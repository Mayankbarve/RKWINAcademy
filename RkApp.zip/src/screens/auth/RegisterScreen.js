// src/screens/auth/RegisterScreen.js
import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn } from '../../components/UI';

export default function RegisterScreen({ navigation }) {
  const { register } = useAuth();
  const [name,    setName]    = useState('');
  const [email,   setEmail]   = useState('');
  const [pwd,     setPwd]     = useState('');
  const [confirm, setConfirm] = useState('');
  const [show,    setShow]    = useState(false);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  const handle = async () => {
    if (!name.trim())       { setError('Please enter your name'); return; }
    if (!email.trim())      { setError('Please enter your email'); return; }
    if (pwd.length < 6)     { setError('Password must be at least 6 characters'); return; }
    if (pwd !== confirm)    { setError('Passwords do not match'); return; }
    setLoading(true); setError('');
    const res = await register(name.trim(), email.trim().toLowerCase(), pwd);
    setLoading(false);
    if (!res.success) setError(res.error || 'Registration failed');
  };

  return (
    <LinearGradient colors={['#08090F', '#0F1220']} style={{ flex: 1 }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
          <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color={C.t1} />
          </TouchableOpacity>

          <LinearGradient colors={C.gGold} style={s.logo}>
            <Text style={s.logoTxt}>RK</Text>
          </LinearGradient>
          <Text style={s.title}>Create Account</Text>
          <Text style={s.sub}>Join thousands of students achieving their goals</Text>

          <View style={s.card}>
            {[
              { key: 'name',  ph: 'Full Name',       val: name,    set: setName,    icon: 'person-outline',      kb: 'default',       cap: 'words' },
              { key: 'email', ph: 'Email Address',    val: email,   set: setEmail,   icon: 'mail-outline',        kb: 'email-address', cap: 'none'  },
            ].map(f => (
              <View key={f.key} style={s.inputWrap}>
                <Ionicons name={f.icon} size={17} color={C.t3} />
                <TextInput style={s.input} placeholder={f.ph}
                  placeholderTextColor={C.t3} value={f.val} onChangeText={f.set}
                  keyboardType={f.kb} autoCapitalize={f.cap} selectionColor={C.gold} />
              </View>
            ))}

            <View style={s.inputWrap}>
              <Ionicons name="lock-closed-outline" size={17} color={C.t3} />
              <TextInput style={[s.input, { flex: 1 }]} placeholder="Password (min 6 chars)"
                placeholderTextColor={C.t3} value={pwd} onChangeText={setPwd}
                secureTextEntry={!show} selectionColor={C.gold} />
              <TouchableOpacity onPress={() => setShow(!show)}>
                <Ionicons name={show ? 'eye' : 'eye-off'} size={17} color={C.t3} />
              </TouchableOpacity>
            </View>

            <View style={s.inputWrap}>
              <Ionicons name="checkmark-circle-outline" size={17} color={C.t3} />
              <TextInput style={s.input} placeholder="Confirm Password"
                placeholderTextColor={C.t3} value={confirm} onChangeText={setConfirm}
                secureTextEntry={!show} selectionColor={C.gold} />
            </View>

            {error ? <Text style={s.err}>{error}</Text> : null}

            <GradBtn label={loading ? 'Creating Account…' : 'Create Account'} onPress={handle} disabled={loading} />

            <TouchableOpacity style={s.loginRow} onPress={() => navigation.goBack()}>
              <Text style={s.loginTxt}>Already have an account? <Text style={{ color: C.gold }}>Sign In</Text></Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  scroll:    { flexGrow: 1, padding: S.base, paddingTop: 56, alignItems: 'center', gap: 12 },
  backBtn:   { position: 'absolute', top: 52, left: S.base, width: 40, height: 40, borderRadius: R.md, backgroundColor: `${C.surface}90`, justifyContent: 'center', alignItems: 'center' },
  logo:      { width: 68, height: 68, borderRadius: 20, justifyContent: 'center', alignItems: 'center', marginTop: 20 },
  logoTxt:   { fontSize: 28, fontWeight: '900', color: C.inv },
  title:     { color: C.t1, fontSize: F.x2, fontWeight: '900' },
  sub:       { color: C.t2, fontSize: F.sm, textAlign: 'center' },
  card:      { backgroundColor: C.card, borderRadius: R.x2, padding: S.xl, borderWidth: 1, borderColor: C.border, gap: 14, width: '100%' },
  inputWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.surface, borderRadius: R.md, borderWidth: 1, borderColor: C.border, paddingHorizontal: S.md, height: 52 },
  input:     { flex: 1, color: C.t1, fontSize: F.md },
  err:       { color: C.red, fontSize: F.sm, textAlign: 'center' },
  loginRow:  { alignItems: 'center' },
  loginTxt:  { color: C.t2, fontSize: F.sm },
});
