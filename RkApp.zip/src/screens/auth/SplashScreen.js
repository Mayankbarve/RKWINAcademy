// src/screens/auth/SplashScreen.js
import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { C } from '../../theme/colors';

export default function SplashScreen({ navigation }) {
  const scale   = useRef(new Animated.Value(0.25)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const tagOp   = useRef(new Animated.Value(0)).current;
  const ring1   = useRef(new Animated.Value(0.5)).current;
  const ring2   = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale,   { toValue: 1, tension: 45, friction: 7, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
      Animated.timing(tagOp, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();

    Animated.loop(Animated.sequence([
      Animated.timing(ring1, { toValue: 1,   duration: 1600, useNativeDriver: true }),
      Animated.timing(ring1, { toValue: 0.5, duration: 1600, useNativeDriver: true }),
    ])).start();
    Animated.loop(Animated.sequence([
      Animated.timing(ring2, { toValue: 0.7, duration: 2200, useNativeDriver: true }),
      Animated.timing(ring2, { toValue: 0.3, duration: 2200, useNativeDriver: true }),
    ])).start();

    const t = setTimeout(() => navigation.replace('Login'), 2600);
    return () => clearTimeout(t);
  }, []);

  return (
    <LinearGradient colors={['#08090F', '#0F1220', '#08090F']} style={s.wrap}>
      <Animated.View style={[s.ring, s.ring1, { opacity: ring1 }]} />
      <Animated.View style={[s.ring, s.ring2, { opacity: ring2 }]} />

      <Animated.View style={[s.logoWrap, { opacity, transform: [{ scale }] }]}>
        <LinearGradient colors={C.gGold} style={s.logoBg}>
          <Text style={s.logoTxt}>RK</Text>
        </LinearGradient>
        <Text style={s.appName}>WIN ACADEMY</Text>
        <Animated.View style={[s.tagRow, { opacity: tagOp }]}>
          <View style={s.line} />
          <Text style={s.tagline}>EXCELLENCE · EVERY DAY</Text>
          <View style={s.line} />
        </Animated.View>
      </Animated.View>

      <Text style={s.ver}>v1.0.0</Text>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  wrap:    { flex: 1, justifyContent: 'center', alignItems: 'center' },
  ring:    { position: 'absolute', borderRadius: 999, borderWidth: 1, borderColor: `${C.gold}45` },
  ring1:   { width: 280, height: 280 },
  ring2:   { width: 400, height: 400 },
  logoWrap:{ alignItems: 'center', gap: 14 },
  logoBg:  { width: 106, height: 106, borderRadius: 30, justifyContent: 'center', alignItems: 'center', shadowColor: C.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.85, shadowRadius: 28, elevation: 20 },
  logoTxt: { fontSize: 46, fontWeight: '900', color: C.inv, letterSpacing: 2 },
  appName: { fontSize: 26, fontWeight: '900', color: C.t1, letterSpacing: 7 },
  tagRow:  { flexDirection: 'row', alignItems: 'center', gap: 10 },
  line:    { height: 1, width: 40, backgroundColor: `${C.gold}55` },
  tagline: { color: C.t2, fontSize: 11, letterSpacing: 3 },
  ver:     { position: 'absolute', bottom: 40, color: C.t3, fontSize: 12 },
});
