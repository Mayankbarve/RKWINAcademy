// src/screens/auth/LoginScreen.js
import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Animated, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn } from '../../components/UI';

export default function LoginScreen({ navigation }) {
  const { signIn, signInWithGoogle } = useAuth();
  const [tab,      setTab]      = useState('email');
  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [showPwd,  setShowPwd]  = useState(false);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');
  const shake = useRef(new Animated.Value(0)).current;

  const doShake = () =>
    Animated.sequence([
      Animated.timing(shake, { toValue: 10,  duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: -10, duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 8,   duration: 55, useNativeDriver: true }),
      Animated.timing(shake, { toValue: 0,   duration: 55, useNativeDriver: true }),
    ]).start();

  const handleSignIn = async () => {
    if (!email.trim() || !password) { setError('Enter email and password'); doShake(); return; }
    setLoading(true); setError('');
    const res = await signIn(email.trim().toLowerCase(), password);
    setLoading(false);
    if (!res.success) { setError(res.error || 'Sign-in failed'); doShake(); }
  };

  const handleGoogle = async () => {
    setLoading(true); setError('');
    const res = await signInWithGoogle();
    setLoading(false);
    if (!res.success) { setError(res.error || 'Google sign-in failed'); doShake(); }
  };

  return (
    <LinearGradient colors={['#08090F', '#0F1220', '#08090F']} style={{ flex: 1 }}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={s.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

          {/* Logo */}
          <View style={s.header}>
            <LinearGradient colors={C.gGold} style={s.logo}>
              <Text style={s.logoTxt}>RK</Text>
            </LinearGradient>
            <Text style={s.brand}>RK WIN Academy</Text>
            <Text style={s.tagline}>Your gateway to excellence</Text>
          </View>

          {/* Card */}
          <Animated.View style={[s.card, { transform: [{ translateX: shake }] }]}>
            <Text style={s.cardTitle}>Welcome Back</Text>
            <Text style={s.cardSub}>Sign in to continue your journey</Text>

            {/* Tabs */}
            <View style={s.tabRow}>
              {[
                { key: 'email',  icon: 'mail',       label: 'Email'  },
                { key: 'google', icon: 'logo-google', label: 'Google' },
              ].map(t => (
                <TouchableOpacity
                  key={t.key}
                  style={[s.tabBtn, tab === t.key && s.tabBtnA]}
                  onPress={() => { setTab(t.key); setError(''); }}
                >
                  <Ionicons name={t.icon} size={15} color={tab === t.key ? C.gold : C.t3} />
                  <Text style={[s.tabTxt, tab === t.key && s.tabTxtA]}>{t.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {tab === 'email' ? (
              <>
                <View style={s.inputWrap}>
                  <Ionicons name="mail-outline" size={17} color={C.t3} />
                  <TextInput style={s.input} placeholder="Email address"
                    placeholderTextColor={C.t3} value={email} onChangeText={setEmail}
                    autoCapitalize="none" keyboardType="email-address" selectionColor={C.gold} />
                </View>
                <View style={s.inputWrap}>
                  <Ionicons name="lock-closed-outline" size={17} color={C.t3} />
                  <TextInput style={[s.input, { flex: 1 }]} placeholder="Password"
                    placeholderTextColor={C.t3} value={password} onChangeText={setPassword}
                    secureTextEntry={!showPwd} selectionColor={C.gold} />
                  <TouchableOpacity onPress={() => setShowPwd(!showPwd)}>
                    <Ionicons name={showPwd ? 'eye' : 'eye-off'} size={17} color={C.t3} />
                  </TouchableOpacity>
                </View>

                {error ? <Text style={s.err}>{error}</Text> : null}

                <GradBtn label={loading ? 'Signing in…' : 'Sign In  →'} onPress={handleSignIn} disabled={loading} />

                <TouchableOpacity style={s.regRow} onPress={() => navigation.navigate('Register')}>
                  <Text style={s.regTxt}>New student? <Text style={{ color: C.gold }}>Create account</Text></Text>
                </TouchableOpacity>
              </>
            ) : (
              <>
                <View style={s.googleBox}>
                  <Ionicons name="logo-google" size={32} color="#EA4335" />
                  <Text style={s.googleDesc}>
                    Sign in with your Google account. New users can set a password after first sign-in.
                  </Text>
                </View>
                {error ? <Text style={s.err}>{error}</Text> : null}
                <TouchableOpacity style={s.gBtn} onPress={handleGoogle} disabled={loading} activeOpacity={0.85}>
                  <Ionicons name="logo-google" size={20} color={C.t1} />
                  <Text style={s.gBtnTxt}>{loading ? 'Connecting…' : 'Continue with Google'}</Text>
                </TouchableOpacity>
              </>
            )}
          </Animated.View>

          {/* Demo hint */}
          <View style={s.demo}>
            <Ionicons name="information-circle-outline" size={14} color={C.gold} />
            <Text style={s.demoTxt}>Demo: student@rkwin.com · any password</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  scroll:      { flexGrow: 1, justifyContent: 'center', padding: S.base },
  header:      { alignItems: 'center', marginBottom: S.x2, gap: 8 },
  logo:        { width: 76, height: 76, borderRadius: 22, justifyContent: 'center', alignItems: 'center', shadowColor: C.gold, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.6, shadowRadius: 18, elevation: 14 },
  logoTxt:     { fontSize: 32, fontWeight: '900', color: C.inv },
  brand:       { fontSize: F.x2, fontWeight: '900', color: C.t1, letterSpacing: 0.5 },
  tagline:     { color: C.t2, fontSize: F.sm },
  card:        { backgroundColor: C.card, borderRadius: R.x2, padding: S.xl, borderWidth: 1, borderColor: C.border, gap: 14 },
  cardTitle:   { color: C.t1, fontSize: F.x2, fontWeight: '800' },
  cardSub:     { color: C.t2, fontSize: F.sm, marginTop: -6 },
  tabRow:      { flexDirection: 'row', backgroundColor: C.surface, borderRadius: R.md, padding: 4 },
  tabBtn:      { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 10, borderRadius: R.sm },
  tabBtnA:     { backgroundColor: C.card2 },
  tabTxt:      { fontSize: F.md, fontWeight: '600', color: C.t3 },
  tabTxtA:     { color: C.gold },
  inputWrap:   { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.surface, borderRadius: R.md, borderWidth: 1, borderColor: C.border, paddingHorizontal: S.md, height: 52 },
  input:       { flex: 1, color: C.t1, fontSize: F.md },
  err:         { color: C.red, fontSize: F.sm, textAlign: 'center' },
  regRow:      { alignItems: 'center' },
  regTxt:      { color: C.t2, fontSize: F.sm },
  googleBox:   { alignItems: 'center', gap: 12, paddingVertical: S.lg },
  googleDesc:  { color: C.t2, fontSize: F.sm, textAlign: 'center', lineHeight: 20 },
  gBtn:        { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, backgroundColor: C.surface, borderRadius: R.md, paddingVertical: 15, borderWidth: 1, borderColor: C.border },
  gBtnTxt:     { color: C.t1, fontSize: F.base, fontWeight: '700' },
  demo:        { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: S.xl, backgroundColor: `${C.gold}12`, borderRadius: R.md, padding: S.md, borderWidth: 1, borderColor: `${C.gold}28` },
  demoTxt:     { color: C.gold, fontSize: F.sm, fontWeight: '600' },
});
