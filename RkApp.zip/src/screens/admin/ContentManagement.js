// src/screens/admin/ContentManagement.js
export { ContentManagement as default } from './LiveControl';
