// src/screens/admin/AdminDashboard.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useApp  } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

export default function AdminDashboard({ navigation }) {
  const { user, signOut } = useAuth();
  const { adminStats, liveClasses } = useApp();
  const [refreshing, setRefreshing] = useState(false);

  const liveNow = liveClasses.find(c => c.isLive);
  const onRefresh = () => { setRefreshing(true); setTimeout(() => setRefreshing(false), 1000); };

  const kpis = [
    { icon:'people',      label:'Total Students', val: adminStats.totalStudents.toLocaleString(), color:C.cyan   },
    { icon:'pulse',       label:'Active Today',   val: adminStats.activeToday,                    color:C.green  },
    { icon:'book',        label:'Batches',         val: adminStats.totalBatches,                   color:C.gold   },
    { icon:'help-circle', label:'Pending Doubts',  val: adminStats.pendingDoubts,                  color:C.yellow },
    { icon:'trending-up', label:'Avg Attendance',  val:`${adminStats.avgAttendance}%`,             color:C.purple },
    { icon:'radio',       label:'Live Now',        val: liveNow ? '1' : '0',                       color:C.live   },
  ];

  const quickActions = [
    { icon:'radio',         label:'Go Live',     color:C.live,   onPress:()=>navigation.navigate('LiveControl')       },
    { icon:'notifications', label:'Send Notif',  color:C.gold,   onPress:()=>navigation.navigate('NotifControl')      },
    { icon:'add-circle',    label:'New Batch',   color:C.green,  onPress:()=>navigation.getParent()?.navigate('Batches')},
    { icon:'card',          label:'Payments',    color:C.purple, onPress:()=>navigation.navigate('PaymentManagement') },
  ];

  return (
    <View style={s.root}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.gold} />}
      >
        {/* Header */}
        <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
          <View style={s.headerTop}>
            <View>
              <Text style={s.adminBadge}>👑 Admin Panel</Text>
              <Text style={s.headerName}>RK WIN Academy</Text>
              <Text style={s.headerSub}>Welcome, {user?.name}</Text>
            </View>
            <TouchableOpacity style={s.signOutBtn} onPress={signOut}>
              <Ionicons name="log-out-outline" size={20} color={C.red} />
            </TouchableOpacity>
          </View>

          {/* Revenue card */}
          <LinearGradient colors={[`${C.gold}28`,`${C.gold}08`]} style={s.revenueCard}>
            <View>
              <Text style={s.revenueLabel}>Revenue This Month</Text>
              <Text style={s.revenueVal}>₹{adminStats.revenueThisMonth.toLocaleString()}</Text>
            </View>
            <View style={s.revenueRight}>
              <Text style={s.newEnroll}>+{adminStats.newEnrollments}</Text>
              <Text style={s.newEnrollLabel}>New this week</Text>
            </View>
          </LinearGradient>
        </LinearGradient>

        <View style={s.body}>
          {/* Live alert */}
          {liveNow && (
            <TouchableOpacity
              style={s.liveBanner}
              onPress={() => navigation.navigate('LiveControl')}
              activeOpacity={0.9}
            >
              <View style={s.livePulse} />
              <View style={{ flex: 1 }}>
                <Text style={s.liveBannerTitle}>🔴 Live Class in Progress</Text>
                <Text style={s.liveBannerSub}>{liveNow.title} · {liveNow.attendees} students</Text>
              </View>
              <View style={s.manageBtn}>
                <Text style={s.manageBtnTxt}>Manage</Text>
              </View>
            </TouchableOpacity>
          )}

          {/* KPI grid */}
          <Text style={s.sectionTitle}>Overview</Text>
          <View style={s.kpiGrid}>
            {kpis.map((k, i) => (
              <View key={i} style={s.kpiCard}>
                <LinearGradient colors={[`${k.color}22`,`${k.color}06`]} style={s.kpiInner}>
                  <View style={[s.kpiIcon, { backgroundColor: `${k.color}28` }]}>
                    <Ionicons name={k.icon} size={20} color={k.color} />
                  </View>
                  <Text style={[s.kpiVal, { color: k.color }]}>{k.val}</Text>
                  <Text style={s.kpiLabel}>{k.label}</Text>
                </LinearGradient>
              </View>
            ))}
          </View>

          {/* Quick actions */}
          <Text style={s.sectionTitle}>Quick Actions</Text>
          <View style={s.quickGrid}>
            {quickActions.map((a, i) => (
              <TouchableOpacity key={i} style={s.quickCard} onPress={a.onPress} activeOpacity={0.85}>
                <LinearGradient colors={[`${a.color}22`,`${a.color}06`]} style={s.quickInner}>
                  <View style={[s.quickIcon, { backgroundColor: `${a.color}28` }]}>
                    <Ionicons name={a.icon} size={24} color={a.color} />
                  </View>
                  <Text style={s.quickLabel}>{a.label}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>

          {/* Revenue chart */}
          <Text style={s.sectionTitle}>Weekly Revenue</Text>
          <View style={s.chartCard}>
            <View style={s.chartBars}>
              {adminStats.weeklyRevenue.map((val, i) => {
                const max = Math.max(...adminStats.weeklyRevenue);
                const pct = Math.round((val / max) * 100);
                const days = ['M','T','W','T','F','S','S'];
                return (
                  <View key={i} style={s.barWrap}>
                    <Text style={s.barVal}>₹{(val/1000).toFixed(0)}k</Text>
                    <View style={s.barBg}>
                      <LinearGradient colors={C.gGold} style={[s.barFill, { height: `${pct}%` }]} />
                    </View>
                    <Text style={s.barDay}>{days[i]}</Text>
                  </View>
                );
              })}
            </View>
          </View>

          {/* Batch breakdown */}
          <Text style={s.sectionTitle}>Batch Enrollments</Text>
          <View style={s.enrollCard}>
            {adminStats.batchStats.map((b, i) => {
              const max = Math.max(...adminStats.batchStats.map(x => x.students));
              const pct = Math.round((b.students / max) * 100);
              return (
                <View key={i} style={s.enrollRow}>
                  <Text style={s.enrollName}>{b.name}</Text>
                  <View style={s.enrollBarBg}>
                    <LinearGradient
                      colors={[b.color, `${b.color}80`]}
                      style={[s.enrollBarFill, { width: `${pct}%` }]}
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                    />
                  </View>
                  <Text style={[s.enrollCount, { color: b.color }]}>{b.students}</Text>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:             { flex: 1, backgroundColor: C.bg },
  header:           { paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.xl, gap: 16 },
  headerTop:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  adminBadge:       { color: C.gold, fontSize: F.sm, fontWeight: '700', marginBottom: 4 },
  headerName:       { color: C.t1, fontSize: F.x2, fontWeight: '900' },
  headerSub:        { color: C.t2, fontSize: F.sm },
  signOutBtn:       { width: 42, height: 42, borderRadius: 12, backgroundColor: `${C.red}18`, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: `${C.red}28` },
  revenueCard:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderRadius: R.lg, padding: S.lg, borderWidth: 1, borderColor: `${C.gold}28` },
  revenueLabel:     { color: C.t2, fontSize: 12, marginBottom: 4 },
  revenueVal:       { color: C.gold, fontSize: F.x3, fontWeight: '900' },
  revenueRight:     { alignItems: 'flex-end' },
  newEnroll:        { color: C.green, fontWeight: '900', fontSize: F.x2 },
  newEnrollLabel:   { color: C.t3, fontSize: 11 },
  body:             { padding: S.base, gap: 14, paddingBottom: S.x4 },
  liveBanner:       { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: R.lg, padding: S.md, backgroundColor: `${C.live}10`, borderWidth: 1, borderColor: `${C.live}35` },
  livePulse:        { width: 10, height: 10, borderRadius: 5, backgroundColor: C.live },
  liveBannerTitle:  { color: C.t1, fontWeight: '700', fontSize: F.sm },
  liveBannerSub:    { color: C.t2, fontSize: 12, marginTop: 2 },
  manageBtn:        { backgroundColor: C.live, paddingHorizontal: 12, paddingVertical: 6, borderRadius: R.sm },
  manageBtnTxt:     { color: '#fff', fontWeight: '700', fontSize: 12 },
  sectionTitle:     { color: C.t1, fontSize: F.base, fontWeight: '800' },
  kpiGrid:          { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  kpiCard:          { width: '47.5%', borderRadius: R.lg, overflow: 'hidden', borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  kpiInner:         { padding: S.md, gap: 5, borderRadius: R.lg },
  kpiIcon:          { width: 42, height: 42, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  kpiVal:           { fontSize: F.x2, fontWeight: '900' },
  kpiLabel:         { color: C.t2, fontSize: 12, fontWeight: '600' },
  quickGrid:        { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  quickCard:        { width: '47.5%', borderRadius: R.lg, overflow: 'hidden', borderWidth: 1, borderColor: C.border, backgroundColor: C.card },
  quickInner:       { padding: S.lg, alignItems: 'center', gap: 10, borderRadius: R.lg },
  quickIcon:        { width: 52, height: 52, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  quickLabel:       { color: C.t1, fontWeight: '700', fontSize: F.sm },
  chartCard:        { backgroundColor: C.card, borderRadius: R.xl, padding: S.lg, borderWidth: 1, borderColor: C.border },
  chartBars:        { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 110 },
  barWrap:          { flex: 1, alignItems: 'center', gap: 4 },
  barVal:           { color: C.t3, fontSize: 9, fontWeight: '600' },
  barBg:            { flex: 1, width: 22, backgroundColor: C.surface, borderRadius: 5, overflow: 'hidden', justifyContent: 'flex-end' },
  barFill:          { width: '100%', borderRadius: 5 },
  barDay:           { color: C.t3, fontSize: 11, fontWeight: '600' },
  enrollCard:       { backgroundColor: C.card, borderRadius: R.xl, padding: S.lg, borderWidth: 1, borderColor: C.border, gap: 14 },
  enrollRow:        { flexDirection: 'row', alignItems: 'center', gap: 10 },
  enrollName:       { color: C.t2, fontSize: 12, fontWeight: '600', width: 72 },
  enrollBarBg:      { flex: 1, height: 10, backgroundColor: C.surface, borderRadius: 5, overflow: 'hidden' },
  enrollBarFill:    { height: '100%', borderRadius: 5 },
  enrollCount:      { fontWeight: '800', fontSize: F.md, width: 40, textAlign: 'right' },
});
