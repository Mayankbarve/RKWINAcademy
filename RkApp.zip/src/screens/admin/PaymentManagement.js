// src/screens/admin/PaymentManagement.js
export { PaymentManagement as default } from './LiveControl';
