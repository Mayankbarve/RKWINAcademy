// src/screens/admin/LiveControl.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Alert, Switch } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn } from '../../components/UI';

export default function LiveControl({ navigation }) {
  const [isLive,    setIsLive]    = useState(true);
  const [videoId,   setVideoId]   = useState('jNQXAC9IVRw');
  const [title,     setTitle]     = useState('Electrostatics — Electric Field & Potential');
  const [recording, setRecording] = useState(false);
  const attendees = 128;

  const toggleLive = () =>
    Alert.alert(isLive?'End Class?':'Start Class?',
      isLive?'This will end the live class for all students.':'Start the live stream now?',[
        { text:'Cancel', style:'cancel' },
        { text:isLive?'End Class':'Go Live', style:isLive?'destructive':'default', onPress:()=>setIsLive(!isLive) },
      ]);

  return (
    <View style={{ flex:1, backgroundColor:C.bg }}>
      <LinearGradient colors={['#0F1220','#08090F']} style={lc.header}>
        <TouchableOpacity style={lc.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={lc.title}>Live Class Control</Text>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={lc.scroll}>
        {/* Status */}
        <LinearGradient
          colors={isLive?[`${C.live}22`,`${C.live}06`]:[`${C.green}18`,`${C.green}05`]}
          style={lc.statusCard}
        >
          <View style={[lc.statusDot,{backgroundColor:isLive?C.live:C.green}]}/>
          <View style={{flex:1}}>
            <Text style={lc.statusTitle}>{isLive?'🔴 Class is LIVE':'⏸ Class is Offline'}</Text>
            {isLive && <Text style={lc.statusSub}>{attendees} students watching right now</Text>}
          </View>
          <TouchableOpacity
            style={[lc.toggleBtn,{backgroundColor:isLive?C.live:C.green}]}
            onPress={toggleLive}
          >
            <Text style={lc.toggleBtnTxt}>{isLive?'End Class':'Go Live'}</Text>
          </TouchableOpacity>
        </LinearGradient>

        {/* Video ID */}
        <View>
          <Text style={lc.label}>YouTube Video ID (Unlisted Only)</Text>
          <View style={lc.inputWrap}>
            <Ionicons name="logo-youtube" size={18} color={C.red}/>
            <TextInput style={lc.input} value={videoId} onChangeText={setVideoId}
              placeholder="11-char Video ID only" placeholderTextColor={C.t3}
              autoCapitalize="none" selectionColor={C.gold}/>
          </View>
          <Text style={lc.hint}>⚠️ Enter ONLY the Video ID — never the full URL. Students cannot see it.</Text>
        </View>

        {/* Title */}
        <View>
          <Text style={lc.label}>Class Title</Text>
          <View style={lc.inputWrap}>
            <Ionicons name="text" size={18} color={C.t3}/>
            <TextInput style={lc.input} value={title} onChangeText={setTitle} selectionColor={C.gold}/>
          </View>
        </View>

        {/* Recording toggle */}
        <View style={lc.switchRow}>
          <View>
            <Text style={lc.switchLabel}>Enable Recording</Text>
            <Text style={lc.switchSub}>Save class for later viewing</Text>
          </View>
          <Switch value={recording} onValueChange={setRecording}
            trackColor={{false:C.surface,true:`${C.gold}55`}} thumbColor={recording?C.gold:C.t3}/>
        </View>

        {/* Live stats */}
        {isLive && (
          <View style={lc.liveStats}>
            {[{label:'Watching',val:attendees,icon:'eye',color:C.live},{label:'Questions',val:14,icon:'chatbubbles',color:C.gold},{label:'Duration',val:'48m',icon:'time',color:C.cyan}].map((st2,i)=>(
              <View key={i} style={lc.liveStat}>
                <Ionicons name={st2.icon} size={18} color={st2.color}/>
                <Text style={[lc.liveStatVal,{color:st2.color}]}>{st2.val}</Text>
                <Text style={lc.liveStatLabel}>{st2.label}</Text>
              </View>
            ))}
          </View>
        )}

        <GradBtn label={isLive?'End Live Class':'Start Live Class'}
          colors={isLive?[C.red,C.redDark]:C.gGreen}
          onPress={toggleLive}/>
      </ScrollView>
    </View>
  );
}

const lc = StyleSheet.create({
  header:       {flexDirection:'row',alignItems:'center',gap:12,paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  backBtn:      {width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center'},
  title:        {color:C.t1,fontSize:F.xl,fontWeight:'900'},
  scroll:       {padding:S.base,gap:16,paddingBottom:40},
  label:        {color:C.t2,fontSize:F.sm,fontWeight:'700',marginBottom:6},
  inputWrap:    {flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,borderRadius:R.md,paddingHorizontal:S.md,height:52,borderWidth:1,borderColor:C.border},
  input:        {flex:1,color:C.t1,fontSize:F.md},
  hint:         {color:C.yellow,fontSize:11,fontStyle:'italic',marginTop:5},
  switchRow:    {flexDirection:'row',justifyContent:'space-between',alignItems:'center',backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border},
  switchLabel:  {color:C.t1,fontWeight:'700',fontSize:F.md},
  switchSub:    {color:C.t3,fontSize:12,marginTop:2},
  statusCard:   {flexDirection:'row',alignItems:'center',gap:12,borderRadius:R.xl,padding:S.lg,borderWidth:1,borderColor:`${C.live}28`},
  statusDot:    {width:12,height:12,borderRadius:6},
  statusTitle:  {color:C.t1,fontWeight:'800',fontSize:F.base},
  statusSub:    {color:C.t2,fontSize:12,marginTop:2},
  toggleBtn:    {paddingHorizontal:14,paddingVertical:8,borderRadius:R.sm},
  toggleBtnTxt: {color:'#fff',fontWeight:'800',fontSize:F.sm},
  liveStats:    {flexDirection:'row',justifyContent:'space-around',backgroundColor:C.card,borderRadius:R.xl,padding:S.lg,borderWidth:1,borderColor:C.border},
  liveStat:     {alignItems:'center',gap:5},
  liveStatVal:  {fontWeight:'900',fontSize:F.x2},
  liveStatLabel:{color:C.t3,fontSize:11},
});

// ─────────────────────────────────────────────────────────────────
// ContentManagement
// ─────────────────────────────────────────────────────────────────
export function ContentManagement({ route, navigation }) {
  const [tab, setTab] = useState('videos');
  return (
    <View style={{ flex:1, backgroundColor:C.bg }}>
      <LinearGradient colors={['#0F1220','#08090F']} style={lc.header}>
        <TouchableOpacity style={lc.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={lc.title}>Content Management</Text>
      </LinearGradient>

      <View style={cm.tabBar}>
        {['videos','notes','tests'].map(t=>(
          <TouchableOpacity key={t} style={[cm.tabBtn,tab===t&&cm.tabBtnA]} onPress={()=>setTab(t)}>
            <Text style={[cm.tabTxt,tab===t&&cm.tabTxtA]}>{t.charAt(0).toUpperCase()+t.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{padding:S.base,gap:12}}>
        <TouchableOpacity style={cm.uploadCard}>
          <LinearGradient colors={[`${C.gold}18`,`${C.gold}05`]} style={cm.uploadInner}>
            <Ionicons name="cloud-upload-outline" size={30} color={C.gold}/>
            <Text style={cm.uploadTitle}>Upload {tab==='videos'?'Video':tab==='notes'?'Notes / PDF':'Test'}</Text>
            <Text style={cm.uploadSub}>{tab==='videos'?'Add YouTube video ID':tab==='notes'?'PDF, DOC files':'Create MCQ test'}</Text>
          </LinearGradient>
        </TouchableOpacity>

        {[1,2,3].map(i=>(
          <View key={i} style={cm.contentRow}>
            <View style={cm.contentIcon}>
              <Ionicons name={tab==='videos'?'play-circle':tab==='notes'?'document-text':'clipboard'} size={20} color={C.gold}/>
            </View>
            <View style={{flex:1}}>
              <Text style={cm.contentTitle}>{tab==='videos'?`Lecture ${i}: Topic Name`:tab==='notes'?`Notes Part ${i}.pdf`:`Chapter Test ${i}`}</Text>
              <Text style={cm.contentMeta}>{tab==='videos'?'42:18 min':tab==='notes'?'2.4 MB':'30 questions'}</Text>
            </View>
            <TouchableOpacity style={cm.editBtn}><Ionicons name="create-outline" size={15} color={C.gold}/></TouchableOpacity>
            <TouchableOpacity style={cm.delBtn}><Ionicons name="trash-outline" size={15} color={C.red}/></TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const cm = StyleSheet.create({
  tabBar:       {flexDirection:'row',backgroundColor:C.card,borderBottomWidth:1,borderBottomColor:C.border,paddingHorizontal:S.sm,paddingTop:S.xs},
  tabBtn:       {flex:1,paddingVertical:12,alignItems:'center',borderBottomWidth:2,borderBottomColor:'transparent'},
  tabBtnA:      {borderBottomColor:C.gold},
  tabTxt:       {color:C.t3,fontWeight:'600',fontSize:F.sm},
  tabTxtA:      {color:C.gold},
  uploadCard:   {borderRadius:R.xl,overflow:'hidden',borderWidth:2,borderColor:C.border,borderStyle:'dashed'},
  uploadInner:  {padding:S.xl,alignItems:'center',gap:7},
  uploadTitle:  {color:C.t1,fontWeight:'700',fontSize:F.base},
  uploadSub:    {color:C.t3,fontSize:12},
  contentRow:   {flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border},
  contentIcon:  {width:44,height:44,borderRadius:10,backgroundColor:`${C.gold}15`,justifyContent:'center',alignItems:'center'},
  contentTitle: {color:C.t1,fontWeight:'700',fontSize:F.md},
  contentMeta:  {color:C.t3,fontSize:12,marginTop:2},
  editBtn:      {width:34,height:34,borderRadius:8,backgroundColor:`${C.gold}15`,justifyContent:'center',alignItems:'center'},
  delBtn:       {width:34,height:34,borderRadius:8,backgroundColor:`${C.red}15`,justifyContent:'center',alignItems:'center'},
});

// ─────────────────────────────────────────────────────────────────
// NotifControl
// ─────────────────────────────────────────────────────────────────
export function NotifControl({ navigation }) {
  const [target,  setTarget]  = useState('all');
  const [nTitle,  setNTitle]  = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  const send = async () => {
    if (!nTitle||!message) { Alert.alert('Error','Fill in title and message'); return; }
    setSending(true);
    await new Promise(r=>setTimeout(r,1500));
    setSending(false);
    Alert.alert('✅ Sent!',`Notification sent to ${target==='all'?'all students':target}`);
    setNTitle(''); setMessage('');
  };

  return (
    <View style={{flex:1,backgroundColor:C.bg}}>
      <LinearGradient colors={['#0F1220','#08090F']} style={lc.header}>
        <TouchableOpacity style={lc.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={lc.title}>Send Notification</Text>
      </LinearGradient>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{padding:S.base,gap:14,paddingBottom:40}}>
        <Text style={lc.label}>Target Audience</Text>
        <View style={nc.targetRow}>
          {['all','JEE 2025','NEET 2025','Board'].map(t=>(
            <TouchableOpacity key={t} style={[nc.targetBtn,target===t&&nc.targetBtnA]} onPress={()=>setTarget(t)}>
              <Text style={[nc.targetTxt,target===t&&nc.targetTxtA]}>{t==='all'?'All Students':t}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <Text style={lc.label}>Notification Title</Text>
        <View style={lc.inputWrap}>
          <Ionicons name="notifications" size={17} color={C.t3}/>
          <TextInput style={lc.input} value={nTitle} onChangeText={setNTitle} placeholder="Notification title" placeholderTextColor={C.t3} selectionColor={C.gold}/>
        </View>
        <Text style={lc.label}>Message</Text>
        <View style={[lc.inputWrap,{height:120,alignItems:'flex-start',paddingTop:12}]}>
          <Ionicons name="text" size={17} color={C.t3} style={{marginTop:2}}/>
          <TextInput style={[lc.input,{textAlignVertical:'top'}]} value={message} onChangeText={setMessage}
            placeholder="Your message…" placeholderTextColor={C.t3} multiline numberOfLines={4} selectionColor={C.gold}/>
        </View>
        <GradBtn label={sending?'Sending…':'Send Notification'} icon="send" onPress={send} disabled={sending}/>
      </ScrollView>
    </View>
  );
}

const nc = StyleSheet.create({
  targetRow:  {flexDirection:'row',flexWrap:'wrap',gap:8},
  targetBtn:  {paddingHorizontal:13,paddingVertical:8,borderRadius:R.full,backgroundColor:C.surface,borderWidth:1,borderColor:C.border},
  targetBtnA: {backgroundColor:`${C.gold}18`,borderColor:C.gold},
  targetTxt:  {color:C.t3,fontSize:F.sm,fontWeight:'600'},
  targetTxtA: {color:C.gold},
});

// ─────────────────────────────────────────────────────────────────
// PaymentManagement
// ─────────────────────────────────────────────────────────────────
export function PaymentManagement({ navigation }) {
  const payments = [
    {id:'p1',student:'Priya Patel', batch:'JEE 2025',  amount:4999,date:'2024-01-20',status:'paid'  },
    {id:'p2',student:'Rohan Verma', batch:'NEET 2025', amount:3999,date:'2024-02-01',status:'paid'  },
    {id:'p3',student:'Ananya Singh',batch:'JEE 2025',  amount:4999,date:'2024-01-18',status:'refund'},
    {id:'p4',student:'Karan Mehta', batch:'Board',     amount:0,   date:'2024-03-10',status:'free'  },
  ];
  const statusColor = {paid:C.green,refund:C.yellow,free:C.cyan};

  return (
    <View style={{flex:1,backgroundColor:C.bg}}>
      <LinearGradient colors={['#0F1220','#08090F']} style={lc.header}>
        <TouchableOpacity style={lc.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={lc.title}>Payments</Text>
      </LinearGradient>

      <View style={pm.summaryRow}>
        {[{label:'Total Revenue',val:'₹1,84,500',color:C.gold},{label:'Pending',val:'₹0',color:C.yellow},{label:'Refunds',val:'₹4,999',color:C.red}].map((r,i)=>(
          <View key={i} style={{alignItems:'center',gap:3}}>
            <Text style={[pm.summaryVal,{color:r.color}]}>{r.val}</Text>
            <Text style={pm.summaryLabel}>{r.label}</Text>
          </View>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{padding:S.base,gap:10}}>
        {payments.map(p=>(
          <View key={p.id} style={pm.payRow}>
            <View style={pm.payAvatar}><Text style={pm.payAvatarTxt}>{p.student[0]}</Text></View>
            <View style={{flex:1}}>
              <Text style={pm.payName}>{p.student}</Text>
              <Text style={pm.payMeta}>{p.batch} · {p.date}</Text>
            </View>
            <View style={{alignItems:'flex-end',gap:4}}>
              <Text style={[pm.payAmount,{color:statusColor[p.status]}]}>
                {p.status==='free'?'FREE':`₹${p.amount.toLocaleString()}`}
              </Text>
              <View style={[pm.payStatus,{backgroundColor:`${statusColor[p.status]}18`}]}>
                <Text style={[pm.payStatusTxt,{color:statusColor[p.status]}]}>{p.status}</Text>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const pm = StyleSheet.create({
  summaryRow:   {flexDirection:'row',justifyContent:'space-around',backgroundColor:C.card,padding:S.lg,borderBottomWidth:1,borderBottomColor:C.border},
  summaryVal:   {fontWeight:'900',fontSize:F.lg},
  summaryLabel: {color:C.t3,fontSize:11},
  payRow:       {flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.card,borderRadius:R.xl,padding:S.md,borderWidth:1,borderColor:C.border},
  payAvatar:    {width:44,height:44,borderRadius:12,backgroundColor:C.surface,justifyContent:'center',alignItems:'center'},
  payAvatarTxt: {color:C.t1,fontWeight:'900',fontSize:18},
  payName:      {color:C.t1,fontWeight:'700',fontSize:F.md},
  payMeta:      {color:C.t3,fontSize:12,marginTop:2},
  payAmount:    {fontWeight:'900',fontSize:F.base},
  payStatus:    {paddingHorizontal:8,paddingVertical:3,borderRadius:8},
  payStatusTxt: {fontSize:11,fontWeight:'700'},
});
