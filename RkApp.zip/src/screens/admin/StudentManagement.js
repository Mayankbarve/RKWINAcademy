// src/screens/admin/StudentManagement.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, Modal, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const STUDENTS = [
  { id:'s1', name:'Arjun Sharma',  email:'arjun@gmail.com',  batch:'JEE 2025',  status:'active',    progress:68, phone:'+91 9876543210', joinedAt:'2024-01-15' },
  { id:'s2', name:'Priya Patel',   email:'priya@gmail.com',  batch:'JEE 2025',  status:'active',    progress:92, phone:'+91 9876543211', joinedAt:'2024-01-20' },
  { id:'s3', name:'Rohan Verma',   email:'rohan@gmail.com',  batch:'NEET 2025', status:'active',    progress:74, phone:'+91 9876543212', joinedAt:'2024-02-01' },
  { id:'s4', name:'Ananya Singh',  email:'ananya@gmail.com', batch:'JEE 2025',  status:'suspended', progress:45, phone:'+91 9876543213', joinedAt:'2024-01-18' },
  { id:'s5', name:'Karan Mehta',   email:'karan@gmail.com',  batch:'Board',     status:'active',    progress:55, phone:'+91 9876543214', joinedAt:'2024-03-10' },
  { id:'s6', name:'Divya Nair',    email:'divya@gmail.com',  batch:'NEET 2025', status:'pending',   progress: 0, phone:'+91 9876543215', joinedAt:'2024-04-05' },
];
const STATUS_CFG = { active:{color:C.green,label:'Active'}, suspended:{color:C.red,label:'Suspended'}, pending:{color:C.yellow,label:'Pending'} };

export default function StudentManagement() {
  const [search,   setSearch]   = useState('');
  const [filter,   setFilter]   = useState('all');
  const [selected, setSelected] = useState(null);

  const filtered = STUDENTS.filter(s => {
    const ms = s.name.toLowerCase().includes(search.toLowerCase()) || s.email.toLowerCase().includes(search.toLowerCase());
    const mf = filter==='all' || s.status===filter;
    return ms && mf;
  });

  const doAction = (action) => {
    Alert.alert(action.charAt(0).toUpperCase()+action.slice(1), `${action} ${selected?.name}?`,[
      { text:'Cancel', style:'cancel' },
      { text:'Confirm', style:action==='remove'?'destructive':'default',
        onPress:()=>{ Alert.alert('Done',`${selected?.name} ${action}d (demo)`); setSelected(null); }},
    ]);
  };

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <Text style={s.title}>Student Management</Text>
        <Text style={s.sub}>{STUDENTS.length} total students</Text>
      </LinearGradient>

      <View style={s.filterRow}>
        {['all','active','suspended','pending'].map(f=>(
          <TouchableOpacity key={f} style={[s.filterBtn,filter===f&&s.filterBtnA]} onPress={()=>setFilter(f)}>
            <Text style={[s.filterTxt,filter===f&&s.filterTxtA]}>{f.charAt(0).toUpperCase()+f.slice(1)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={s.searchWrap}>
        <Ionicons name="search" size={15} color={C.t3}/>
        <TextInput style={s.search} placeholder="Search…" placeholderTextColor={C.t3}
          value={search} onChangeText={setSearch} selectionColor={C.gold}/>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={s2=>s2.id}
        contentContainerStyle={{padding:S.base,gap:10}}
        showsVerticalScrollIndicator={false}
        renderItem={({item})=>{
          const cfg = STATUS_CFG[item.status]||STATUS_CFG.active;
          return (
            <TouchableOpacity style={s.studentCard} onPress={()=>setSelected(item)} activeOpacity={0.85}>
              <LinearGradient colors={[C.surface,C.card2]} style={s.avatar}>
                <Text style={s.avatarTxt}>{item.name[0]}</Text>
              </LinearGradient>
              <View style={{flex:1,gap:3}}>
                <Text style={s.studentName}>{item.name}</Text>
                <Text style={s.studentEmail}>{item.email}</Text>
                <View style={s.metaRow}>
                  <View style={[s.statusBadge,{backgroundColor:`${cfg.color}18`}]}>
                    <Text style={[s.statusTxt,{color:cfg.color}]}>{cfg.label}</Text>
                  </View>
                  <Text style={s.batchTag}>{item.batch}</Text>
                </View>
              </View>
              <View style={{alignItems:'flex-end'}}>
                <Text style={s.progress}>{item.progress}%</Text>
                <Text style={s.progressLabel}>progress</Text>
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={<View style={{alignItems:'center',paddingTop:60,gap:10}}><Ionicons name="people-outline" size={48} color={C.t3}/><Text style={{color:C.t3,fontSize:F.base}}>No students found</Text></View>}
      />

      <Modal visible={!!selected} animationType="slide" transparent>
        <View style={m.overlay}>
          <View style={m.card}>
            <View style={m.mHeader}>
              <LinearGradient colors={C.gGold} style={m.mAvatar}>
                <Text style={m.mAvatarTxt}>{selected?.name?.[0]}</Text>
              </LinearGradient>
              <View style={{flex:1}}>
                <Text style={m.mName}>{selected?.name}</Text>
                <Text style={m.mEmail}>{selected?.email}</Text>
                <Text style={m.mPhone}>{selected?.phone}</Text>
              </View>
              <TouchableOpacity onPress={()=>setSelected(null)}>
                <Ionicons name="close" size={22} color={C.t1}/>
              </TouchableOpacity>
            </View>
            <View style={m.statsGrid}>
              {[{label:'Batch',val:selected?.batch},{label:'Progress',val:`${selected?.progress}%`},{label:'Joined',val:selected?.joinedAt},{label:'Status',val:selected?.status?.toUpperCase()}].map((st2,i)=>(
                <View key={i} style={m.statItem}>
                  <Text style={m.statLabel}>{st2.label}</Text>
                  <Text style={m.statVal}>{st2.val}</Text>
                </View>
              ))}
            </View>
            <View style={m.actionRow}>
              {selected?.status!=='active' && (
                <TouchableOpacity style={[m.actionBtn,{backgroundColor:`${C.green}15`,borderColor:`${C.green}28`}]} onPress={()=>doAction('activate')}>
                  <Ionicons name="checkmark-circle" size={17} color={C.green}/><Text style={[m.actionTxt,{color:C.green}]}>Activate</Text>
                </TouchableOpacity>
              )}
              {selected?.status==='active' && (
                <TouchableOpacity style={[m.actionBtn,{backgroundColor:`${C.yellow}15`,borderColor:`${C.yellow}28`}]} onPress={()=>doAction('suspend')}>
                  <Ionicons name="ban" size={17} color={C.yellow}/><Text style={[m.actionTxt,{color:C.yellow}]}>Suspend</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={[m.actionBtn,{backgroundColor:`${C.red}15`,borderColor:`${C.red}28`}]} onPress={()=>doAction('remove')}>
                <Ionicons name="trash-outline" size={17} color={C.red}/><Text style={[m.actionTxt,{color:C.red}]}>Remove</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  root:         {flex:1,backgroundColor:C.bg},
  header:       {paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  title:        {color:C.t1,fontSize:F.x2,fontWeight:'900'},
  sub:          {color:C.t2,fontSize:F.sm,marginTop:2},
  filterRow:    {flexDirection:'row',gap:6,paddingHorizontal:S.base,paddingVertical:S.sm,backgroundColor:C.card,borderBottomWidth:1,borderBottomColor:C.border},
  filterBtn:    {paddingHorizontal:11,paddingVertical:7,borderRadius:R.full,backgroundColor:C.surface,borderWidth:1,borderColor:C.border},
  filterBtnA:   {backgroundColor:`${C.gold}18`,borderColor:C.gold},
  filterTxt:    {color:C.t3,fontSize:12,fontWeight:'600'},
  filterTxtA:   {color:C.gold},
  searchWrap:   {flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,paddingHorizontal:S.base,paddingVertical:S.xs,borderBottomWidth:1,borderBottomColor:C.border},
  search:       {flex:1,color:C.t1,fontSize:F.md,height:44},
  studentCard:  {flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.card,borderRadius:R.xl,padding:S.md,borderWidth:1,borderColor:C.border},
  avatar:       {width:48,height:48,borderRadius:12,justifyContent:'center',alignItems:'center'},
  avatarTxt:    {color:C.t1,fontWeight:'900',fontSize:18},
  studentName:  {color:C.t1,fontWeight:'700',fontSize:F.md},
  studentEmail: {color:C.t2,fontSize:12},
  metaRow:      {flexDirection:'row',alignItems:'center',gap:6},
  statusBadge:  {paddingHorizontal:8,paddingVertical:2,borderRadius:10},
  statusTxt:    {fontSize:11,fontWeight:'700'},
  batchTag:     {color:C.t3,fontSize:11},
  progress:     {color:C.gold,fontWeight:'900',fontSize:F.base},
  progressLabel:{color:C.t3,fontSize:10},
});
const m = StyleSheet.create({
  overlay:    {flex:1,backgroundColor:'rgba(0,0,0,0.75)',justifyContent:'flex-end'},
  card:       {backgroundColor:C.card,borderTopLeftRadius:26,borderTopRightRadius:26,padding:S.xl,borderWidth:1,borderColor:C.border},
  mHeader:    {flexDirection:'row',alignItems:'center',gap:12,marginBottom:S.lg},
  mAvatar:    {width:56,height:56,borderRadius:16,justifyContent:'center',alignItems:'center'},
  mAvatarTxt: {color:C.inv,fontWeight:'900',fontSize:22},
  mName:      {color:C.t1,fontWeight:'800',fontSize:F.base},
  mEmail:     {color:C.t2,fontSize:F.sm},
  mPhone:     {color:C.t3,fontSize:12},
  statsGrid:  {flexDirection:'row',flexWrap:'wrap',gap:10,marginBottom:S.lg},
  statItem:   {width:'47%',backgroundColor:C.surface,borderRadius:R.md,padding:S.md,borderWidth:1,borderColor:C.border},
  statLabel:  {color:C.t3,fontSize:11,marginBottom:4},
  statVal:    {color:C.t1,fontWeight:'800',fontSize:F.base},
  actionRow:  {flexDirection:'row',gap:10},
  actionBtn:  {flex:1,flexDirection:'row',alignItems:'center',justifyContent:'center',gap:6,borderRadius:R.md,paddingVertical:13,borderWidth:1},
  actionTxt:  {fontWeight:'700',fontSize:F.md},
});
