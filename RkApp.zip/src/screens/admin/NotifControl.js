// src/screens/admin/NotifControl.js
export { NotifControl as default } from './LiveControl';
