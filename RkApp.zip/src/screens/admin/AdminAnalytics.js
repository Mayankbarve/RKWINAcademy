// src/screens/admin/AdminAnalytics.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const TOP_PERFORMERS = [
  { name:'Priya Patel',  score:96, batch:'JEE 2025',  streak:28 },
  { name:'Rohan Verma',  score:92, batch:'JEE 2025',  streak:22 },
  { name:'Divya Nair',   score:89, batch:'NEET 2025', streak:18 },
  { name:'Arjun Sharma', score:84, batch:'JEE 2025',  streak:15 },
];
const AT_RISK = [
  { name:'Ananya Singh', attendance:42, lastSeen:'8 days ago',  batch:'JEE 2025' },
  { name:'Karan Mehta',  attendance:38, lastSeen:'12 days ago', batch:'Board'    },
];

export default function AdminAnalytics() {
  const [period, setPeriod] = useState('month');

  const kpis = [
    { icon:'people',      label:'Total Students', val:'1,800',    sub:'+47 this week',       color:C.cyan   },
    { icon:'trending-up', label:'Avg Attendance',  val:'78%',      sub:'+3% vs last month',  color:C.green  },
    { icon:'bar-chart',   label:'Avg Test Score',  val:'71%',      sub:'All batches',         color:C.gold   },
    { icon:'card',        label:'Revenue',          val:'₹1.84L',   sub:'This month',          color:C.purple },
  ];

  const batchPerf = [
    { batch:'JEE Mains 2025',  attendance:82, avgScore:74, enrolled:342,  color:C.gold   },
    { batch:'NEET 2025',       attendance:76, avgScore:69, enrolled:218,  color:C.green  },
    { batch:'Class 12 Board',  attendance:71, avgScore:65, enrolled:1240, color:C.cyan   },
  ];

  return (
    <View style={{ flex:1, backgroundColor:C.bg }}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <Text style={s.title}>Analytics</Text>
        <View style={s.periodRow}>
          {['week','month','year'].map(p=>(
            <TouchableOpacity key={p} style={[s.periodBtn,period===p&&s.periodBtnA]} onPress={()=>setPeriod(p)}>
              <Text style={[s.periodTxt,period===p&&s.periodTxtA]}>{p.charAt(0).toUpperCase()+p.slice(1)}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{padding:S.base,gap:14,paddingBottom:40}}>
        <View style={s.kpiGrid}>
          {kpis.map((k,i)=>(
            <View key={i} style={[s.kpiCard,{borderColor:C.border}]}>
              <LinearGradient colors={[`${k.color}20`,`${k.color}05`]} style={s.kpiInner}>
                <View style={[s.kpiIcon,{backgroundColor:`${k.color}28`}]}><Ionicons name={k.icon} size={19} color={k.color}/></View>
                <Text style={[s.kpiVal,{color:k.color}]}>{k.val}</Text>
                <Text style={s.kpiLabel}>{k.label}</Text>
                <Text style={s.kpiSub}>{k.sub}</Text>
              </LinearGradient>
            </View>
          ))}
        </View>

        <Text style={s.sectionTitle}>Batch Performance</Text>
        <View style={s.card}>
          {batchPerf.map((b,i)=>(
            <View key={i} style={[s.batchRow,i>0&&{borderTopWidth:1,borderTopColor:C.border,paddingTop:S.md}]}>
              <View style={[s.batchDot,{backgroundColor:b.color}]}/>
              <View style={{flex:1}}>
                <Text style={s.batchName}>{b.batch}</Text>
                <Text style={s.batchEnrolled}>{b.enrolled} students</Text>
              </View>
              <View style={s.batchStats}>
                {[{val:`${b.attendance}%`,lbl:'Att.'},{val:`${b.avgScore}%`,lbl:'Score'}].map((st2,j)=>(
                  <View key={j} style={{alignItems:'center'}}>
                    <Text style={[s.batchStatVal,{color:b.color}]}>{st2.val}</Text>
                    <Text style={s.batchStatLbl}>{st2.lbl}</Text>
                  </View>
                ))}
              </View>
            </View>
          ))}
        </View>

        <Text style={s.sectionTitle}>🏆 Top Performers</Text>
        <View style={s.card}>
          {TOP_PERFORMERS.map((p,i)=>(
            <View key={i} style={[s.perfRow,i>0&&{borderTopWidth:1,borderTopColor:C.border,paddingTop:S.md}]}>
              <View style={[s.perfRank,i===0&&{backgroundColor:'rgba(255,215,0,0.15)'}]}>
                <Text style={[s.perfRankTxt,i===0&&{color:'#FFD700'}]}>#{i+1}</Text>
              </View>
              <LinearGradient colors={[C.surface,C.card2]} style={s.perfAvatar}>
                <Text style={s.perfAvatarTxt}>{p.name[0]}</Text>
              </LinearGradient>
              <View style={{flex:1}}>
                <Text style={s.perfName}>{p.name}</Text>
                <Text style={s.perfMeta}>{p.batch} · 🔥{p.streak}d</Text>
              </View>
              <Text style={[s.perfScore,{color:p.score>=90?C.green:C.gold}]}>{p.score}%</Text>
            </View>
          ))}
        </View>

        <Text style={s.sectionTitle}>⚠️ At-Risk Students</Text>
        <View style={s.card}>
          {AT_RISK.map((st2,i)=>(
            <View key={i} style={[s.riskRow,i>0&&{borderTopWidth:1,borderTopColor:C.border,paddingTop:S.md}]}>
              <View style={s.riskAvatar}><Text style={s.riskAvatarTxt}>{st2.name[0]}</Text></View>
              <View style={{flex:1}}>
                <Text style={s.riskName}>{st2.name}</Text>
                <Text style={s.riskMeta}>{st2.batch} · Last seen {st2.lastSeen}</Text>
              </View>
              <View style={s.riskBadge}><Text style={s.riskBadgeTxt}>{st2.attendance}% att.</Text></View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  header:       {paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg,gap:12},
  title:        {color:C.t1,fontSize:F.x2,fontWeight:'900'},
  periodRow:    {flexDirection:'row',gap:8},
  periodBtn:    {flex:1,paddingVertical:8,borderRadius:R.sm,backgroundColor:C.surface,alignItems:'center',borderWidth:1,borderColor:C.border},
  periodBtnA:   {backgroundColor:`${C.gold}18`,borderColor:C.gold},
  periodTxt:    {color:C.t3,fontSize:F.sm,fontWeight:'600'},
  periodTxtA:   {color:C.gold},
  kpiGrid:      {flexDirection:'row',flexWrap:'wrap',gap:10},
  kpiCard:      {width:'47.5%',borderRadius:R.lg,overflow:'hidden',borderWidth:1,backgroundColor:C.card},
  kpiInner:     {padding:S.md,gap:5,borderRadius:R.lg},
  kpiIcon:      {width:40,height:40,borderRadius:10,justifyContent:'center',alignItems:'center'},
  kpiVal:       {fontSize:F.xl,fontWeight:'900'},
  kpiLabel:     {color:C.t2,fontSize:12,fontWeight:'600'},
  kpiSub:       {color:C.t3,fontSize:10},
  sectionTitle: {color:C.t1,fontSize:F.base,fontWeight:'800'},
  card:         {backgroundColor:C.card,borderRadius:R.xl,padding:S.lg,borderWidth:1,borderColor:C.border,gap:14},
  batchRow:     {flexDirection:'row',alignItems:'center',gap:10},
  batchDot:     {width:12,height:12,borderRadius:6},
  batchName:    {color:C.t1,fontWeight:'700',fontSize:F.sm},
  batchEnrolled:{color:C.t3,fontSize:11},
  batchStats:   {flexDirection:'row',gap:16},
  batchStatVal: {fontWeight:'800',fontSize:F.base},
  batchStatLbl: {color:C.t3,fontSize:10},
  perfRow:      {flexDirection:'row',alignItems:'center',gap:10},
  perfRank:     {width:30,height:30,borderRadius:8,backgroundColor:C.surface,justifyContent:'center',alignItems:'center'},
  perfRankTxt:  {color:C.t2,fontWeight:'800',fontSize:F.sm},
  perfAvatar:   {width:40,height:40,borderRadius:10,justifyContent:'center',alignItems:'center'},
  perfAvatarTxt:{color:C.t1,fontWeight:'800',fontSize:F.base},
  perfName:     {color:C.t1,fontWeight:'700',fontSize:F.md},
  perfMeta:     {color:C.t3,fontSize:11},
  perfScore:    {fontWeight:'900',fontSize:F.base},
  riskRow:      {flexDirection:'row',alignItems:'center',gap:10},
  riskAvatar:   {width:40,height:40,borderRadius:10,backgroundColor:`${C.yellow}18`,justifyContent:'center',alignItems:'center'},
  riskAvatarTxt:{color:C.yellow,fontWeight:'800',fontSize:F.base},
  riskName:     {color:C.t1,fontWeight:'700',fontSize:F.md},
  riskMeta:     {color:C.t3,fontSize:11},
  riskBadge:    {backgroundColor:`${C.red}18`,paddingHorizontal:8,paddingVertical:4,borderRadius:8},
  riskBadgeTxt: {color:C.red,fontWeight:'700',fontSize:12},
});
