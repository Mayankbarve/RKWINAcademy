// src/screens/admin/BatchManagement.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Modal, Alert, Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn } from '../../components/UI';

export default function BatchManagement({ navigation }) {
  const { batches } = useApp();
  const [search,     setSearch]     = useState('');
  const [showModal,  setShowModal]  = useState(false);
  const [editBatch,  setEditBatch]  = useState(null);
  const [form, setForm] = useState({ name:'', subject:'', price:'', isFree:false, maxStudents:'500' });

  const filtered = batches.filter(b =>
    b.name.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditBatch(null);
    setForm({ name:'', subject:'', price:'', isFree:false, maxStudents:'500' });
    setShowModal(true);
  };

  const openEdit = (b) => {
    setEditBatch(b);
    setForm({ name:b.name, subject:b.subject, price:String(b.price), isFree:b.isFree, maxStudents:String(b.maxStudents) });
    setShowModal(true);
  };

  const handleDelete = (b) =>
    Alert.alert('Delete Batch', `Delete "${b.name}"? This cannot be undone.`, [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress:() => Alert.alert('Deleted (demo)') },
    ]);

  const handleSave = () => {
    if (!form.name.trim()) { Alert.alert('Error','Batch name is required'); return; }
    Alert.alert('Saved', `Batch "${form.name}" ${editBatch ? 'updated' : 'created'} (demo)`);
    setShowModal(false);
  };

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <View style={s.headerRow}>
          <Text style={s.title}>Batch Management</Text>
          <TouchableOpacity style={s.createBtn} onPress={openCreate}>
            <LinearGradient colors={C.gGold} style={s.createBtnGrad}>
              <Ionicons name="add" size={18} color={C.inv} />
              <Text style={s.createBtnTxt}>New Batch</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={s.statsRow}>
          {[
            { label:'Total',    val: batches.length,                           color:C.gold  },
            { label:'Active',   val: batches.filter(b=>b.isActive).length,     color:C.green },
            { label:'Free',     val: batches.filter(b=>b.isFree).length,       color:C.cyan  },
          ].map((st, i) => (
            <View key={i} style={s.statItem}>
              <Text style={[s.statVal, {color:st.color}]}>{st.val}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>
      </LinearGradient>

      {/* Search */}
      <View style={s.searchWrap}>
        <Ionicons name="search" size={15} color={C.t3} />
        <TextInput
          style={s.search}
          placeholder="Search batches…"
          placeholderTextColor={C.t3}
          value={search}
          onChangeText={setSearch}
          selectionColor={C.gold}
        />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.list}>
        {filtered.map(b => (
          <View key={b.id} style={s.batchRow}>
            <LinearGradient colors={C.gGold} style={s.batchIcon}>
              <Text style={s.batchIconTxt}>{b.name.slice(0,2).toUpperCase()}</Text>
            </LinearGradient>
            <View style={s.batchInfo}>
              <Text style={s.batchName} numberOfLines={1}>{b.name}</Text>
              <Text style={s.batchMeta}>{b.totalStudents} students · {b.isFree?'Free':`₹${b.price}`}</Text>
              <View style={[s.statusBadge, b.isActive?s.statusActive:s.statusInactive]}>
                <View style={[s.statusDot,{backgroundColor:b.isActive?C.green:C.t3}]}/>
                <Text style={[s.statusTxt,{color:b.isActive?C.green:C.t3}]}>{b.isActive?'Active':'Inactive'}</Text>
              </View>
            </View>
            <View style={s.actions}>
              <TouchableOpacity style={s.actionBtn}
                onPress={() => navigation.navigate('ContentMgmt',{batchId:b.id})}>
                <Ionicons name="folder-open" size={15} color={C.cyan} />
              </TouchableOpacity>
              <TouchableOpacity style={s.actionBtn} onPress={()=>openEdit(b)}>
                <Ionicons name="create-outline" size={15} color={C.gold} />
              </TouchableOpacity>
              <TouchableOpacity style={[s.actionBtn,s.deleteBtn]} onPress={()=>handleDelete(b)}>
                <Ionicons name="trash-outline" size={15} color={C.red} />
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>

      {/* Create / Edit Modal */}
      <Modal visible={showModal} animationType="slide" transparent>
        <View style={m.overlay}>
          <View style={m.card}>
            <View style={m.mHeader}>
              <Text style={m.mTitle}>{editBatch?'Edit Batch':'Create New Batch'}</Text>
              <TouchableOpacity onPress={()=>setShowModal(false)}>
                <Ionicons name="close" size={22} color={C.t1} />
              </TouchableOpacity>
            </View>

            <ScrollView showsVerticalScrollIndicator={false} style={{maxHeight:360}}>
              {[
                { label:'Batch Name *', key:'name',        ph:'e.g. JEE Mains 2025',       kb:'default' },
                { label:'Subjects',    key:'subject',      ph:'e.g. Physics + Maths',       kb:'default' },
                { label:'Max Students',key:'maxStudents',  ph:'500',                         kb:'numeric' },
              ].map(f => (
                <View key={f.key} style={m.formGroup}>
                  <Text style={m.formLabel}>{f.label}</Text>
                  <TextInput
                    style={m.formInput}
                    placeholder={f.ph}
                    placeholderTextColor={C.t3}
                    value={form[f.key]}
                    onChangeText={v=>setForm(p=>({...p,[f.key]:v}))}
                    keyboardType={f.kb}
                    selectionColor={C.gold}
                  />
                </View>
              ))}

              <View style={m.toggleRow}>
                <Text style={m.formLabel}>Free Batch</Text>
                <Switch
                  value={form.isFree}
                  onValueChange={v=>setForm(p=>({...p,isFree:v}))}
                  trackColor={{false:C.surface,true:`${C.green}55`}}
                  thumbColor={form.isFree?C.green:C.t3}
                />
              </View>

              {!form.isFree && (
                <View style={m.formGroup}>
                  <Text style={m.formLabel}>Price (₹)</Text>
                  <TextInput
                    style={m.formInput}
                    placeholder="4999"
                    placeholderTextColor={C.t3}
                    value={form.price}
                    onChangeText={v=>setForm(p=>({...p,price:v}))}
                    keyboardType="numeric"
                    selectionColor={C.gold}
                  />
                </View>
              )}
            </ScrollView>

            <GradBtn
              label={editBatch?'Update Batch':'Create Batch'}
              onPress={handleSave}
              style={{marginTop:S.md}}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  root:         { flex:1, backgroundColor:C.bg },
  header:       { paddingTop:52, paddingHorizontal:S.base, paddingBottom:S.lg, gap:14 },
  headerRow:    { flexDirection:'row', justifyContent:'space-between', alignItems:'center' },
  title:        { color:C.t1, fontSize:F.x2, fontWeight:'900' },
  createBtn:    { borderRadius:R.md, overflow:'hidden' },
  createBtnGrad:{ flexDirection:'row', alignItems:'center', gap:4, paddingVertical:9, paddingHorizontal:12 },
  createBtnTxt: { color:C.inv, fontWeight:'800', fontSize:F.sm },
  statsRow:     { flexDirection:'row', backgroundColor:C.card, borderRadius:R.lg, padding:S.md, borderWidth:1, borderColor:C.border, justifyContent:'space-around' },
  statItem:     { alignItems:'center', gap:2 },
  statVal:      { fontWeight:'900', fontSize:F.xl },
  statLabel:    { color:C.t3, fontSize:11 },
  searchWrap:   { flexDirection:'row', alignItems:'center', gap:10, backgroundColor:C.card, paddingHorizontal:S.base, paddingVertical:S.xs, borderBottomWidth:1, borderBottomColor:C.border },
  search:       { flex:1, color:C.t1, fontSize:F.md, height:44 },
  list:         { padding:S.base, gap:12 },
  batchRow:     { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:C.card, borderRadius:R.xl, padding:S.md, borderWidth:1, borderColor:C.border },
  batchIcon:    { width:52, height:52, borderRadius:14, justifyContent:'center', alignItems:'center' },
  batchIconTxt: { color:C.inv, fontWeight:'900', fontSize:18 },
  batchInfo:    { flex:1, gap:4 },
  batchName:    { color:C.t1, fontWeight:'700', fontSize:F.md },
  batchMeta:    { color:C.t2, fontSize:12 },
  statusBadge:  { flexDirection:'row', alignItems:'center', gap:4, alignSelf:'flex-start', paddingHorizontal:8, paddingVertical:3, borderRadius:20 },
  statusActive: { backgroundColor:`${C.green}18` },
  statusInactive:{ backgroundColor:C.surface },
  statusDot:    { width:6, height:6, borderRadius:3 },
  statusTxt:    { fontSize:11, fontWeight:'700' },
  actions:      { flexDirection:'row', gap:6 },
  actionBtn:    { width:34, height:34, borderRadius:8, backgroundColor:C.surface, justifyContent:'center', alignItems:'center', borderWidth:1, borderColor:C.border },
  deleteBtn:    { backgroundColor:`${C.red}12`, borderColor:`${C.red}28` },
});
const m = StyleSheet.create({
  overlay:    { flex:1, backgroundColor:'rgba(0,0,0,0.72)', justifyContent:'flex-end' },
  card:       { backgroundColor:C.card, borderTopLeftRadius:26, borderTopRightRadius:26, padding:S.xl, borderWidth:1, borderColor:C.border },
  mHeader:    { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:S.lg },
  mTitle:     { color:C.t1, fontSize:F.xl, fontWeight:'900' },
  formGroup:  { marginBottom:S.md },
  formLabel:  { color:C.t2, fontSize:F.sm, fontWeight:'600', marginBottom:6 },
  formInput:  { backgroundColor:C.surface, borderRadius:R.md, paddingHorizontal:S.md, height:50, color:C.t1, fontSize:F.md, borderWidth:1, borderColor:C.border },
  toggleRow:  { flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:S.md },
});
