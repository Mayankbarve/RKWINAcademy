// src/screens/student/ProfileScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Switch } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useApp  } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

export default function ProfileScreen({ navigation }) {
  const { user, signOut } = useAuth();
  const { analytics }     = useApp();
  const [notif, setNotif] = useState(true);

  const doSignOut = () =>
    Alert.alert('Sign Out','Are you sure?',[
      { text:'Cancel',style:'cancel' },
      { text:'Sign Out',style:'destructive', onPress:signOut },
    ]);

  const menu = [
    { title:'Learning', items:[
      { icon:'time',        label:'Watch History',  color:C.cyan,   onPress:()=>navigation.navigate('WatchHistory')  },
      { icon:'calendar',    label:'Timetable',      color:C.gold,   onPress:()=>navigation.navigate('Timetable')     },
      { icon:'trophy',      label:'Leaderboard',    color:'#FFD600',onPress:()=>navigation.getParent()?.navigate('Rank') },
      { icon:'cloud-upload',label:'My Submissions', color:C.green,  onPress:()=>{}                                   },
    ]},
    { title:'Account', items:[
      { icon:'lock-closed', label:'Change Password',color:C.yellow, onPress:()=>{}             },
      { icon:'card',        label:'Subscriptions',  color:C.purple, onPress:()=>{}             },
      { icon:'help-circle', label:'Help & Support', color:C.cyan,   onPress:()=>{}             },
      { icon:'document-text',label:'Privacy Policy',color:C.t3,    onPress:()=>{}             },
    ]},
  ];

  return (
    <View style={s.root}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
          <View style={s.avatarRow}>
            <LinearGradient colors={C.gGold} style={s.avatar}>
              <Text style={s.avatarTxt}>{user?.name?.[0]||'S'}</Text>
            </LinearGradient>
            <View>
              <Text style={s.name}>{user?.name}</Text>
              <Text style={s.email}>{user?.email}</Text>
              {user?.phone && <Text style={s.phone}>{user.phone}</Text>}
            </View>
          </View>

          <View style={s.statsRow}>
            {[
              {label:'Streak',     val:`${analytics.streak}d`,       icon:'flame',    color:C.gold  },
              {label:'Tests',      val:analytics.testsAttempted,      icon:'clipboard',color:C.cyan  },
              {label:'Attendance', val:`${analytics.attendancePercent}%`, icon:'calendar',color:C.green },
              {label:'Rank',       val:`#${user?.rank||'—'}`,         icon:'trophy',   color:'#FFD600'},
            ].map((st2,i)=>(
              <View key={i} style={s.statItem}>
                <Ionicons name={st2.icon} size={15} color={st2.color}/>
                <Text style={[s.statVal,{color:st2.color}]}>{st2.val}</Text>
                <Text style={s.statLbl}>{st2.label}</Text>
              </View>
            ))}
          </View>
        </LinearGradient>

        <View style={s.body}>
          {/* Notification toggle */}
          <View style={s.card}>
            <Text style={s.sectionTitle}>Preferences</Text>
            <View style={s.toggleRow}>
              <View style={[s.toggleIcon,{backgroundColor:`${C.gold}18`}]}>
                <Ionicons name="notifications" size={18} color={C.gold}/>
              </View>
              <View style={{flex:1}}>
                <Text style={s.toggleLabel}>Push Notifications</Text>
                <Text style={s.toggleSub}>Class reminders & alerts</Text>
              </View>
              <Switch value={notif} onValueChange={setNotif}
                trackColor={{false:C.surface,true:`${C.gold}55`}}
                thumbColor={notif?C.gold:C.t3}/>
            </View>
          </View>

          {menu.map((sec,si)=>(
            <View key={si} style={s.card}>
              <Text style={s.sectionTitle}>{sec.title}</Text>
              {sec.items.map((item,ii)=>(
                <TouchableOpacity key={ii}
                  style={[s.menuItem, ii<sec.items.length-1&&s.menuItemBorder]}
                  onPress={item.onPress} activeOpacity={0.75}
                >
                  <View style={[s.menuIcon,{backgroundColor:`${item.color}18`}]}>
                    <Ionicons name={item.icon} size={17} color={item.color}/>
                  </View>
                  <Text style={s.menuLabel}>{item.label}</Text>
                  <Ionicons name="chevron-forward" size={15} color={C.t3}/>
                </TouchableOpacity>
              ))}
            </View>
          ))}

          <View style={s.versionWrap}>
            <LinearGradient colors={C.gGold} style={s.versionLogo}>
              <Text style={s.versionLogoTxt}>RK</Text>
            </LinearGradient>
            <Text style={s.versionApp}>RK WIN Academy</Text>
            <Text style={s.versionNum}>Version 1.0.0</Text>
          </View>

          <TouchableOpacity style={s.signOutBtn} onPress={doSignOut} activeOpacity={0.8}>
            <Ionicons name="log-out-outline" size={20} color={C.red}/>
            <Text style={s.signOutTxt}>Sign Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:        {flex:1,backgroundColor:C.bg},
  header:      {paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.xl,gap:16},
  avatarRow:   {flexDirection:'row',alignItems:'center',gap:16},
  avatar:      {width:70,height:70,borderRadius:20,justifyContent:'center',alignItems:'center'},
  avatarTxt:   {color:C.inv,fontWeight:'900',fontSize:30},
  name:        {color:C.t1,fontSize:F.xl,fontWeight:'900'},
  email:       {color:C.t2,fontSize:F.sm,marginTop:2},
  phone:       {color:C.t3,fontSize:12,marginTop:1},
  statsRow:    {flexDirection:'row',backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border,justifyContent:'space-between'},
  statItem:    {alignItems:'center',gap:3,flex:1},
  statVal:     {fontWeight:'900',fontSize:F.base},
  statLbl:     {color:C.t3,fontSize:10},
  body:        {padding:S.base,gap:14,paddingBottom:S.x4},
  sectionTitle:{color:C.t1,fontSize:F.md,fontWeight:'800',marginBottom:S.md},
  card:        {backgroundColor:C.card,borderRadius:R.xl,padding:S.lg,borderWidth:1,borderColor:C.border},
  toggleRow:   {flexDirection:'row',alignItems:'center',gap:12},
  toggleIcon:  {width:40,height:40,borderRadius:10,justifyContent:'center',alignItems:'center'},
  toggleLabel: {color:C.t1,fontWeight:'600',fontSize:F.md},
  toggleSub:   {color:C.t3,fontSize:11,marginTop:2},
  menuItem:    {flexDirection:'row',alignItems:'center',gap:12,paddingVertical:S.md},
  menuItemBorder:{borderBottomWidth:1,borderBottomColor:C.border},
  menuIcon:    {width:38,height:38,borderRadius:10,justifyContent:'center',alignItems:'center'},
  menuLabel:   {flex:1,color:C.t1,fontWeight:'600',fontSize:F.md},
  versionWrap: {alignItems:'center',gap:8,paddingVertical:S.lg},
  versionLogo: {width:52,height:52,borderRadius:14,justifyContent:'center',alignItems:'center'},
  versionLogoTxt:{color:C.inv,fontWeight:'900',fontSize:22},
  versionApp:  {color:C.t2,fontSize:F.md,fontWeight:'700'},
  versionNum:  {color:C.t3,fontSize:12},
  signOutBtn:  {flexDirection:'row',alignItems:'center',justifyContent:'center',gap:10,backgroundColor:`${C.red}12`,borderRadius:R.lg,paddingVertical:16,borderWidth:1,borderColor:`${C.red}28`},
  signOutTxt:  {color:C.red,fontWeight:'800',fontSize:F.base},
});
