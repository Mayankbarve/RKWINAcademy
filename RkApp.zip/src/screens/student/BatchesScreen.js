// src/screens/student/BatchesScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useApp  } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { Badge, EmptyState } from '../../components/UI';

function BatchCard({ batch, enrolled, onPress }) {
  const disc = batch.originalPrice > batch.price
    ? Math.round((1 - batch.price / batch.originalPrice) * 100) : 0;
  return (
    <TouchableOpacity style={bc.card} onPress={onPress} activeOpacity={0.87}>
      <LinearGradient
        colors={enrolled ? [C.gold, C.goldDark] : [C.surface, C.card2]}
        style={bc.thumb}
      >
        <Text style={bc.thumbTxt}>{batch.name.slice(0,2).toUpperCase()}</Text>
        {enrolled && (
          <View style={bc.enrolledBadge}>
            <Ionicons name="checkmark-circle" size={14} color={C.green} />
            <Text style={bc.enrolledBadgeTxt}>Enrolled</Text>
          </View>
        )}
        {batch.isFree && !enrolled && (
          <View style={[bc.enrolledBadge, { backgroundColor: `${C.green}20` }]}>
            <Text style={[bc.enrolledBadgeTxt, { color: C.green }]}>FREE</Text>
          </View>
        )}
      </LinearGradient>
      <View style={bc.info}>
        <Text style={bc.name} numberOfLines={2}>{batch.name}</Text>
        <Text style={bc.subj} numberOfLines={1}>{batch.subject}</Text>
        <View style={bc.meta}>
          {[
            { icon: 'play-circle-outline', val: `${batch.videos}` },
            { icon: 'document-text-outline', val: `${batch.tests} tests` },
            { icon: 'people-outline', val: `${batch.totalStudents}` },
          ].map((m, i) => (
            <View key={i} style={bc.metaItem}>
              <Ionicons name={m.icon} size={11} color={C.t3} />
              <Text style={bc.metaTxt}>{m.val}</Text>
            </View>
          ))}
        </View>
        {enrolled ? (
          <View style={bc.continueBtn}>
            <Text style={bc.continueTxt}>Continue Learning →</Text>
          </View>
        ) : (
          <View style={bc.priceRow}>
            {batch.isFree
              ? <Text style={bc.freeText}>Free Enrollment</Text>
              : <>
                  <Text style={bc.price}>₹{batch.price.toLocaleString()}</Text>
                  {disc > 0 && (
                    <>
                      <Text style={bc.origPrice}>₹{batch.originalPrice.toLocaleString()}</Text>
                      <View style={bc.discBadge}><Text style={bc.discTxt}>{disc}% OFF</Text></View>
                    </>
                  )}
                </>
            }
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}

export default function BatchesScreen({ navigation }) {
  const { user } = useAuth();
  const { getEnrolledBatches, getAvailableBatches } = useApp();
  const [tab,    setTab]    = useState('enrolled');
  const [search, setSearch] = useState('');

  const enrolled  = getEnrolledBatches(user?.enrolledBatches || []);
  const available = getAvailableBatches(user?.enrolledBatches || []);
  const list = (tab === 'enrolled' ? enrolled : available)
    .filter(b => b.name.toLowerCase().includes(search.toLowerCase()) ||
                 b.subject.toLowerCase().includes(search.toLowerCase()));

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <Text style={s.title}>My Batches</Text>
        <View style={s.searchWrap}>
          <Ionicons name="search" size={15} color={C.t3} />
          <TextInput style={s.search} placeholder="Search batches…" placeholderTextColor={C.t3}
            value={search} onChangeText={setSearch} selectionColor={C.gold} />
        </View>
        <View style={s.tabs}>
          {[
            { key: 'enrolled',  label: 'My Batches', count: enrolled.length  },
            { key: 'available', label: 'Explore',    count: available.length },
          ].map(t => (
            <TouchableOpacity key={t.key}
              style={[s.tabBtn, tab === t.key && s.tabBtnA]}
              onPress={() => setTab(t.key)}
            >
              <Text style={[s.tabTxt, tab === t.key && s.tabTxtA]}>{t.label}</Text>
              <View style={[s.tabCount, tab === t.key && s.tabCountA]}>
                <Text style={[s.tabCountTxt, tab === t.key && { color: C.gold }]}>{t.count}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>
        {list.length === 0
          ? <EmptyState icon="book-outline"
              title={tab === 'enrolled' ? 'No Batches Enrolled' : 'No Batches Available'}
              subtitle={tab === 'enrolled' ? 'Switch to Explore tab to enroll in a batch' : 'Check back soon for new batches'} />
          : list.map(b => (
              <BatchCard key={b.id} batch={b} enrolled={tab === 'enrolled'}
                onPress={() => navigation.navigate('BatchDetail', { batchId: b.id, isEnrolled: tab === 'enrolled' })} />
            ))
        }
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:       { flex: 1, backgroundColor: C.bg },
  header:     { paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.lg, gap: 12 },
  title:      { color: C.t1, fontSize: F.x2, fontWeight: '900' },
  searchWrap: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.surface, borderRadius: R.md, paddingHorizontal: S.md, height: 46, borderWidth: 1, borderColor: C.border },
  search:     { flex: 1, color: C.t1, fontSize: F.md },
  tabs:       { flexDirection: 'row', gap: 8 },
  tabBtn:     { flexDirection: 'row', alignItems: 'center', gap: 7, paddingVertical: 8, paddingHorizontal: 14, borderRadius: R.full, backgroundColor: C.surface, borderWidth: 1, borderColor: C.border },
  tabBtnA:    { backgroundColor: `${C.gold}18`, borderColor: C.gold },
  tabTxt:     { color: C.t3, fontWeight: '600', fontSize: F.sm },
  tabTxtA:    { color: C.gold },
  tabCount:   { backgroundColor: C.border, paddingHorizontal: 6, paddingVertical: 1, borderRadius: 8 },
  tabCountA:  { backgroundColor: `${C.gold}28` },
  tabCountTxt:{ color: C.t3, fontSize: 11, fontWeight: '700' },
  scroll:     { padding: S.base, gap: 12 },
});

const bc = StyleSheet.create({
  card:         { flexDirection: 'row', backgroundColor: C.card, borderRadius: R.xl, overflow: 'hidden', borderWidth: 1, borderColor: C.border },
  thumb:        { width: 118, alignItems: 'center', justifyContent: 'center', gap: 7, padding: S.sm },
  thumbTxt:     { color: C.inv, fontSize: 26, fontWeight: '900' },
  enrolledBadge:{ flexDirection: 'row', alignItems: 'center', gap: 3, backgroundColor: `${C.green}20`, paddingHorizontal: 7, paddingVertical: 3, borderRadius: 10 },
  enrolledBadgeTxt:{ color: C.green, fontSize: 10, fontWeight: '700' },
  info:         { flex: 1, padding: S.md, gap: 5 },
  name:         { color: C.t1, fontWeight: '800', fontSize: F.md, lineHeight: 20 },
  subj:         { color: C.t2, fontSize: 12 },
  meta:         { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  metaItem:     { flexDirection: 'row', alignItems: 'center', gap: 3 },
  metaTxt:      { color: C.t3, fontSize: 11 },
  continueBtn:  { backgroundColor: `${C.gold}18`, borderRadius: R.sm, paddingVertical: 6, paddingHorizontal: 10, alignSelf: 'flex-start', borderWidth: 1, borderColor: `${C.gold}35` },
  continueTxt:  { color: C.gold, fontWeight: '700', fontSize: 12 },
  priceRow:     { flexDirection: 'row', alignItems: 'center', gap: 5 },
  price:        { color: C.gold, fontWeight: '900', fontSize: F.base },
  origPrice:    { color: C.t3, fontSize: F.sm, textDecorationLine: 'line-through' },
  discBadge:    { backgroundColor: `${C.green}20`, paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5 },
  discTxt:      { color: C.green, fontSize: 10, fontWeight: '800' },
  freeText:     { color: C.green, fontWeight: '800', fontSize: F.md },
});
