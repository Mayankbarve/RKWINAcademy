// src/screens/student/BatchDetailScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn, OutlineBtn } from '../../components/UI';

export default function BatchDetailScreen({ route, navigation }) {
  const { batchId, isEnrolled } = route.params;
  const { batches, getBatchChapters } = useApp();
  const [subjFilter, setSubjFilter] = useState('All');

  const batch    = batches.find(b => b.id === batchId);
  const chapters = getBatchChapters(batchId);
  if (!batch) return null;

  const subjects = ['All', ...new Set(chapters.map(c => c.subject))];
  const filtered = subjFilter === 'All' ? chapters : chapters.filter(c => c.subject === subjFilter);
  const totalProgress = chapters.length
    ? Math.round(chapters.reduce((a, c) => a + c.completionPercent, 0) / chapters.length) : 0;

  return (
    <View style={s.root}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <LinearGradient colors={['#0F1220','#08090F']} style={s.hero}>
          <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color={C.t1} />
          </TouchableOpacity>
          <LinearGradient colors={C.gGold} style={s.heroIcon}>
            <Text style={s.heroIconTxt}>{batch.name.slice(0,2).toUpperCase()}</Text>
          </LinearGradient>
          <Text style={s.heroTitle}>{batch.name}</Text>
          <Text style={s.heroSubj}>{batch.subject}</Text>
          <Text style={s.heroDesc}>{batch.description}</Text>

          <View style={s.statsRow}>
            {[
              { icon:'play-circle', val:batch.videos,   label:'Videos'   },
              { icon:'clipboard',   val:batch.tests,    label:'Tests'    },
              { icon:'library',     val:batch.chapters, label:'Chapters' },
              { icon:'people',      val:batch.totalStudents, label:'Students' },
            ].map((st2, i) => (
              <View key={i} style={s.stat}>
                <Ionicons name={st2.icon} size={15} color={C.gold} />
                <Text style={s.statVal}>{st2.val}</Text>
                <Text style={s.statLbl}>{st2.label}</Text>
              </View>
            ))}
          </View>

          <View style={s.scheduleRow}>
            <Ionicons name="time-outline" size={14} color={C.t2} />
            <Text style={s.scheduleTxt}>{batch.schedule}</Text>
          </View>

          {isEnrolled ? (
            <>
              <View style={s.progressWrap}>
                <View style={{ flexDirection:'row', justifyContent:'space-between' }}>
                  <Text style={s.progLabel}>Overall Progress</Text>
                  <Text style={s.progVal}>{totalProgress}%</Text>
                </View>
                <View style={s.progBg}>
                  <LinearGradient colors={C.gGold} style={[s.progFill,{width:`${totalProgress}%`}]} start={{x:0,y:0}} end={{x:1,y:0}} />
                </View>
              </View>
              <View style={s.actionsRow}>
                <OutlineBtn icon="cloud-upload-outline" label="Submit Project" color={C.cyan}
                  style={{flex:1}} onPress={() => navigation.navigate('ProjectSubmit',{batchId})} />
                <OutlineBtn icon="chatbubble-outline"   label="Ask Doubt"      color={C.green}
                  style={{flex:1}} onPress={() => Alert.alert('Doubts','Doubt feature coming soon!')} />
              </View>
            </>
          ) : (
            <GradBtn
              label={batch.isFree ? 'Enroll Free' : `Enroll — ₹${batch.price.toLocaleString()}`}
              icon="cart"
              onPress={() => Alert.alert('Enroll','Payment integration will be added via Razorpay.')}
            />
          )}
        </LinearGradient>

        <View style={s.content}>
          {/* Subject filter */}
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.filterScroll}>
            {subjects.map(sub => (
              <TouchableOpacity key={sub}
                style={[s.filterBtn, subjFilter === sub && s.filterBtnA]}
                onPress={() => setSubjFilter(sub)}
              >
                <Text style={[s.filterTxt, subjFilter === sub && s.filterTxtA]}>{sub}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={s.sectionTitle}>Course Content ({filtered.length} chapters)</Text>
          {filtered.map((ch, i) => (
            <TouchableOpacity key={ch.id} style={[s.chCard, !ch.isUnlocked && !isEnrolled && s.chLocked]}
              onPress={() => {
                if (!ch.isUnlocked && !isEnrolled) { Alert.alert('Locked','Enroll to access this chapter'); return; }
                navigation.navigate('ChapterDetail', { chapterId: ch.id, batchId });
              }} activeOpacity={0.85}
            >
              <View style={[s.chNum, ch.completionPercent === 100 && s.chNumDone]}>
                {ch.completionPercent === 100
                  ? <Ionicons name="checkmark" size={15} color={C.inv} />
                  : <Text style={s.chNumTxt}>{i+1}</Text>}
              </View>
              <View style={{ flex:1, gap:3 }}>
                <Text style={s.chTitle} numberOfLines={1}>{ch.title}</Text>
                <View style={s.chMeta}>
                  <Text style={s.chMetaTxt}>{ch.videos.length} videos</Text>
                  <Text style={s.chMetaDot}>·</Text>
                  <Text style={s.chMetaTxt}>{ch.notes.length} notes</Text>
                  <Text style={s.chMetaDot}>·</Text>
                  <Text style={s.chMetaTxt}>{ch.tests.length} tests</Text>
                </View>
                {ch.isUnlocked && ch.completionPercent > 0 && (
                  <View style={s.chProgBg}>
                    <View style={[s.chProgFill,{width:`${ch.completionPercent}%`}]} />
                  </View>
                )}
              </View>
              <View style={{flexDirection:'row',alignItems:'center',gap:4}}>
                {ch.completionPercent > 0 && <Text style={s.chPct}>{ch.completionPercent}%</Text>}
                {(!ch.isUnlocked && !isEnrolled)
                  ? <Ionicons name="lock-closed" size={17} color={C.t3} />
                  : <Ionicons name="chevron-forward" size={17} color={C.t3} />}
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:        { flex:1, backgroundColor:C.bg },
  hero:        { padding:S.base, paddingTop:52, gap:12 },
  backBtn:     { width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center' },
  heroIcon:    { width:72,height:72,borderRadius:20,justifyContent:'center',alignItems:'center' },
  heroIconTxt: { color:C.inv,fontSize:28,fontWeight:'900' },
  heroTitle:   { color:C.t1,fontSize:F.x2,fontWeight:'900',lineHeight:32 },
  heroSubj:    { color:C.gold,fontSize:F.md,fontWeight:'600' },
  heroDesc:    { color:C.t2,fontSize:F.sm,lineHeight:20 },
  statsRow:    { flexDirection:'row',justifyContent:'space-between',backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border },
  stat:        { alignItems:'center',gap:3,flex:1 },
  statVal:     { color:C.t1,fontWeight:'900',fontSize:F.base },
  statLbl:     { color:C.t3,fontSize:11 },
  scheduleRow: { flexDirection:'row',alignItems:'center',gap:5 },
  scheduleTxt: { color:C.t2,fontSize:F.sm },
  progressWrap:{ gap:6 },
  progLabel:   { color:C.t2,fontSize:F.sm },
  progVal:     { color:C.gold,fontWeight:'700',fontSize:F.sm },
  progBg:      { height:8,backgroundColor:C.surface,borderRadius:4,overflow:'hidden' },
  progFill:    { height:'100%',borderRadius:4 },
  actionsRow:  { flexDirection:'row',gap:10 },
  content:     { padding:S.base },
  filterScroll:{ marginBottom:S.md },
  filterBtn:   { paddingHorizontal:14,paddingVertical:8,borderRadius:R.full,backgroundColor:C.surface,marginRight:8,borderWidth:1,borderColor:C.border },
  filterBtnA:  { backgroundColor:`${C.gold}18`,borderColor:C.gold },
  filterTxt:   { color:C.t3,fontWeight:'600',fontSize:F.sm },
  filterTxtA:  { color:C.gold },
  sectionTitle:{ color:C.t1,fontSize:F.base,fontWeight:'800',marginBottom:S.md },
  chCard:      { flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,marginBottom:10,borderWidth:1,borderColor:C.border },
  chLocked:    { opacity:0.55 },
  chNum:       { width:34,height:34,borderRadius:9,backgroundColor:C.surface,justifyContent:'center',alignItems:'center' },
  chNumDone:   { backgroundColor:C.green },
  chNumTxt:    { color:C.t1,fontWeight:'800',fontSize:F.md },
  chTitle:     { color:C.t1,fontWeight:'700',fontSize:F.md },
  chMeta:      { flexDirection:'row',alignItems:'center',gap:4 },
  chMetaTxt:   { color:C.t3,fontSize:11 },
  chMetaDot:   { color:C.t3 },
  chProgBg:    { height:3,backgroundColor:C.surface,borderRadius:2,overflow:'hidden',marginTop:2 },
  chProgFill:  { height:'100%',backgroundColor:C.gold,borderRadius:2 },
  chPct:       { color:C.gold,fontSize:12,fontWeight:'700' },
});
