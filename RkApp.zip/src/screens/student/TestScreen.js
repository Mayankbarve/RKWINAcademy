// src/screens/student/TestScreen.js
import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Modal } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { TEST_QUESTIONS } from '../../services/mockData';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

export default function TestScreen({ route, navigation }) {
  const { title = 'Chapter Test' } = route.params || {};
  const [answers,   setAnswers]   = useState({});
  const [current,   setCurrent]   = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [showResult,setShowResult]= useState(false);
  const [timeLeft,  setTimeLeft]  = useState(45 * 60);
  const timerRef = useRef(null);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(timerRef.current); doSubmit(); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timerRef.current);
  }, []);

  const formatTime = s => `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;
  const timerColor = timeLeft < 300 ? C.red : timeLeft < 600 ? C.yellow : C.green;

  const doSubmit = () => {
    clearInterval(timerRef.current);
    setSubmitted(true);
    setShowResult(true);
  };

  const handleSubmit = () => {
    const unanswered = TEST_QUESTIONS.length - Object.keys(answers).length;
    if (unanswered > 0) {
      Alert.alert('Unanswered', `${unanswered} question(s) unanswered. Submit anyway?`,
        [{ text:'Continue', style:'cancel' },{ text:'Submit', onPress:doSubmit }]);
    } else doSubmit();
  };

  const score = () => {
    let correct = 0;
    TEST_QUESTIONS.forEach(q => { if (answers[q.id] === q.correct) correct++; });
    return { correct, total:TEST_QUESTIONS.length, pct:Math.round((correct/TEST_QUESTIONS.length)*100) };
  };

  const q   = TEST_QUESTIONS[current];
  const sc  = submitted ? score() : null;

  return (
    <View style={s.root}>
      {/* Header */}
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <TouchableOpacity style={s.closeBtn} onPress={() => {
          if (!submitted) Alert.alert('Exit?','Progress will be lost.',
            [{ text:'Stay',style:'cancel'},{ text:'Exit',style:'destructive',onPress:()=>navigation.goBack()}]);
          else navigation.goBack();
        }}>
          <Ionicons name="close" size={22} color={C.t1} />
        </TouchableOpacity>
        <View style={{ flex:1 }}>
          <Text style={s.testTitle}>{title}</Text>
          <Text style={s.testSub}>{Object.keys(answers).length}/{TEST_QUESTIONS.length} answered</Text>
        </View>
        <View style={[s.timer, { borderColor:timerColor }]}>
          <Ionicons name="time" size={13} color={timerColor} />
          <Text style={[s.timerTxt,{color:timerColor}]}>{formatTime(timeLeft)}</Text>
        </View>
      </LinearGradient>

      {/* Palette */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.palette}>
        {TEST_QUESTIONS.map((q2,i) => (
          <TouchableOpacity key={q2.id}
            style={[s.paletteBtn,
              answers[q2.id] !== undefined && s.paletteBtnAnswered,
              current===i && s.paletteBtnCurrent,
            ]}
            onPress={() => setCurrent(i)}
          >
            <Text style={[s.paletteBtnTxt,
              answers[q2.id]!==undefined && s.paletteTxtAnswered,
              current===i && s.paletteTxtCurrent,
            ]}>{i+1}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Question */}
      <ScrollView style={{ flex:1 }} showsVerticalScrollIndicator={false}>
        <View style={s.qCard}>
          <View style={s.qNum}><Text style={s.qNumTxt}>Q{current+1}</Text></View>
          <Text style={s.qTxt}>{q.text}</Text>
          <View style={{ gap:10 }}>
            {q.options.map((opt,i) => {
              const isSel     = answers[q.id] === i;
              const isCorrect = submitted && i === q.correct;
              const isWrong   = submitted && isSel && i !== q.correct;
              return (
                <TouchableOpacity key={i}
                  style={[s.option,
                    isSel && !submitted && s.optSelected,
                    isCorrect && s.optCorrect,
                    isWrong   && s.optWrong,
                  ]}
                  onPress={() => !submitted && setAnswers(prev=>({...prev,[q.id]:i}))}
                  disabled={submitted} activeOpacity={0.8}
                >
                  <View style={[s.optLabel,
                    isSel && !submitted && {backgroundColor:C.gold},
                    isCorrect && {backgroundColor:C.green},
                    isWrong   && {backgroundColor:C.red},
                  ]}>
                    <Text style={s.optLabelTxt}>{['A','B','C','D'][i]}</Text>
                  </View>
                  <Text style={[s.optTxt, (isSel||isCorrect) && {color:C.t1}]}>{opt}</Text>
                  {isCorrect && <Ionicons name="checkmark-circle" size={17} color={C.green}/>}
                  {isWrong   && <Ionicons name="close-circle"     size={17} color={C.red}  />}
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Nav buttons */}
        <View style={s.navRow}>
          <TouchableOpacity style={[s.navBtn, current===0&&{opacity:0.35}]}
            onPress={()=>setCurrent(c=>Math.max(0,c-1))} disabled={current===0}>
            <Ionicons name="chevron-back" size={19} color={C.t1} />
            <Text style={s.navBtnTxt}>Prev</Text>
          </TouchableOpacity>
          {current < TEST_QUESTIONS.length-1 ? (
            <TouchableOpacity style={s.nextBtn} onPress={()=>setCurrent(c=>c+1)}>
              <LinearGradient colors={C.gGold} style={s.nextGrad}>
                <Text style={s.nextTxt}>Next</Text>
                <Ionicons name="chevron-forward" size={19} color={C.inv}/>
              </LinearGradient>
            </TouchableOpacity>
          ) : !submitted && (
            <TouchableOpacity style={s.nextBtn} onPress={handleSubmit}>
              <LinearGradient colors={C.gGreen} style={s.nextGrad}>
                <Ionicons name="checkmark" size={19} color="#fff"/>
                <Text style={[s.nextTxt,{color:'#fff'}]}>Submit</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>

      {/* Result Modal */}
      <Modal visible={showResult} animationType="slide" transparent>
        <View style={rm.overlay}>
          <View style={rm.card}>
            <LinearGradient
              colors={sc?.pct>=60 ? C.gGreen : [C.red,C.redDark]}
              style={rm.icon}
            >
              <Ionicons name={sc?.pct>=60?'trophy':'refresh'} size={38} color="#fff"/>
            </LinearGradient>
            <Text style={rm.title}>
              {sc?.pct>=80?'Excellent! 🎉':sc?.pct>=60?'Good Job! 👍':'Keep Going 💪'}
            </Text>
            <View style={rm.stats}>
              {[
                {val:sc?.correct,  lbl:'Correct', color:C.green },
                {val:sc?.total-sc?.correct, lbl:'Wrong', color:C.red },
                {val:`${sc?.pct}%`,lbl:'Score',   color:C.gold  },
              ].map((st2,i)=>(
                <View key={i} style={rm.stat}>
                  <Text style={[rm.statVal,{color:st2.color}]}>{st2.val}</Text>
                  <Text style={rm.statLbl}>{st2.lbl}</Text>
                </View>
              ))}
            </View>
            <View style={rm.btns}>
              <TouchableOpacity style={rm.reviewBtn} onPress={()=>setShowResult(false)}>
                <Text style={rm.reviewTxt}>Review</Text>
              </TouchableOpacity>
              <TouchableOpacity style={rm.doneBtn} onPress={()=>navigation.goBack()}>
                <LinearGradient colors={C.gGold} style={rm.doneGrad}>
                  <Text style={rm.doneTxt}>Done</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  root:           { flex:1, backgroundColor:C.bg },
  header:         { flexDirection:'row', alignItems:'center', gap:10, paddingTop:52, paddingHorizontal:S.base, paddingBottom:S.md },
  closeBtn:       { width:38,height:38,borderRadius:10,backgroundColor:C.surface,justifyContent:'center',alignItems:'center' },
  testTitle:      { color:C.t1, fontWeight:'800', fontSize:F.base },
  testSub:        { color:C.t2, fontSize:12, marginTop:2 },
  timer:          { flexDirection:'row',alignItems:'center',gap:4,borderWidth:1.5,borderRadius:R.sm,paddingHorizontal:10,paddingVertical:5 },
  timerTxt:       { fontWeight:'800', fontSize:F.md, fontVariant:['tabular-nums'] },
  palette:        { backgroundColor:C.card,borderBottomWidth:1,borderBottomColor:C.border,paddingVertical:10,paddingHorizontal:S.sm,maxHeight:56 },
  paletteBtn:     { width:36,height:36,borderRadius:8,backgroundColor:C.surface,justifyContent:'center',alignItems:'center',marginHorizontal:4,borderWidth:1,borderColor:C.border },
  paletteBtnAnswered:{ backgroundColor:`${C.green}22`,borderColor:C.green },
  paletteBtnCurrent: { borderColor:C.gold,borderWidth:2 },
  paletteBtnTxt:  { color:C.t3, fontWeight:'700', fontSize:F.sm },
  paletteTxtAnswered:{ color:C.green },
  paletteTxtCurrent: { color:C.gold },
  qCard:          { margin:S.base, backgroundColor:C.card, borderRadius:R.xl, padding:S.lg, borderWidth:1, borderColor:C.border, gap:16 },
  qNum:           { backgroundColor:`${C.gold}18`,paddingHorizontal:9,paddingVertical:3,borderRadius:7,alignSelf:'flex-start' },
  qNumTxt:        { color:C.gold, fontWeight:'800', fontSize:12 },
  qTxt:           { color:C.t1, fontSize:F.base, fontWeight:'600', lineHeight:26 },
  option:         { flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.surface,borderRadius:R.md,padding:S.md,borderWidth:1,borderColor:C.border },
  optSelected:    { borderColor:C.gold, backgroundColor:`${C.gold}10` },
  optCorrect:     { borderColor:C.green,backgroundColor:`${C.green}10` },
  optWrong:       { borderColor:C.red,  backgroundColor:`${C.red}10`   },
  optLabel:       { width:30,height:30,borderRadius:7,backgroundColor:C.border,justifyContent:'center',alignItems:'center' },
  optLabelTxt:    { color:C.t1, fontWeight:'800', fontSize:F.sm },
  optTxt:         { flex:1, color:C.t2, fontSize:F.md, fontWeight:'500' },
  navRow:         { flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingHorizontal:S.base,paddingBottom:S.x3 },
  navBtn:         { flexDirection:'row',alignItems:'center',gap:4,backgroundColor:C.card,borderRadius:R.md,paddingVertical:12,paddingHorizontal:18,borderWidth:1,borderColor:C.border },
  navBtnTxt:      { color:C.t1, fontWeight:'600', fontSize:F.md },
  nextBtn:        { borderRadius:R.md, overflow:'hidden' },
  nextGrad:       { flexDirection:'row',alignItems:'center',gap:4,paddingVertical:12,paddingHorizontal:22 },
  nextTxt:        { color:C.inv, fontWeight:'800', fontSize:F.md },
});
const rm = StyleSheet.create({
  overlay: { flex:1,backgroundColor:'rgba(0,0,0,0.82)',justifyContent:'center',alignItems:'center',padding:S.base },
  card:    { width:'100%',backgroundColor:C.card,borderRadius:R.x2,padding:S.x2,alignItems:'center',gap:18,borderWidth:1,borderColor:C.border },
  icon:    { width:80,height:80,borderRadius:24,justifyContent:'center',alignItems:'center' },
  title:   { color:C.t1, fontSize:F.x2, fontWeight:'900' },
  stats:   { flexDirection:'row', gap:22 },
  stat:    { alignItems:'center', gap:4 },
  statVal: { fontSize:F.x3, fontWeight:'900' },
  statLbl: { color:C.t2, fontSize:F.sm },
  btns:    { flexDirection:'row', gap:12, width:'100%' },
  reviewBtn:{ flex:1,backgroundColor:C.surface,borderRadius:R.md,paddingVertical:14,alignItems:'center',borderWidth:1,borderColor:C.border },
  reviewTxt:{ color:C.t1, fontWeight:'700', fontSize:F.md },
  doneBtn: { flex:1, borderRadius:R.md, overflow:'hidden' },
  doneGrad:{ paddingVertical:14, alignItems:'center' },
  doneTxt: { color:C.inv, fontWeight:'800', fontSize:F.md },
});
