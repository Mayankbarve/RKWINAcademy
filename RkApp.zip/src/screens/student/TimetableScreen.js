// src/screens/student/TimetableScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const DAYS   = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const SHORT  = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const TYPE_CFG = {
  live:     {color:C.live,  icon:'radio',       label:'Live'    },
  recorded: {color:C.cyan,  icon:'play-circle', label:'Recorded'},
  test:     {color:C.gold,  icon:'clipboard',   label:'Test'    },
  doubt:    {color:C.green, icon:'chatbubbles', label:'Doubt'   },
};
const SUB_C = { Physics:C.cyan, Chemistry:C.green, Maths:C.gold, Biology:'#22c55e', All:C.purple, Test:C.red };

export default function TimetableScreen({ navigation }) {
  const { timetable } = useApp();
  const todayIdx = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
  const [activeDay, setActiveDay] = useState(todayIdx);

  const classes = timetable.find(t => t.day === DAYS[activeDay])?.classes || [];

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={s.title}>Weekly Timetable</Text>
      </LinearGradient>

      <View style={s.dayBar}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {SHORT.map((d,i)=>(
            <TouchableOpacity key={i}
              style={[s.dayBtn, activeDay===i&&s.dayBtnA, i===todayIdx&&s.dayBtnToday]}
              onPress={()=>setActiveDay(i)}
            >
              <Text style={[s.dayTxt, activeDay===i&&s.dayTxtA]}>{d}</Text>
              {i===todayIdx && <View style={s.todayDot}/>}
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{padding:S.base,paddingBottom:40}}>
        <Text style={s.dayTitle}>{DAYS[activeDay]}{activeDay===todayIdx?' · Today':''}</Text>

        {classes.length===0 ? (
          <View style={s.restDay}>
            <Ionicons name="cafe-outline" size={48} color={C.t3}/>
            <Text style={s.restTitle}>Rest Day</Text>
            <Text style={s.restSub}>No classes scheduled. Great time to revise!</Text>
          </View>
        ) : (
          <View style={{gap:0}}>
            {classes.map((cls,i)=>{
              const cfg = TYPE_CFG[cls.type]||TYPE_CFG.recorded;
              const col = SUB_C[cls.subject]||C.gold;
              return (
                <View key={i} style={s.timelineItem}>
                  <View style={s.timeAxis}>
                    <Text style={s.timeTxt}>{cls.time}</Text>
                    <View style={[s.timeDot,{backgroundColor:col}]}/>
                    {i<classes.length-1 && <View style={s.timeLine}/>}
                  </View>
                  <View style={[s.classCard,{borderLeftColor:col}]}>
                    <View style={s.classTop}>
                      <View style={[s.subjBadge,{backgroundColor:`${col}20`}]}>
                        <Text style={[s.subjBadgeTxt,{color:col}]}>{cls.subject}</Text>
                      </View>
                      <View style={[s.typeBadge,{backgroundColor:`${cfg.color}20`}]}>
                        <Ionicons name={cfg.icon} size={11} color={cfg.color}/>
                        <Text style={[s.typeBadgeTxt,{color:cfg.color}]}>{cfg.label}</Text>
                      </View>
                    </View>
                    <Text style={s.classTopic}>{cls.topic}</Text>
                    <View style={{flexDirection:'row',alignItems:'center',gap:4}}>
                      <Ionicons name="time-outline" size={12} color={C.t3}/>
                      <Text style={s.classDur}>{cls.duration} mins</Text>
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:        {flex:1,backgroundColor:C.bg},
  header:      {flexDirection:'row',alignItems:'center',gap:12,paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  backBtn:     {width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center'},
  title:       {color:C.t1,fontSize:F.xl,fontWeight:'900'},
  dayBar:      {backgroundColor:C.card,borderBottomWidth:1,borderBottomColor:C.border,paddingVertical:S.sm,paddingHorizontal:S.sm},
  dayBtn:      {alignItems:'center',justifyContent:'center',paddingVertical:9,paddingHorizontal:13,borderRadius:R.md,marginHorizontal:3,backgroundColor:C.surface,minWidth:50,borderWidth:1,borderColor:C.border},
  dayBtnA:     {backgroundColor:`${C.gold}18`,borderColor:C.gold},
  dayBtnToday: {borderColor:`${C.gold}50`},
  dayTxt:      {color:C.t3,fontWeight:'700',fontSize:F.sm},
  dayTxtA:     {color:C.gold},
  todayDot:    {width:5,height:5,borderRadius:2.5,backgroundColor:C.gold,marginTop:3},
  dayTitle:    {color:C.t1,fontSize:F.xl,fontWeight:'800',marginBottom:S.lg},
  restDay:     {alignItems:'center',paddingTop:60,gap:12},
  restTitle:   {color:C.t1,fontSize:F.xl,fontWeight:'800'},
  restSub:     {color:C.t2,fontSize:F.md,textAlign:'center'},
  timelineItem:{flexDirection:'row',gap:12},
  timeAxis:    {alignItems:'center',width:50,paddingTop:4},
  timeTxt:     {color:C.t2,fontSize:12,fontWeight:'700',marginBottom:6},
  timeDot:     {width:12,height:12,borderRadius:6,marginBottom:4},
  timeLine:    {width:2,flex:1,backgroundColor:C.border,marginBottom:0},
  classCard:   {flex:1,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border,borderLeftWidth:3,marginBottom:14,gap:7},
  classTop:    {flexDirection:'row',gap:8,flexWrap:'wrap'},
  subjBadge:   {paddingHorizontal:9,paddingVertical:3,borderRadius:20},
  subjBadgeTxt:{fontSize:12,fontWeight:'700'},
  typeBadge:   {flexDirection:'row',alignItems:'center',gap:3,paddingHorizontal:7,paddingVertical:3,borderRadius:20},
  typeBadgeTxt:{fontSize:11,fontWeight:'600'},
  classTopic:  {color:C.t1,fontWeight:'700',fontSize:F.base},
  classDur:    {color:C.t3,fontSize:12},
});
