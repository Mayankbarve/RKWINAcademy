// src/screens/student/VideoPlayerScreen.js
import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions, StatusBar } from 'react-native';
import { WebView } from 'react-native-webview';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const { width } = Dimensions.get('window');
const PLAYER_H  = width * 0.5625; // 16:9

// Secure YouTube embed — video ID never visible in UI layer
function SecurePlayer({ videoId }) {
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
  <style>
    *{margin:0;padding:0;box-sizing:border-box;-webkit-user-select:none;user-select:none;}
    html,body{width:100vw;height:100vh;background:#000;overflow:hidden;}
  </style>
</head>
<body>
  <div id="p"></div>
  <script>
    document.addEventListener('contextmenu',e=>e.preventDefault());
    document.addEventListener('selectstart',e=>e.preventDefault());
    document.addEventListener('copy',e=>e.preventDefault());
    window.open=()=>null;

    var s=document.createElement('script');
    s.src='https://www.youtube.com/iframe_api';
    document.head.appendChild(s);

    var player;
    function onYouTubeIframeAPIReady(){
      player=new YT.Player('p',{
        videoId:'${videoId}',
        width:'100%',height:'100%',
        playerVars:{autoplay:1,controls:1,rel:0,modestbranding:1,
          fs:1,iv_load_policy:3,cc_load_policy:0,playsinline:1},
        events:{onReady:e=>e.target.playVideo()}
      });
    }
  </script>
</body>
</html>`;

  return (
    <WebView
      source={{ html }}
      style={{ width, height: PLAYER_H }}
      allowsInlineMediaPlayback
      mediaPlaybackRequiresUserAction={false}
      javaScriptEnabled
      domStorageEnabled
      scrollEnabled={false}
      bounces={false}
      allowsFullscreenVideo
      onShouldStartLoadWithRequest={req => {
        const blocked = ['youtube.com/watch','youtu.be/','youtube.com/shorts'];
        return !blocked.some(u => req.url.includes(u));
      }}
    />
  );
}

export default function VideoPlayerScreen({ route, navigation }) {
  const { videoId, title } = route.params || {};
  const { addWatchHistory } = useApp();

  useEffect(() => {
    if (videoId && title) addWatchHistory({ id: videoId, youtubeId: videoId, title });
  }, []);

  return (
    <View style={s.root}>
      <StatusBar hidden />

      {/* Player */}
      <View style={[s.playerWrap, { height: PLAYER_H }]}>
        <SecurePlayer videoId={videoId} />
      </View>

      {/* Top bar */}
      <View style={s.bar}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1} />
        </TouchableOpacity>
        <Text style={s.barTitle} numberOfLines={1}>{title}</Text>
      </View>

      {/* Info */}
      <View style={s.info}>
        <Text style={s.infoTitle} numberOfLines={3}>{title}</Text>
        <View style={s.badgeRow}>
          <View style={s.badge}>
            <Ionicons name="play-circle" size={13} color={C.cyan} />
            <Text style={[s.badgeTxt, { color: C.cyan }]}>Recorded Lecture</Text>
          </View>
          <View style={[s.badge, { backgroundColor: `${C.green}18` }]}>
            <Ionicons name="shield-checkmark" size={13} color={C.green} />
            <Text style={[s.badgeTxt, { color: C.green }]}>Protected</Text>
          </View>
        </View>
        <View style={s.notice}>
          <Ionicons name="information-circle-outline" size={16} color={C.t3} />
          <Text style={s.noticeTxt}>
            This content is protected. Sharing, screen recording, or downloading is strictly prohibited.
          </Text>
        </View>
      </View>
    </View>
  );
}

const s = StyleSheet.create({
  root:      { flex: 1, backgroundColor: '#000' },
  playerWrap:{ width, backgroundColor: '#000' },
  bar:       { flexDirection: 'row', alignItems: 'center', gap: 10, padding: S.md, backgroundColor: C.card, borderBottomWidth: 1, borderBottomColor: C.border },
  backBtn:   { width: 38, height: 38, borderRadius: 10, backgroundColor: C.surface, justifyContent: 'center', alignItems: 'center' },
  barTitle:  { flex: 1, color: C.t1, fontWeight: '700', fontSize: F.md },
  info:      { flex: 1, backgroundColor: C.bg, padding: S.base, gap: 12 },
  infoTitle: { color: C.t1, fontSize: F.lg, fontWeight: '800', lineHeight: 26 },
  badgeRow:  { flexDirection: 'row', gap: 10 },
  badge:     { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: `${C.cyan}18`, paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.full },
  badgeTxt:  { fontSize: 12, fontWeight: '600' },
  notice:    { flexDirection: 'row', gap: 8, backgroundColor: C.card, padding: S.md, borderRadius: R.md, borderWidth: 1, borderColor: C.border },
  noticeTxt: { flex: 1, color: C.t3, fontSize: 12, lineHeight: 18 },
});
