// src/screens/student/NotificationsScreen.js
import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const TYPE_CFG2 = {
  live:  {icon:'radio',         color:C.live  },
  test:  {icon:'clipboard',     color:C.gold  },
  notes: {icon:'document-text', color:C.cyan  },
  alert: {icon:'alert-circle',  color:C.yellow},
};

export default function NotificationsScreen({ navigation }) {
  const { notifications, handleMarkRead, getUnreadCount } = useApp();
  const unread = getUnreadCount();

  return (
    <View style={ns.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={ns.header}>
        <TouchableOpacity style={ns.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={ns.title}>Notifications</Text>
        {unread>0 && (
          <View style={ns.unreadBadge}>
            <Text style={ns.unreadTxt}>{unread} new</Text>
          </View>
        )}
      </LinearGradient>

      <FlatList
        data={notifications}
        keyExtractor={n=>n.id}
        contentContainerStyle={{padding:S.base,gap:10}}
        showsVerticalScrollIndicator={false}
        renderItem={({item})=>{
          const cfg = TYPE_CFG2[item.type]||TYPE_CFG2.alert;
          return (
            <TouchableOpacity
              style={[ns.card, !item.read&&ns.cardUnread]}
              onPress={()=>handleMarkRead(item.id)}
              activeOpacity={0.85}
            >
              {!item.read && <View style={ns.unreadDot}/>}
              <View style={[ns.icon,{backgroundColor:`${cfg.color}20`}]}>
                <Ionicons name={cfg.icon} size={20} color={cfg.color}/>
              </View>
              <View style={{flex:1,gap:3}}>
                <Text style={ns.notifTitle}>{item.title}</Text>
                <Text style={ns.notifBody}>{item.body}</Text>
                <Text style={ns.notifTime}>{item.time}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
        ListEmptyComponent={
          <View style={{alignItems:'center',paddingTop:80,gap:12}}>
            <Ionicons name="notifications-off-outline" size={48} color={C.t3}/>
            <Text style={{color:C.t3,fontSize:F.base}}>No notifications yet</Text>
          </View>
        }
      />
    </View>
  );
}

const ns = StyleSheet.create({
  root:        {flex:1,backgroundColor:C.bg},
  header:      {flexDirection:'row',alignItems:'center',gap:12,paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  backBtn:     {width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center'},
  title:       {flex:1,color:C.t1,fontSize:F.xl,fontWeight:'900'},
  unreadBadge: {backgroundColor:`${C.gold}22`,paddingHorizontal:9,paddingVertical:3,borderRadius:R.full,borderWidth:1,borderColor:`${C.gold}35`},
  unreadTxt:   {color:C.gold,fontSize:12,fontWeight:'700'},
  card:        {flexDirection:'row',alignItems:'flex-start',gap:12,backgroundColor:C.card,borderRadius:R.xl,padding:S.md,borderWidth:1,borderColor:C.border,position:'relative'},
  cardUnread:  {borderColor:`${C.gold}35`,backgroundColor:`${C.gold}04`},
  unreadDot:   {position:'absolute',top:13,right:13,width:8,height:8,borderRadius:4,backgroundColor:C.gold},
  icon:        {width:46,height:46,borderRadius:12,justifyContent:'center',alignItems:'center'},
  notifTitle:  {color:C.t1,fontWeight:'700',fontSize:F.md},
  notifBody:   {color:C.t2,fontSize:F.sm,lineHeight:18},
  notifTime:   {color:C.t3,fontSize:11},
});

// ─────────────────────────────────────────────────────────────────
// WatchHistoryScreen
// ─────────────────────────────────────────────────────────────────
import { FlatList as FL2 } from 'react-native';

export function WatchHistoryScreen({ navigation }) {
  const { watchHistory } = useApp();
  return (
    <View style={wh.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={wh.header}>
        <TouchableOpacity style={wh.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <View>
          <Text style={wh.title}>Watch History</Text>
          <Text style={wh.sub}>{watchHistory.length} lectures watched</Text>
        </View>
      </LinearGradient>

      <FL2
        data={watchHistory}
        keyExtractor={v=>v.id}
        contentContainerStyle={{padding:S.base,gap:10}}
        showsVerticalScrollIndicator={false}
        renderItem={({item})=>(
          <TouchableOpacity style={wh.card}
            onPress={()=>navigation.navigate('VideoPlayer',{videoId:item.youtubeId,title:item.title})}
            activeOpacity={0.85}
          >
            <View style={wh.thumb}>
              <Ionicons name="play-circle" size={28} color={C.cyan}/>
            </View>
            <View style={{flex:1,gap:4}}>
              <Text style={wh.cardTitle} numberOfLines={2}>{item.title}</Text>
              <Text style={wh.cardTime}>
                {item.watchedAt ? new Date(item.watchedAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}) : 'Recently'}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={17} color={C.t3}/>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={{alignItems:'center',paddingTop:80,gap:12}}>
            <Ionicons name="time-outline" size={52} color={C.t3}/>
            <Text style={{color:C.t1,fontSize:F.lg,fontWeight:'800'}}>No Watch History</Text>
            <Text style={{color:C.t2,fontSize:F.md}}>Videos you watch will appear here</Text>
          </View>
        }
      />
    </View>
  );
}

const wh = StyleSheet.create({
  root:      {flex:1,backgroundColor:C.bg},
  header:    {flexDirection:'row',alignItems:'center',gap:12,paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  backBtn:   {width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center'},
  title:     {color:C.t1,fontSize:F.xl,fontWeight:'900'},
  sub:       {color:C.t2,fontSize:12,marginTop:2},
  card:      {flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border},
  thumb:     {width:52,height:52,borderRadius:12,backgroundColor:`${C.cyan}15`,justifyContent:'center',alignItems:'center'},
  cardTitle: {color:C.t1,fontWeight:'700',fontSize:F.md},
  cardTime:  {color:C.t3,fontSize:11},
});

// ─────────────────────────────────────────────────────────────────
// ProjectSubmitScreen
// ─────────────────────────────────────────────────────────────────
import { TextInput, Alert as RNAlert, KeyboardAvoidingView, Platform } from 'react-native';
import { GradBtn } from '../../components/UI';

export function ProjectSubmitScreen({ route, navigation }) {
  const { batchId } = route.params || {};
  const [type,     setType]     = React.useState('file');
  const [title,    setTitle]    = React.useState('');
  const [desc,     setDesc]     = React.useState('');
  const [url,      setUrl]      = React.useState('');
  const [loading,  setLoading]  = React.useState(false);
  const [done,     setDone]     = React.useState(false);

  const submit = async () => {
    if (!title.trim()) { RNAlert.alert('Missing','Please enter a project title'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r,1800));
    setLoading(false);
    setDone(true);
  };

  if (done) return (
    <View style={ps.successWrap}>
      <LinearGradient colors={['#08090F','#0F1220']} style={StyleSheet.absoluteFillObject}/>
      <LinearGradient colors={C.gGreen} style={ps.successIcon}>
        <Ionicons name="checkmark" size={50} color="#fff"/>
      </LinearGradient>
      <Text style={ps.successTitle}>Submitted! 🎉</Text>
      <Text style={ps.successSub}>Your project has been submitted. Your teacher will review it shortly.</Text>
      <GradBtn label="Back to Batch" onPress={()=>navigation.goBack()} style={{width:'80%'}}/>
    </View>
  );

  return (
    <KeyboardAvoidingView style={{flex:1,backgroundColor:C.bg}} behavior={Platform.OS==='ios'?'padding':undefined}>
      <LinearGradient colors={['#0F1220','#08090F']} style={ps.header}>
        <TouchableOpacity style={ps.backBtn} onPress={()=>navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1}/>
        </TouchableOpacity>
        <Text style={ps.title}>Submit Project</Text>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={ps.scroll}>
        <Text style={ps.label}>Project Type</Text>
        <View style={ps.typeRow}>
          {[
            {key:'file', icon:'document',  label:'File Project',  sub:'PDF, ZIP, DOC'},
            {key:'video',icon:'videocam',  label:'Video Project', sub:'MP4 or URL'},
          ].map(t=>(
            <TouchableOpacity key={t.key}
              style={[ps.typeCard, type===t.key&&ps.typeCardA]}
              onPress={()=>setType(t.key)}
            >
              <Ionicons name={t.icon} size={26} color={type===t.key?C.gold:C.t3}/>
              <Text style={[ps.typeLabel, type===t.key&&{color:C.gold}]}>{t.label}</Text>
              <Text style={ps.typeSub}>{t.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={ps.label}>Project Title *</Text>
        <View style={ps.inputWrap}>
          <Ionicons name="create-outline" size={17} color={C.t3}/>
          <TextInput style={ps.input} placeholder="Enter project title…" placeholderTextColor={C.t3}
            value={title} onChangeText={setTitle} selectionColor={C.gold}/>
        </View>

        <Text style={ps.label}>Description</Text>
        <View style={[ps.inputWrap,{height:100,alignItems:'flex-start',paddingTop:12}]}>
          <Ionicons name="text-outline" size={17} color={C.t3} style={{marginTop:2}}/>
          <TextInput style={[ps.input,{textAlignVertical:'top'}]} placeholder="Describe your project…"
            placeholderTextColor={C.t3} value={desc} onChangeText={setDesc}
            multiline numberOfLines={4} selectionColor={C.gold}/>
        </View>

        {type==='video' && <>
          <Text style={ps.label}>Video URL (YouTube / Drive)</Text>
          <View style={ps.inputWrap}>
            <Ionicons name="link-outline" size={17} color={C.t3}/>
            <TextInput style={ps.input} placeholder="https://…" placeholderTextColor={C.t3}
              value={url} onChangeText={setUrl} autoCapitalize="none" keyboardType="url" selectionColor={C.gold}/>
          </View>
        </>}

        <View style={ps.uploadBox}>
          <LinearGradient colors={[`${C.gold}18`,`${C.gold}05`]} style={ps.uploadIcon}>
            <Ionicons name="cloud-upload-outline" size={32} color={C.gold}/>
          </LinearGradient>
          <Text style={ps.uploadTitle}>Tap to attach file</Text>
          <Text style={ps.uploadSub}>{type==='file'?'PDF, ZIP, DOC (max 50 MB)':'MP4, MOV (max 500 MB)'}</Text>
        </View>

        <GradBtn label={loading?'Uploading…':'Submit Project'} icon="send"
          onPress={submit} disabled={loading} style={{marginTop:S.sm}}/>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const ps = StyleSheet.create({
  header:      {flexDirection:'row',alignItems:'center',gap:12,paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg},
  backBtn:     {width:40,height:40,borderRadius:R.md,backgroundColor:`${C.surface}90`,justifyContent:'center',alignItems:'center'},
  title:       {color:C.t1,fontSize:F.xl,fontWeight:'900'},
  scroll:      {padding:S.base,gap:13,paddingBottom:40},
  label:       {color:C.t2,fontSize:F.sm,fontWeight:'700'},
  typeRow:     {flexDirection:'row',gap:12},
  typeCard:    {flex:1,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,alignItems:'center',gap:5,borderWidth:2,borderColor:C.border},
  typeCardA:   {borderColor:C.gold,backgroundColor:`${C.gold}08`},
  typeLabel:   {color:C.t1,fontWeight:'700',fontSize:F.sm},
  typeSub:     {color:C.t3,fontSize:11},
  inputWrap:   {flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,borderRadius:R.md,paddingHorizontal:S.md,height:52,borderWidth:1,borderColor:C.border},
  input:       {flex:1,color:C.t1,fontSize:F.md},
  uploadBox:   {backgroundColor:C.card,borderRadius:R.xl,borderWidth:2,borderColor:C.border,borderStyle:'dashed',padding:S.xl,alignItems:'center',gap:9},
  uploadIcon:  {width:68,height:68,borderRadius:20,justifyContent:'center',alignItems:'center'},
  uploadTitle: {color:C.t1,fontWeight:'700',fontSize:F.base},
  uploadSub:   {color:C.t3,fontSize:12},
  successWrap: {flex:1,justifyContent:'center',alignItems:'center',padding:S.xl,gap:18},
  successIcon: {width:96,height:96,borderRadius:28,justifyContent:'center',alignItems:'center'},
  successTitle:{color:C.t1,fontSize:F.x3,fontWeight:'900'},
  successSub:  {color:C.t2,fontSize:F.md,textAlign:'center',lineHeight:22},
});
