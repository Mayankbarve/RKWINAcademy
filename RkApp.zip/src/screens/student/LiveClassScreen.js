// src/screens/student/LiveClassScreen.js
import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  FlatList, KeyboardAvoidingView, Platform, Dimensions,
  Modal, Alert,
} from 'react-native';
import { WebView } from 'react-native-webview';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp  } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const { width } = Dimensions.get('window');
const PLAYER_H  = width * 0.5625;

function SecureLivePlayer({ videoId }) {
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no,maximum-scale=1">
  <style>
    *{margin:0;padding:0;-webkit-user-select:none;user-select:none;}
    html,body{width:100vw;height:100vh;background:#000;overflow:hidden;}
  </style>
</head>
<body>
  <div id="p"></div>
  <script>
    document.addEventListener('contextmenu',e=>e.preventDefault());
    window.open=()=>null;
    var s=document.createElement('script');
    s.src='https://www.youtube.com/iframe_api';
    document.head.appendChild(s);
    var player;
    function onYouTubeIframeAPIReady(){
      player=new YT.Player('p',{
        videoId:'${videoId}',
        width:'100%',height:'100%',
        playerVars:{autoplay:1,controls:1,rel:0,modestbranding:1,
          fs:0,iv_load_policy:3,playsinline:1},
        events:{onReady:e=>e.target.playVideo()}
      });
    }
  </script>
</body>
</html>`;
  return (
    <WebView
      source={{ html }}
      style={{ width, height: PLAYER_H }}
      allowsInlineMediaPlayback mediaPlaybackRequiresUserAction={false}
      javaScriptEnabled domStorageEnabled scrollEnabled={false} bounces={false}
      onShouldStartLoadWithRequest={req => {
        const blocked = ['youtube.com/watch','youtu.be/'];
        return !blocked.some(u => req.url.includes(u));
      }}
    />
  );
}

function QuestionPopup({ question, onClose }) {
  const [selected, setSelected]   = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft]   = useState(30);

  useEffect(() => {
    if (!question) return;
    setSelected(null); setSubmitted(false); setTimeLeft(30);
    const interval = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) { clearInterval(interval); onClose(); return 0; }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [question]);

  if (!question) return null;

  const handleSubmit = () => {
    if (selected === null) { Alert.alert('Select an option first'); return; }
    setSubmitted(true);
    setTimeout(onClose, 2500);
  };

  return (
    <Modal transparent animationType="slide" visible={!!question}>
      <View style={qp.overlay}>
        <LinearGradient colors={[C.card, C.card2]} style={qp.card}>
          <View style={qp.header}>
            <View style={qp.badge}>
              <Ionicons name="help-circle" size={15} color={C.gold} />
              <Text style={qp.badgeTxt}>Teacher's Question</Text>
            </View>
            <Text style={[qp.timer, { color: timeLeft <= 10 ? C.red : C.green }]}>
              ⏱ {timeLeft}s
            </Text>
          </View>
          <Text style={qp.questionTxt}>{question.text}</Text>
          {question.options.map((opt, i) => {
            const isCorrect = submitted && i === question.correct;
            const isWrong   = submitted && selected === i && i !== question.correct;
            const isSelected = selected === i && !submitted;
            return (
              <TouchableOpacity key={i}
                style={[qp.option,
                  isSelected && qp.optSelected,
                  isCorrect  && qp.optCorrect,
                  isWrong    && qp.optWrong,
                ]}
                onPress={() => !submitted && setSelected(i)}
              >
                <View style={[qp.optLabel,
                  isSelected && { backgroundColor: C.gold },
                  isCorrect  && { backgroundColor: C.green },
                  isWrong    && { backgroundColor: C.red },
                ]}>
                  <Text style={qp.optLabelTxt}>{['A','B','C','D'][i]}</Text>
                </View>
                <Text style={qp.optTxt}>{opt}</Text>
                {isCorrect && <Ionicons name="checkmark-circle" size={18} color={C.green} />}
                {isWrong   && <Ionicons name="close-circle"     size={18} color={C.red}   />}
              </TouchableOpacity>
            );
          })}
          {submitted ? (
            <Text style={qp.result}>
              {selected === question.correct ? '✅ Correct! +10 pts' : '❌ Incorrect'}
            </Text>
          ) : (
            <TouchableOpacity style={qp.submitBtn} onPress={handleSubmit}>
              <LinearGradient colors={C.gGold} style={qp.submitGrad}>
                <Text style={qp.submitTxt}>Submit Answer</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}
        </LinearGradient>
      </View>
    </Modal>
  );
}

export default function LiveClassScreen() {
  const { liveClasses, chatMessages, sendMessage, activeQuestion, pushQuestion } = useApp();
  const { user } = useAuth();
  const [inputTxt, setInputTxt] = useState('');
  const [panel, setPanel]       = useState('chat'); // chat | info
  const [localQ, setLocalQ]     = useState(null);
  const flatRef = useRef(null);

  const liveClass = liveClasses.find(c => c.isLive);

  useEffect(() => {
    if (activeQuestion) setLocalQ(activeQuestion);
  }, [activeQuestion]);

  useEffect(() => {
    setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
  }, [chatMessages]);

  const handleSend = () => {
    if (!inputTxt.trim()) return;
    sendMessage(inputTxt.trim());
    setInputTxt('');
  };

  // Demo: simulate teacher pushing a question
  const demoTeacherQ = () => {
    setLocalQ({
      text: "What is the SI unit of Electric Field Intensity?",
      options: ["N/C", "V/m", "Both A & B", "None of these"],
      correct: 2,
    });
  };

  if (!liveClass) {
    return (
      <View style={s.noLive}>
        <LinearGradient colors={['#08090F','#0F1220']} style={StyleSheet.absoluteFillObject} />
        <Ionicons name="radio-outline" size={64} color={C.t3} />
        <Text style={s.noLiveTitle}>No Live Class Right Now</Text>
        <Text style={s.noLiveSub}>Check the timetable for upcoming sessions</Text>
        <View style={s.upcomingList}>
          {liveClasses.filter(c => !c.isLive).map(cls => (
            <View key={cls.id} style={s.upcomingItem}>
              <View style={s.upcomingDot} />
              <View>
                <Text style={s.upcomingTitle}>{cls.title}</Text>
                <Text style={s.upcomingSub}>
                  {new Date(cls.scheduledAt).toLocaleString('en-IN', {
                    day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit',
                  })}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      {/* Player */}
      <View style={[s.playerWrap, { height: PLAYER_H }]}>
        <SecureLivePlayer videoId={liveClass.youtubeVideoId} />
        <View style={s.liveBadge}>
          <View style={s.livePulse} />
          <Text style={s.liveTxt}>LIVE</Text>
        </View>
        <LinearGradient colors={['transparent','rgba(0,0,0,0.75)']} style={s.playerOverlay} pointerEvents="none">
          <Text style={s.playerTitle} numberOfLines={1}>{liveClass.title}</Text>
          <Text style={s.playerSub}>👁 {liveClass.attendees} watching · {liveClass.teacher}</Text>
        </LinearGradient>
      </View>

      {/* Panel toggle */}
      <View style={s.panelToggle}>
        {[
          { key: 'chat', icon: 'chatbubbles', label: 'Live Chat' },
          { key: 'info', icon: 'information-circle', label: 'Class Info' },
        ].map(p => (
          <TouchableOpacity key={p.key}
            style={[s.panelBtn, panel === p.key && s.panelBtnA]}
            onPress={() => setPanel(p.key)}
          >
            <Ionicons name={p.icon} size={15} color={panel === p.key ? C.gold : C.t3} />
            <Text style={[s.panelTxt, panel === p.key && s.panelTxtA]}>{p.label}</Text>
          </TouchableOpacity>
        ))}
        {/* Demo question button */}
        <TouchableOpacity style={s.demoQBtn} onPress={demoTeacherQ}>
          <Text style={s.demoQTxt}>📋 Q</Text>
        </TouchableOpacity>
      </View>

      {panel === 'chat' ? (
        <>
          <FlatList
            ref={flatRef}
            data={chatMessages}
            keyExtractor={m => m.id}
            style={{ flex: 1 }}
            contentContainerStyle={s.chatList}
            showsVerticalScrollIndicator={false}
            renderItem={({ item: m }) => (
              <View style={[s.msgWrap, m.isMe && s.msgWrapMe]}>
                {!m.isMe && <Text style={s.msgName}>{m.name}</Text>}
                <View style={[s.bubble, m.isMe && s.bubbleMe]}>
                  <Text style={[s.bubbleTxt, m.isMe && s.bubbleTxtMe]}>{m.text}</Text>
                </View>
                <Text style={s.msgTime}>{m.time}</Text>
              </View>
            )}
          />
          <View style={s.inputRow}>
            <TextInput
              style={s.chatInput}
              placeholder="Ask a question…"
              placeholderTextColor={C.t3}
              value={inputTxt}
              onChangeText={setInputTxt}
              selectionColor={C.gold}
              onSubmitEditing={handleSend}
              returnKeyType="send"
            />
            <TouchableOpacity style={s.sendBtn} onPress={handleSend}>
              <LinearGradient colors={C.gGold} style={s.sendGrad}>
                <Ionicons name="send" size={15} color={C.inv} />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <View style={s.infoPanel}>
          <Text style={s.infoTitle}>{liveClass.title}</Text>
          <Text style={s.infoDesc}>{liveClass.description}</Text>
          <View style={s.infoGrid}>
            {[
              { label: 'Subject',  val: liveClass.subject   },
              { label: 'Teacher',  val: liveClass.teacher   },
              { label: 'Duration', val: `${liveClass.duration} mins` },
              { label: 'Chapter',  val: liveClass.chapterName },
            ].map((item, i) => (
              <View key={i} style={s.infoItem}>
                <Text style={s.infoItemLabel}>{item.label}</Text>
                <Text style={s.infoItemVal}>{item.val}</Text>
              </View>
            ))}
          </View>
        </View>
      )}

      <QuestionPopup question={localQ} onClose={() => setLocalQ(null)} />
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  noLive:        { flex:1, justifyContent:'center', alignItems:'center', padding:S.xl, gap:14 },
  noLiveTitle:   { color:C.t1, fontSize:F.xl, fontWeight:'800' },
  noLiveSub:     { color:C.t2, fontSize:F.md },
  upcomingList:  { width:'100%', gap:10 },
  upcomingItem:  { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:C.card, borderRadius:R.lg, padding:S.md, borderWidth:1, borderColor:C.border },
  upcomingDot:   { width:10, height:10, borderRadius:5, backgroundColor:C.gold },
  upcomingTitle: { color:C.t1, fontWeight:'700', fontSize:F.sm },
  upcomingSub:   { color:C.t2, fontSize:12, marginTop:2 },
  playerWrap:    { width, position:'relative', backgroundColor:'#000' },
  liveBadge:     { position:'absolute', top:12, left:12, flexDirection:'row', alignItems:'center', gap:5, backgroundColor:C.live, paddingHorizontal:10, paddingVertical:4, borderRadius:6 },
  livePulse:     { width:7, height:7, borderRadius:3.5, backgroundColor:'#fff' },
  liveTxt:       { color:'#fff', fontWeight:'900', fontSize:11, letterSpacing:1 },
  playerOverlay: { position:'absolute', bottom:0, left:0, right:0, padding:S.md },
  playerTitle:   { color:'#fff', fontWeight:'700', fontSize:F.sm },
  playerSub:     { color:'rgba(255,255,255,0.7)', fontSize:11, marginTop:2 },
  panelToggle:   { flexDirection:'row', gap:6, padding:S.sm, backgroundColor:C.card, borderBottomWidth:1, borderBottomColor:C.border },
  panelBtn:      { flexDirection:'row', alignItems:'center', gap:5, paddingHorizontal:10, paddingVertical:7, borderRadius:R.sm },
  panelBtnA:     { backgroundColor:`${C.gold}18` },
  panelTxt:      { fontSize:F.sm, fontWeight:'600', color:C.t3 },
  panelTxtA:     { color:C.gold },
  demoQBtn:      { marginLeft:'auto', backgroundColor:`${C.gold}18`, paddingHorizontal:9, paddingVertical:6, borderRadius:6, borderWidth:1, borderColor:`${C.gold}35` },
  demoQTxt:      { color:C.gold, fontSize:11, fontWeight:'700' },
  chatList:      { padding:S.sm, paddingBottom:S.md, gap:6 },
  msgWrap:       { gap:2 },
  msgWrapMe:     { alignItems:'flex-end' },
  msgName:       { color:C.t3, fontSize:10, marginLeft:4 },
  bubble:        { backgroundColor:C.surface, borderRadius:R.lg, borderTopLeftRadius:4, paddingHorizontal:12, paddingVertical:8, maxWidth:'76%' },
  bubbleMe:      { backgroundColor:`${C.gold}22`, borderTopLeftRadius:R.lg, borderTopRightRadius:4 },
  bubbleTxt:     { color:C.t1, fontSize:F.sm },
  bubbleTxtMe:   { color:C.goldLight },
  msgTime:       { color:C.t3, fontSize:9, marginHorizontal:4 },
  inputRow:      { flexDirection:'row', gap:8, padding:S.sm, backgroundColor:C.card, borderTopWidth:1, borderTopColor:C.border },
  chatInput:     { flex:1, backgroundColor:C.surface, borderRadius:R.md, paddingHorizontal:S.md, paddingVertical:10, color:C.t1, fontSize:F.md, borderWidth:1, borderColor:C.border },
  sendBtn:       { borderRadius:R.md, overflow:'hidden' },
  sendGrad:      { width:44, height:44, justifyContent:'center', alignItems:'center' },
  infoPanel:     { flex:1, padding:S.base, gap:12 },
  infoTitle:     { color:C.t1, fontSize:F.lg, fontWeight:'800' },
  infoDesc:      { color:C.t2, fontSize:F.sm, lineHeight:20 },
  infoGrid:      { flexDirection:'row', flexWrap:'wrap', gap:10 },
  infoItem:      { width:'47%', backgroundColor:C.card, borderRadius:R.md, padding:S.md, borderWidth:1, borderColor:C.border },
  infoItemLabel: { color:C.t3, fontSize:11, marginBottom:4 },
  infoItemVal:   { color:C.t1, fontWeight:'700', fontSize:F.md },
});

const qp = StyleSheet.create({
  overlay:    { flex:1, backgroundColor:'rgba(0,0,0,0.78)', justifyContent:'flex-end' },
  card:       { borderTopLeftRadius:26, borderTopRightRadius:26, padding:S.xl, gap:12, borderWidth:1, borderColor:C.border },
  header:     { flexDirection:'row', justifyContent:'space-between', alignItems:'center' },
  badge:      { flexDirection:'row', alignItems:'center', gap:5, backgroundColor:`${C.gold}20`, paddingHorizontal:10, paddingVertical:4, borderRadius:20 },
  badgeTxt:   { color:C.gold, fontWeight:'700', fontSize:12 },
  timer:      { fontWeight:'800', fontSize:F.md },
  questionTxt:{ color:C.t1, fontSize:F.base, fontWeight:'700', lineHeight:24 },
  option:     { flexDirection:'row', alignItems:'center', gap:10, backgroundColor:C.surface, borderRadius:R.md, padding:S.md, borderWidth:1, borderColor:C.border },
  optSelected:{ borderColor:C.gold, backgroundColor:`${C.gold}12` },
  optCorrect: { borderColor:C.green, backgroundColor:`${C.green}12` },
  optWrong:   { borderColor:C.red,   backgroundColor:`${C.red}12`   },
  optLabel:   { width:30, height:30, borderRadius:7, backgroundColor:C.border, justifyContent:'center', alignItems:'center' },
  optLabelTxt:{ color:C.t1, fontWeight:'800', fontSize:F.sm },
  optTxt:     { flex:1, color:C.t1, fontSize:F.md },
  submitBtn:  { borderRadius:R.md, overflow:'hidden' },
  submitGrad: { paddingVertical:14, alignItems:'center' },
  submitTxt:  { color:C.inv, fontWeight:'800', fontSize:F.base },
  result:     { textAlign:'center', fontSize:F.lg, fontWeight:'800', color:C.t1, paddingVertical:8 },
});
