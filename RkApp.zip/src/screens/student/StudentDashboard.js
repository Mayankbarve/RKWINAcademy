// src/screens/student/StudentDashboard.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useApp  } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { StatCard, ProgressRing, TimetableWidget } from '../../components/UI';

const DAYS_SHORT = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

export default function StudentDashboard({ navigation }) {
  const { user }  = useAuth();
  const { analytics, liveClasses, timetable, getUnreadCount } = useApp();
  const [refreshing, setRefreshing] = useState(false);
  const unread = getUnreadCount();

  const todayName    = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const todayClasses = timetable.find(t => t.day === todayName)?.classes || [];
  const liveNow      = liveClasses.find(c => c.isLive);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good Morning ☀️';
    if (h < 17) return 'Good Afternoon 🌤';
    return 'Good Evening 🌙';
  };

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  return (
    <View style={s.root}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.gold} />}
      >
        {/* ── HEADER ────────────────────────────────────────── */}
        <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
          <View style={s.headerTop}>
            <View style={{ flex: 1 }}>
              <Text style={s.greeting}>{greeting()}</Text>
              <Text style={s.name}>{user?.name}</Text>
              <View style={s.streakRow}>
                <Ionicons name="flame" size={13} color={C.gold} />
                <Text style={s.streakTxt}>{analytics.streak} day streak</Text>
              </View>
            </View>
            <View style={s.headerBtns}>
              <TouchableOpacity style={s.headerBtn} onPress={() => navigation.navigate('Notifications')}>
                <Ionicons name="notifications" size={21} color={C.t1} />
                {unread > 0 && (
                  <View style={s.notifBadge}>
                    <Text style={s.notifBadgeTxt}>{unread > 9 ? '9+' : unread}</Text>
                  </View>
                )}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => navigation.getParent()?.navigate('Profile')}>
                <LinearGradient colors={C.gGold} style={s.avatar}>
                  <Text style={s.avatarTxt}>{user?.name?.[0] || 'S'}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>

          {/* Study goal progress */}
          <View style={s.goalWrap}>
            <View style={s.goalLabelRow}>
              <Text style={s.goalLabel}>Weekly Study Goal</Text>
              <Text style={s.goalVal}>{analytics.studyHours}/{analytics.studyGoal} hrs</Text>
            </View>
            <View style={s.goalBg}>
              <LinearGradient
                colors={C.gGold}
                style={[s.goalFill, { width: `${Math.min((analytics.studyHours / analytics.studyGoal) * 100, 100)}%` }]}
                start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
              />
            </View>
          </View>
        </LinearGradient>

        <View style={s.body}>
          {/* ── LIVE BANNER ───────────────────────────────────── */}
          {liveNow && (
            <TouchableOpacity
              style={s.liveBanner}
              onPress={() => navigation.getParent()?.navigate('LiveTab')}
              activeOpacity={0.9}
            >
              <View style={s.liveDot} />
              <View style={{ flex: 1 }}>
                <Text style={s.liveBannerTitle}>🔴 Live Now — {liveNow.title}</Text>
                <Text style={s.liveBannerSub}>{liveNow.attendees} students watching · Tap to join</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={C.live} />
            </TouchableOpacity>
          )}

          {/* ── STATS ─────────────────────────────────────────── */}
          <Text style={s.sectionTitle}>Your Performance</Text>
          <View style={s.statsGrid}>
            <StatCard icon="checkmark-circle" iconColor={C.green}  label="Attendance"  value={`${analytics.attendancePercent}%`} sub="This month" />
            <StatCard icon="document-text"    iconColor={C.cyan}   label="Tests Done"  value={`${analytics.testsAttempted}/${analytics.totalTests}`} sub="Completed" />
            <StatCard icon="trending-up"      iconColor={C.gold}   label="Avg Score"   value={`${analytics.avgScore}%`} sub="Last 10 tests" />
            <StatCard icon="trophy"           iconColor="#FFD600"  label="My Rank"     value={`#${user?.rank || '—'}`} sub="Leaderboard"
              onPress={() => navigation.getParent()?.navigate('Rank')} />
          </View>

          {/* ── SUBJECT RINGS ─────────────────────────────────── */}
          <Text style={s.sectionTitle}>Subject Progress</Text>
          <View style={s.ringsCard}>
            {analytics.subjectWise.map((s2, i) => (
              <ProgressRing
                key={i}
                percent={s2.percent}
                label={s2.subject}
                color={[C.cyan, C.gold, C.green][i]}
              />
            ))}
          </View>

          {/* ── TIMETABLE ─────────────────────────────────────── */}
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>Today's Schedule</Text>
            <TouchableOpacity onPress={() => navigation.navigate('Timetable')}>
              <Text style={s.seeAll}>Full →</Text>
            </TouchableOpacity>
          </View>
          <TimetableWidget classes={todayClasses} />

          {/* ── WEEKLY CHART ──────────────────────────────────── */}
          <Text style={s.sectionTitle}>Weekly Scores</Text>
          <View style={s.chartCard}>
            <View style={s.chartBars}>
              {analytics.weeklyScores.map((score, i) => {
                const today = new Date().getDay() === 0 ? 6 : new Date().getDay() - 1;
                const isToday = i === today;
                return (
                  <View key={i} style={s.barWrap}>
                    <Text style={s.barScore}>{score}</Text>
                    <View style={s.barBg}>
                      <LinearGradient
                        colors={isToday ? C.gGold : [C.cyan, C.cyanDark]}
                        style={[s.barFill, { height: `${score}%` }]}
                      />
                    </View>
                    <Text style={[s.barDay, isToday && { color: C.gold }]}>{DAYS_SHORT[i][0]}</Text>
                  </View>
                );
              })}
            </View>
          </View>

          {/* ── QUICK ACTIONS ─────────────────────────────────── */}
          <Text style={s.sectionTitle}>Quick Access</Text>
          <View style={s.quickRow}>
            {[
              { icon: 'play-circle',  label: 'Continue',    sub: 'Last lecture',  color: C.cyan,   action: () => navigation.getParent()?.navigate('Batches') },
              { icon: 'clipboard',    label: 'Test',        sub: 'Pending test',  color: C.gold,   action: () => navigation.getParent()?.navigate('Batches') },
              { icon: 'time',         label: 'History',     sub: 'Watch later',   color: C.purple, action: () => navigation.navigate('WatchHistory')          },
              { icon: 'calendar',     label: 'Schedule',    sub: 'Timetable',     color: C.green,  action: () => navigation.navigate('Timetable')             },
            ].map((a, i) => (
              <TouchableOpacity key={i} style={s.quickBtn} onPress={a.action} activeOpacity={0.8}>
                <View style={[s.quickIcon, { backgroundColor: `${a.color}20` }]}>
                  <Ionicons name={a.icon} size={22} color={a.color} />
                </View>
                <Text style={s.quickLabel}>{a.label}</Text>
                <Text style={s.quickSub}>{a.sub}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:            { flex: 1, backgroundColor: C.bg },
  header:          { paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.xl },
  headerTop:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: S.lg },
  greeting:        { color: C.t2, fontSize: F.sm, fontWeight: '500' },
  name:            { color: C.t1, fontSize: F.xl, fontWeight: '900', marginTop: 2 },
  streakRow:       { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: `${C.gold}18`, paddingHorizontal: 8, paddingVertical: 3, borderRadius: R.full, marginTop: 6, alignSelf: 'flex-start' },
  streakTxt:       { color: C.gold, fontSize: 11, fontWeight: '700' },
  headerBtns:      { flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerBtn:       { width: 42, height: 42, borderRadius: R.md, backgroundColor: C.surface, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: C.border },
  notifBadge:      { position: 'absolute', top: 6, right: 6, width: 16, height: 16, borderRadius: 8, backgroundColor: C.live, justifyContent: 'center', alignItems: 'center' },
  notifBadgeTxt:   { color: '#fff', fontSize: 9, fontWeight: '800' },
  avatar:          { width: 42, height: 42, borderRadius: R.md, justifyContent: 'center', alignItems: 'center' },
  avatarTxt:       { color: C.inv, fontWeight: '900', fontSize: 18 },
  goalWrap:        { gap: 6 },
  goalLabelRow:    { flexDirection: 'row', justifyContent: 'space-between' },
  goalLabel:       { color: C.t2, fontSize: F.sm },
  goalVal:         { color: C.gold, fontSize: F.sm, fontWeight: '700' },
  goalBg:          { height: 7, backgroundColor: C.surface, borderRadius: 4, overflow: 'hidden' },
  goalFill:        { height: '100%', borderRadius: 4 },
  body:            { padding: S.base, paddingTop: S.lg, gap: 2 },
  liveBanner:      { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: R.lg, padding: S.md, marginBottom: S.lg, backgroundColor: `${C.live}12`, borderWidth: 1, borderColor: `${C.live}35` },
  liveDot:         { width: 10, height: 10, borderRadius: 5, backgroundColor: C.live, shadowColor: C.live, shadowOffset: { width: 0, height: 0 }, shadowOpacity: 1, shadowRadius: 6, elevation: 6 },
  liveBannerTitle: { color: C.t1, fontWeight: '700', fontSize: F.sm },
  liveBannerSub:   { color: C.t2, fontSize: 11, marginTop: 2 },
  sectionTitle:    { color: C.t1, fontSize: F.base, fontWeight: '800', marginBottom: S.md, marginTop: S.md },
  sectionHeader:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  seeAll:          { color: C.gold, fontSize: F.sm, fontWeight: '700' },
  statsGrid:       { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: S.sm },
  ringsCard:       { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: C.card, borderRadius: R.xl, padding: S.lg, borderWidth: 1, borderColor: C.border, marginBottom: S.md },
  chartCard:       { backgroundColor: C.card, borderRadius: R.xl, padding: S.lg, borderWidth: 1, borderColor: C.border, marginBottom: S.md },
  chartBars:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', height: 100 },
  barWrap:         { flex: 1, alignItems: 'center', gap: 4 },
  barScore:        { color: C.t3, fontSize: 9, fontWeight: '600' },
  barBg:           { flex: 1, width: 22, backgroundColor: C.surface, borderRadius: 5, overflow: 'hidden', justifyContent: 'flex-end' },
  barFill:         { width: '100%', borderRadius: 5 },
  barDay:          { color: C.t3, fontSize: 11, fontWeight: '600' },
  quickRow:        { flexDirection: 'row', gap: 10, marginBottom: S.x4 },
  quickBtn:        { flex: 1, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, alignItems: 'center', borderWidth: 1, borderColor: C.border, gap: 6 },
  quickIcon:       { width: 44, height: 44, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  quickLabel:      { color: C.t1, fontSize: 12, fontWeight: '700' },
  quickSub:        { color: C.t3, fontSize: 10 },
});
