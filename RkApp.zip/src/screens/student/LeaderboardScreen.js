// src/screens/student/LeaderboardScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp  } from '../../context/AppContext';
import { useAuth } from '../../context/AuthContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

const MEDALS = ['🥇','🥈','🥉'];
const MEDAL_COLORS = ['#FFD700','#C0C0C0','#CD7F32'];

export default function LeaderboardScreen() {
  const { leaderboard } = useApp();
  const { user } = useAuth();
  const [filter, setFilter] = useState('all');

  const top3 = leaderboard.slice(0,3);
  const rest  = leaderboard.slice(3);

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <Text style={s.title}>Leaderboard</Text>
        <Text style={s.sub}>Top performers this month</Text>

        {/* My rank */}
        {user && (
          <LinearGradient colors={[`${C.gold}25`,`${C.gold}08`]} style={s.myCard}>
            <LinearGradient colors={C.gGold} style={s.myAvatar}>
              <Text style={s.myAvatarTxt}>{user.name?.[0]}</Text>
            </LinearGradient>
            <View style={{flex:1}}>
              <Text style={s.myName}>Your Rank</Text>
              <Text style={s.myPoints}>{(user.points||0).toLocaleString()} pts</Text>
            </View>
            <View style={s.myRankBadge}>
              <Text style={s.myRankNum}>#{user.rank||'—'}</Text>
            </View>
          </LinearGradient>
        )}

        <View style={s.filterRow}>
          {['all','month','week'].map(f=>(
            <TouchableOpacity key={f}
              style={[s.filterBtn, filter===f && s.filterBtnA]}
              onPress={()=>setFilter(f)}
            >
              <Text style={[s.filterTxt, filter===f && s.filterTxtA]}>
                {f==='all'?'All Time':f==='month'?'This Month':'This Week'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{paddingBottom:40}}>
        {/* Podium */}
        <View style={s.podium}>
          {[top3[1],top3[0],top3[2]].map((p,idx)=>{
            const rank = idx===0?2:idx===1?1:3;
            const isFirst = rank===1;
            if(!p) return <View key={idx} style={{flex:1}} />;
            return (
              <View key={idx} style={[s.podiumItem, isFirst&&s.podiumFirst]}>
                <Text style={s.podiumMedal}>{MEDALS[rank-1]}</Text>
                <LinearGradient
                  colors={isFirst?C.gGold:[C.surface,C.card2]}
                  style={[s.podiumAvatar, isFirst&&s.podiumAvatarFirst]}
                >
                  <Text style={[s.podiumAvatarTxt,isFirst&&{fontSize:22}]}>{p.name[0]}</Text>
                </LinearGradient>
                <Text style={s.podiumName} numberOfLines={1}>{p.name.split(' ')[0]}</Text>
                <Text style={[s.podiumPts, {color:MEDAL_COLORS[rank-1]}]}>{p.points.toLocaleString()}</Text>
              </View>
            );
          })}
        </View>

        {/* Rest */}
        <View style={{padding:S.base, gap:8}}>
          {rest.map(p => {
            const isMe = p.uid === user?.uid;
            return (
              <View key={p.rank} style={[s.rankRow, isMe&&s.rankRowMe]}>
                {isMe && <View style={s.meBar}/>}
                <View style={s.rankNumWrap}>
                  <Text style={s.rankNumTxt}>{p.rank}</Text>
                </View>
                <LinearGradient colors={isMe?C.gGold:[C.surface,C.card2]} style={s.rankAvatar}>
                  <Text style={s.rankAvatarTxt}>{p.name[0]}</Text>
                </LinearGradient>
                <View style={{flex:1}}>
                  <Text style={[s.rankName, isMe&&{color:C.gold}]}>{p.name}{isMe?' (You)':''}</Text>
                  <View style={{flexDirection:'row',gap:8,alignItems:'center'}}>
                    <Text style={s.rankBatch}>{p.batch}</Text>
                    <View style={s.streakBadge}>
                      <Ionicons name="flame" size={10} color={C.gold}/>
                      <Text style={s.streakTxt}>{p.streak}d</Text>
                    </View>
                  </View>
                </View>
                <View style={{alignItems:'flex-end'}}>
                  <Text style={[s.rankPts, isMe&&{color:C.gold}]}>{p.points.toLocaleString()}</Text>
                  <Text style={{color:C.t3,fontSize:10}}>pts</Text>
                </View>
              </View>
            );
          })}
        </View>
      </ScrollView>
    </View>
  );
}

const s = StyleSheet.create({
  root:       {flex:1,backgroundColor:C.bg},
  header:     {paddingTop:52,paddingHorizontal:S.base,paddingBottom:S.lg,gap:12},
  title:      {color:C.t1,fontSize:F.x3,fontWeight:'900'},
  sub:        {color:C.t2,fontSize:F.sm,marginTop:-8},
  myCard:     {flexDirection:'row',alignItems:'center',gap:12,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:`${C.gold}35`},
  myAvatar:   {width:44,height:44,borderRadius:12,justifyContent:'center',alignItems:'center'},
  myAvatarTxt:{color:C.inv,fontWeight:'900',fontSize:18},
  myName:     {color:C.t2,fontSize:12},
  myPoints:   {color:C.gold,fontWeight:'900',fontSize:F.base},
  myRankBadge:{backgroundColor:C.gold,paddingHorizontal:14,paddingVertical:7,borderRadius:R.md},
  myRankNum:  {color:C.inv,fontWeight:'900',fontSize:F.lg},
  filterRow:  {flexDirection:'row',gap:8},
  filterBtn:  {flex:1,paddingVertical:8,borderRadius:R.sm,backgroundColor:C.surface,alignItems:'center',borderWidth:1,borderColor:C.border},
  filterBtnA: {backgroundColor:`${C.gold}18`,borderColor:C.gold},
  filterTxt:  {color:C.t3,fontSize:12,fontWeight:'600'},
  filterTxtA: {color:C.gold},
  podium:     {flexDirection:'row',justifyContent:'center',alignItems:'flex-end',padding:S.xl,gap:12,backgroundColor:C.card,borderBottomWidth:1,borderBottomColor:C.border},
  podiumItem: {alignItems:'center',gap:5,flex:1},
  podiumFirst:{marginBottom:18},
  podiumMedal:{fontSize:24},
  podiumAvatar:{width:56,height:56,borderRadius:16,justifyContent:'center',alignItems:'center'},
  podiumAvatarFirst:{width:70,height:70,borderRadius:20},
  podiumAvatarTxt:{color:C.t1,fontWeight:'900',fontSize:18},
  podiumName: {color:C.t1,fontWeight:'700',fontSize:F.sm,textAlign:'center'},
  podiumPts:  {fontWeight:'900',fontSize:F.base},
  rankRow:    {flexDirection:'row',alignItems:'center',gap:12,backgroundColor:C.card,borderRadius:R.lg,padding:S.md,borderWidth:1,borderColor:C.border,overflow:'hidden'},
  rankRowMe:  {borderColor:C.gold,backgroundColor:`${C.gold}06`},
  meBar:      {position:'absolute',left:0,top:0,bottom:0,width:4,backgroundColor:C.gold,borderRadius:2},
  rankNumWrap:{width:32,height:32,borderRadius:7,backgroundColor:C.surface,justifyContent:'center',alignItems:'center'},
  rankNumTxt: {color:C.t2,fontWeight:'800',fontSize:F.sm},
  rankAvatar: {width:40,height:40,borderRadius:10,justifyContent:'center',alignItems:'center'},
  rankAvatarTxt:{color:C.t1,fontWeight:'800',fontSize:F.base},
  rankName:   {color:C.t1,fontWeight:'700',fontSize:F.md},
  rankBatch:  {color:C.t3,fontSize:11},
  streakBadge:{flexDirection:'row',alignItems:'center',gap:2,backgroundColor:`${C.gold}18`,paddingHorizontal:5,paddingVertical:2,borderRadius:5},
  streakTxt:  {color:C.gold,fontSize:10,fontWeight:'700'},
  rankPts:    {color:C.t1,fontWeight:'900',fontSize:F.base},
});
