// src/screens/student/ProjectSubmitScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';
import { GradBtn } from '../../components/UI';

export default function ProjectSubmitScreen({ route, navigation }) {
  const { batchId } = route.params || {};
  const [type,    setType]    = useState('file');
  const [title,   setTitle]   = useState('');
  const [desc,    setDesc]    = useState('');
  const [url,     setUrl]     = useState('');
  const [loading, setLoading] = useState(false);
  const [done,    setDone]    = useState(false);

  const submit = async () => {
    if (!title.trim()) { Alert.alert('Missing', 'Please enter a project title'); return; }
    setLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setLoading(false);
    setDone(true);
  };

  if (done) {
    return (
      <View style={s.successWrap}>
        <LinearGradient colors={['#08090F','#0F1220']} style={StyleSheet.absoluteFillObject} />
        <LinearGradient colors={C.gGreen} style={s.successIcon}>
          <Ionicons name="checkmark" size={50} color="#fff" />
        </LinearGradient>
        <Text style={s.successTitle}>Submitted! 🎉</Text>
        <Text style={s.successSub}>
          Your project has been submitted successfully. Your teacher will review it shortly.
        </Text>
        <GradBtn label="Back to Batch" onPress={() => navigation.goBack()} style={{ width: '80%' }} />
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: C.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1} />
        </TouchableOpacity>
        <Text style={s.title}>Submit Project</Text>
      </LinearGradient>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>
        <Text style={s.label}>Project Type</Text>
        <View style={s.typeRow}>
          {[
            { key: 'file',  icon: 'document', label: 'File Project',  sub: 'PDF, ZIP, DOC' },
            { key: 'video', icon: 'videocam', label: 'Video Project', sub: 'MP4 or URL'     },
          ].map(t => (
            <TouchableOpacity
              key={t.key}
              style={[s.typeCard, type === t.key && s.typeCardA]}
              onPress={() => setType(t.key)}
            >
              <Ionicons name={t.icon} size={26} color={type === t.key ? C.gold : C.t3} />
              <Text style={[s.typeLabel, type === t.key && { color: C.gold }]}>{t.label}</Text>
              <Text style={s.typeSub}>{t.sub}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={s.label}>Project Title *</Text>
        <View style={s.inputWrap}>
          <Ionicons name="create-outline" size={17} color={C.t3} />
          <TextInput
            style={s.input}
            placeholder="Enter your project title…"
            placeholderTextColor={C.t3}
            value={title}
            onChangeText={setTitle}
            selectionColor={C.gold}
          />
        </View>

        <Text style={s.label}>Description</Text>
        <View style={[s.inputWrap, { height: 100, alignItems: 'flex-start', paddingTop: 12 }]}>
          <Ionicons name="text-outline" size={17} color={C.t3} style={{ marginTop: 2 }} />
          <TextInput
            style={[s.input, { textAlignVertical: 'top' }]}
            placeholder="Describe your project…"
            placeholderTextColor={C.t3}
            value={desc}
            onChangeText={setDesc}
            multiline
            numberOfLines={4}
            selectionColor={C.gold}
          />
        </View>

        {type === 'video' && (
          <>
            <Text style={s.label}>Video URL (YouTube / Drive)</Text>
            <View style={s.inputWrap}>
              <Ionicons name="link-outline" size={17} color={C.t3} />
              <TextInput
                style={s.input}
                placeholder="https://…"
                placeholderTextColor={C.t3}
                value={url}
                onChangeText={setUrl}
                autoCapitalize="none"
                keyboardType="url"
                selectionColor={C.gold}
              />
            </View>
          </>
        )}

        <TouchableOpacity style={s.uploadBox} activeOpacity={0.8}>
          <LinearGradient colors={[`${C.gold}18`, `${C.gold}05`]} style={s.uploadIcon}>
            <Ionicons name="cloud-upload-outline" size={32} color={C.gold} />
          </LinearGradient>
          <Text style={s.uploadTitle}>Tap to attach file</Text>
          <Text style={s.uploadSub}>
            {type === 'file' ? 'PDF, ZIP, DOC (max 50 MB)' : 'MP4, MOV (max 500 MB)'}
          </Text>
        </TouchableOpacity>

        <GradBtn
          label={loading ? 'Uploading…' : 'Submit Project'}
          icon="send"
          onPress={submit}
          disabled={loading}
          style={{ marginTop: S.sm }}
        />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  header:       { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.lg },
  backBtn:      { width: 40, height: 40, borderRadius: R.md, backgroundColor: `${C.surface}90`, justifyContent: 'center', alignItems: 'center' },
  title:        { color: C.t1, fontSize: F.xl, fontWeight: '900' },
  scroll:       { padding: S.base, gap: 13, paddingBottom: 40 },
  label:        { color: C.t2, fontSize: F.sm, fontWeight: '700' },
  typeRow:      { flexDirection: 'row', gap: 12 },
  typeCard:     { flex: 1, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, alignItems: 'center', gap: 5, borderWidth: 2, borderColor: C.border },
  typeCardA:    { borderColor: C.gold, backgroundColor: `${C.gold}08` },
  typeLabel:    { color: C.t1, fontWeight: '700', fontSize: F.sm },
  typeSub:      { color: C.t3, fontSize: 11 },
  inputWrap:    { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: C.card, borderRadius: R.md, paddingHorizontal: S.md, height: 52, borderWidth: 1, borderColor: C.border },
  input:        { flex: 1, color: C.t1, fontSize: F.md },
  uploadBox:    { backgroundColor: C.card, borderRadius: R.xl, borderWidth: 2, borderColor: C.border, borderStyle: 'dashed', padding: S.xl, alignItems: 'center', gap: 9 },
  uploadIcon:   { width: 68, height: 68, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  uploadTitle:  { color: C.t1, fontWeight: '700', fontSize: F.base },
  uploadSub:    { color: C.t3, fontSize: 12 },
  successWrap:  { flex: 1, justifyContent: 'center', alignItems: 'center', padding: S.xl, gap: 18 },
  successIcon:  { width: 96, height: 96, borderRadius: 28, justifyContent: 'center', alignItems: 'center' },
  successTitle: { color: C.t1, fontSize: F.x3, fontWeight: '900' },
  successSub:   { color: C.t2, fontSize: F.md, textAlign: 'center', lineHeight: 22 },
});
