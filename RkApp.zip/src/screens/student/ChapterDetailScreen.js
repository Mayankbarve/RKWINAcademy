// src/screens/student/ChapterDetailScreen.js
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

export default function ChapterDetailScreen({ route, navigation }) {
  const { chapterId, batchId } = route.params;
  const { chapters } = useApp();
  const [tab, setTab] = useState('videos');

  const chapter = chapters.find(c => c.id === chapterId);
  if (!chapter) return null;

  const TABS = [
    { key: 'videos', label: 'Lectures',   icon: 'play-circle',   count: chapter.videos.length },
    { key: 'notes',  label: 'Notes & DPP',icon: 'document-text', count: chapter.notes.length  },
    { key: 'tests',  label: 'Tests',       icon: 'clipboard',     count: chapter.tests.length  },
  ];

  const noteColor = (type) => type === 'dpp' ? C.yellow : C.cyan;
  const noteIcon  = (type) => type === 'dpp' ? 'clipboard' : 'document-text';

  return (
    <View style={s.root}>
      {/* Header */}
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1} />
        </TouchableOpacity>
        <Text style={s.title} numberOfLines={2}>{chapter.title}</Text>
        <View style={s.progRow}>
          <View style={s.progBg}>
            <View style={[s.progFill, { width: `${chapter.completionPercent}%` }]} />
          </View>
          <Text style={s.progTxt}>{chapter.completionPercent}% done</Text>
        </View>
      </LinearGradient>

      {/* Tabs */}
      <View style={s.tabBar}>
        {TABS.map(t => (
          <TouchableOpacity key={t.key}
            style={[s.tabBtn, tab === t.key && s.tabBtnA]}
            onPress={() => setTab(t.key)}
          >
            <Ionicons name={t.icon} size={14} color={tab === t.key ? C.gold : C.t3} />
            <Text style={[s.tabTxt, tab === t.key && s.tabTxtA]}>{t.label}</Text>
            <View style={[s.tabCount, tab === t.key && s.tabCountA]}>
              <Text style={[s.tabCountTxt, tab === t.key && { color: C.gold }]}>{t.count}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.scroll}>

        {/* VIDEOS */}
        {tab === 'videos' && (
          chapter.videos.length === 0
            ? <Empty icon="videocam-outline" text="No lectures uploaded yet" />
            : chapter.videos.map((v, i) => (
                <TouchableOpacity key={v.id} style={s.videoCard}
                  onPress={() => navigation.navigate('VideoPlayer', { videoId: v.youtubeId, title: v.title })}
                  activeOpacity={0.85}
                >
                  <View style={[s.videoThumb, v.watched && s.videoThumbWatched]}>
                    {v.watched
                      ? <Ionicons name="checkmark-circle" size={26} color={C.green} />
                      : <Ionicons name="play" size={22} color={C.t1} />}
                  </View>
                  <View style={s.videoInfo}>
                    <Text style={s.videoTitle}>{v.title}</Text>
                    <View style={s.videoMeta}>
                      <Ionicons name="time-outline" size={12} color={C.t3} />
                      <Text style={s.videoMetaTxt}>{v.duration}</Text>
                      {v.watched && (
                        <View style={s.watchedBadge}>
                          <Text style={s.watchedTxt}>Watched</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <Ionicons name="chevron-forward" size={17} color={C.t3} />
                </TouchableOpacity>
              ))
        )}

        {/* NOTES */}
        {tab === 'notes' && (
          chapter.notes.length === 0
            ? <Empty icon="document-outline" text="No notes uploaded yet" />
            : chapter.notes.map(n => (
                <TouchableOpacity key={n.id} style={s.noteCard} activeOpacity={0.85}>
                  <View style={[s.noteIcon, { backgroundColor: `${noteColor(n.type)}18` }]}>
                    <Ionicons name={noteIcon(n.type)} size={22} color={noteColor(n.type)} />
                  </View>
                  <View style={s.noteInfo}>
                    <Text style={s.noteTitle}>{n.title}</Text>
                    <Text style={s.noteSize}>{n.size}</Text>
                  </View>
                  <View style={s.dlBtn}>
                    <Ionicons name="download-outline" size={20} color={C.gold} />
                  </View>
                </TouchableOpacity>
              ))
        )}

        {/* TESTS */}
        {tab === 'tests' && (
          chapter.tests.length === 0
            ? <Empty icon="clipboard-outline" text="No tests added yet" />
            : chapter.tests.map(t2 => (
                <View key={t2.id} style={s.testCard}>
                  <View style={s.testTop}>
                    <Text style={s.testTitle}>{t2.title}</Text>
                    {t2.attempted && (
                      <View style={[s.scoreBadge, { backgroundColor: t2.score >= 80 ? `${C.green}20` : `${C.yellow}20` }]}>
                        <Text style={[s.scoreTxt, { color: t2.score >= 80 ? C.green : C.yellow }]}>
                          {t2.score}/{t2.maxMarks}
                        </Text>
                      </View>
                    )}
                  </View>
                  <View style={s.testMeta}>
                    <Text style={s.testMetaTxt}>{t2.questions} questions</Text>
                    <Text style={s.testMetaDot}>·</Text>
                    <Text style={s.testMetaTxt}>{t2.duration} mins</Text>
                    <Text style={s.testMetaDot}>·</Text>
                    <Text style={s.testMetaTxt}>{t2.maxMarks} marks</Text>
                  </View>
                  <TouchableOpacity
                    style={[s.testBtn, t2.attempted && s.testBtnDone]}
                    onPress={() => navigation.navigate('Test', { testId: t2.id, title: t2.title })}
                  >
                    <Ionicons
                      name={t2.attempted ? 'stats-chart' : 'arrow-forward'}
                      size={14}
                      color={t2.attempted ? C.green : C.gold}
                    />
                    <Text style={[s.testBtnTxt, t2.attempted && { color: C.green }]}>
                      {t2.attempted ? 'View Results' : 'Start Test'}
                    </Text>
                  </TouchableOpacity>
                </View>
              ))
        )}
      </ScrollView>
    </View>
  );
}

function Empty({ icon, text }) {
  return (
    <View style={{ alignItems: 'center', paddingTop: 50, gap: 10 }}>
      <Ionicons name={icon} size={44} color={C.t3} />
      <Text style={{ color: C.t3, fontSize: F.md }}>{text}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  root:          { flex: 1, backgroundColor: C.bg },
  header:        { paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.lg, gap: 10 },
  backBtn:       { width: 40, height: 40, borderRadius: R.md, backgroundColor: `${C.surface}90`, justifyContent: 'center', alignItems: 'center' },
  title:         { color: C.t1, fontSize: F.xl, fontWeight: '800', lineHeight: 28 },
  progRow:       { flexDirection: 'row', alignItems: 'center', gap: 10 },
  progBg:        { flex: 1, height: 6, backgroundColor: C.surface, borderRadius: 3, overflow: 'hidden' },
  progFill:      { height: '100%', backgroundColor: C.gold, borderRadius: 3 },
  progTxt:       { color: C.gold, fontSize: 12, fontWeight: '700', minWidth: 58 },
  tabBar:        { flexDirection: 'row', backgroundColor: C.card, borderBottomWidth: 1, borderBottomColor: C.border, paddingHorizontal: S.xs, paddingTop: S.xs },
  tabBtn:        { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, paddingVertical: 11, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabBtnA:       { borderBottomColor: C.gold },
  tabTxt:        { color: C.t3, fontSize: 11, fontWeight: '600' },
  tabTxtA:       { color: C.gold },
  tabCount:      { backgroundColor: C.surface, paddingHorizontal: 5, paddingVertical: 1, borderRadius: 7, minWidth: 18, alignItems: 'center' },
  tabCountA:     { backgroundColor: `${C.gold}28` },
  tabCountTxt:   { color: C.t3, fontSize: 10, fontWeight: '700' },
  scroll:        { padding: S.base, gap: 10 },
  videoCard:     { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, borderWidth: 1, borderColor: C.border },
  videoThumb:    { width: 52, height: 52, borderRadius: 12, backgroundColor: C.surface, justifyContent: 'center', alignItems: 'center' },
  videoThumbWatched: { backgroundColor: `${C.green}15` },
  videoInfo:     { flex: 1, gap: 5 },
  videoTitle:    { color: C.t1, fontWeight: '700', fontSize: F.md },
  videoMeta:     { flexDirection: 'row', alignItems: 'center', gap: 5 },
  videoMetaTxt:  { color: C.t3, fontSize: 12 },
  watchedBadge:  { backgroundColor: `${C.green}20`, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 5 },
  watchedTxt:    { color: C.green, fontSize: 10, fontWeight: '700' },
  noteCard:      { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, borderWidth: 1, borderColor: C.border },
  noteIcon:      { width: 48, height: 48, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  noteInfo:      { flex: 1, gap: 4 },
  noteTitle:     { color: C.t1, fontWeight: '700', fontSize: F.md },
  noteSize:      { color: C.t3, fontSize: 12 },
  dlBtn:         { width: 40, height: 40, borderRadius: 10, backgroundColor: `${C.gold}18`, justifyContent: 'center', alignItems: 'center' },
  testCard:      { backgroundColor: C.card, borderRadius: R.lg, padding: S.md, borderWidth: 1, borderColor: C.border, gap: 8 },
  testTop:       { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  testTitle:     { color: C.t1, fontWeight: '800', fontSize: F.base, flex: 1, marginRight: 8 },
  scoreBadge:    { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  scoreTxt:      { fontWeight: '800', fontSize: F.sm },
  testMeta:      { flexDirection: 'row', alignItems: 'center', gap: 4 },
  testMetaTxt:   { color: C.t3, fontSize: 12 },
  testMetaDot:   { color: C.t3 },
  testBtn:       { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: `${C.gold}18`, borderRadius: R.md, paddingVertical: 10, borderWidth: 1, borderColor: `${C.gold}35` },
  testBtnDone:   { backgroundColor: `${C.green}15`, borderColor: `${C.green}30` },
  testBtnTxt:    { color: C.gold, fontWeight: '700', fontSize: F.md },
});
