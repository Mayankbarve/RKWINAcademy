// src/screens/student/WatchHistoryScreen.js
import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme/colors';
import { S, R, F } from '../../theme/spacing';

export default function WatchHistoryScreen({ navigation }) {
  const { watchHistory } = useApp();

  return (
    <View style={s.root}>
      <LinearGradient colors={['#0F1220','#08090F']} style={s.header}>
        <TouchableOpacity style={s.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={22} color={C.t1} />
        </TouchableOpacity>
        <View>
          <Text style={s.title}>Watch History</Text>
          <Text style={s.sub}>{watchHistory.length} lectures watched</Text>
        </View>
      </LinearGradient>

      <FlatList
        data={watchHistory}
        keyExtractor={v => v.id}
        contentContainerStyle={s.list}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={s.card}
            onPress={() => navigation.navigate('VideoPlayer', { videoId: item.youtubeId, title: item.title })}
            activeOpacity={0.85}
          >
            <View style={s.thumb}>
              <Ionicons name="play-circle" size={28} color={C.cyan} />
            </View>
            <View style={s.info}>
              <Text style={s.cardTitle} numberOfLines={2}>{item.title}</Text>
              <Text style={s.cardTime}>
                {item.watchedAt
                  ? new Date(item.watchedAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })
                  : 'Recently'}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={17} color={C.t3} />
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={s.empty}>
            <Ionicons name="time-outline" size={52} color={C.t3} />
            <Text style={s.emptyTitle}>No Watch History</Text>
            <Text style={s.emptySub}>Videos you watch will appear here</Text>
          </View>
        }
      />
    </View>
  );
}

const s = StyleSheet.create({
  root:       { flex: 1, backgroundColor: C.bg },
  header:     { flexDirection: 'row', alignItems: 'center', gap: 12, paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.lg },
  backBtn:    { width: 40, height: 40, borderRadius: R.md, backgroundColor: `${C.surface}90`, justifyContent: 'center', alignItems: 'center' },
  title:      { color: C.t1, fontSize: F.xl, fontWeight: '900' },
  sub:        { color: C.t2, fontSize: 12, marginTop: 2 },
  list:       { padding: S.base, gap: 10 },
  card:       { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, borderWidth: 1, borderColor: C.border },
  thumb:      { width: 52, height: 52, borderRadius: 12, backgroundColor: `${C.cyan}15`, justifyContent: 'center', alignItems: 'center' },
  info:       { flex: 1, gap: 4 },
  cardTitle:  { color: C.t1, fontWeight: '700', fontSize: F.md },
  cardTime:   { color: C.t3, fontSize: 11 },
  empty:      { alignItems: 'center', paddingTop: 80, gap: 12 },
  emptyTitle: { color: C.t1, fontSize: F.lg, fontWeight: '800' },
  emptySub:   { color: C.t2, fontSize: F.md },
});
