// src/navigation/index.js
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator }   from '@react-navigation/bottom-tabs';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import { useApp  } from '../context/AppContext';
import { C } from '../theme/colors';

// ── Auth Screens ──────────────────────────────────────────────────
import SplashScreen     from '../screens/auth/SplashScreen';
import LoginScreen      from '../screens/auth/LoginScreen';
import RegisterScreen   from '../screens/auth/RegisterScreen';

// ── Student Screens ───────────────────────────────────────────────
import StudentDashboard    from '../screens/student/StudentDashboard';
import BatchesScreen       from '../screens/student/BatchesScreen';
import BatchDetailScreen   from '../screens/student/BatchDetailScreen';
import ChapterDetailScreen from '../screens/student/ChapterDetailScreen';
import VideoPlayerScreen   from '../screens/student/VideoPlayerScreen';
import LiveClassScreen     from '../screens/student/LiveClassScreen';
import TestScreen          from '../screens/student/TestScreen';
import LeaderboardScreen   from '../screens/student/LeaderboardScreen';
import ProfileScreen       from '../screens/student/ProfileScreen';
import TimetableScreen     from '../screens/student/TimetableScreen';
import NotificationsScreen from '../screens/student/NotificationsScreen';
import WatchHistoryScreen  from '../screens/student/WatchHistoryScreen';
import ProjectSubmitScreen from '../screens/student/ProjectSubmitScreen';

// ── Admin Screens ─────────────────────────────────────────────────
import AdminDashboard      from '../screens/admin/AdminDashboard';
import BatchManagement     from '../screens/admin/BatchManagement';
import StudentManagement   from '../screens/admin/StudentManagement';
import AdminAnalytics      from '../screens/admin/AdminAnalytics';
import LiveControl         from '../screens/admin/LiveControl';
import ContentManagement   from '../screens/admin/ContentManagement';
import NotifControl        from '../screens/admin/NotifControl';
import PaymentManagement   from '../screens/admin/PaymentManagement';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

const noHeader = { headerShown: false };

// ─────────────────────────────────────────────────────────────────
//  AUTH
// ─────────────────────────────────────────────────────────────────
export function AuthNavigator() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="Splash"    component={SplashScreen}   />
      <Stack.Screen name="Login"     component={LoginScreen}    />
      <Stack.Screen name="Register"  component={RegisterScreen} />
    </Stack.Navigator>
  );
}

// ─────────────────────────────────────────────────────────────────
//  STUDENT — nested stacks inside tabs
// ─────────────────────────────────────────────────────────────────
function HomeStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="Dashboard"     component={StudentDashboard}    />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="Timetable"     component={TimetableScreen}     />
      <Stack.Screen name="WatchHistory"  component={WatchHistoryScreen}  />
    </Stack.Navigator>
  );
}

function BatchStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="Batches"       component={BatchesScreen}       />
      <Stack.Screen name="BatchDetail"   component={BatchDetailScreen}   />
      <Stack.Screen name="ChapterDetail" component={ChapterDetailScreen} />
      <Stack.Screen name="VideoPlayer"   component={VideoPlayerScreen}   />
      <Stack.Screen name="Test"          component={TestScreen}          />
      <Stack.Screen name="ProjectSubmit" component={ProjectSubmitScreen} />
    </Stack.Navigator>
  );
}

function LiveStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="Live" component={LiveClassScreen} />
    </Stack.Navigator>
  );
}

function TabIcon({ name, focused, color, badge }) {
  return (
    <View>
      <Ionicons name={name} size={22} color={color} />
      {badge > 0 && (
        <View style={st.badge}>
          <Text style={st.badgeText}>{badge > 9 ? '9+' : badge}</Text>
        </View>
      )}
    </View>
  );
}

export function StudentNavigator() {
  const { getUnreadCount } = useApp();
  const unread = getUnreadCount();

  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: st.tabBar,
        tabBarActiveTintColor:   C.gold,
        tabBarInactiveTintColor: C.t3,
        tabBarLabelStyle: st.tabLabel,
        tabBarHideOnKeyboard: true,
      }}
    >
      <Tab.Screen
        name="Home" component={HomeStack}
        options={{
          tabBarIcon: ({ focused, color }) =>
            <TabIcon name={focused ? 'home' : 'home-outline'} focused={focused} color={color} badge={unread} />,
        }}
      />
      <Tab.Screen
        name="Batches" component={BatchStack}
        options={{
          tabBarLabel: 'My Batches',
          tabBarIcon: ({ focused, color }) =>
            <Ionicons name={focused ? 'book' : 'book-outline'} size={22} color={color} />,
        }}
      />
      <Tab.Screen
        name="LiveTab" component={LiveStack}
        options={{
          tabBarLabel: () => (
            <Text style={[st.tabLabel, { color: C.live, fontWeight: '900' }]}>LIVE</Text>
          ),
          tabBarIcon: ({ focused }) => (
            <View style={[st.liveBtn, focused && st.liveBtnActive]}>
              <Ionicons name="radio" size={22} color={focused ? '#fff' : C.live} />
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Rank" component={LeaderboardScreen}
        options={{
          tabBarIcon: ({ focused, color }) =>
            <Ionicons name={focused ? 'trophy' : 'trophy-outline'} size={22} color={color} />,
        }}
      />
      <Tab.Screen
        name="Profile" component={ProfileScreen}
        options={{
          tabBarIcon: ({ focused, color }) =>
            <Ionicons name={focused ? 'person' : 'person-outline'} size={22} color={color} />,
        }}
      />
    </Tab.Navigator>
  );
}

// ─────────────────────────────────────────────────────────────────
//  ADMIN — nested stacks inside tabs
// ─────────────────────────────────────────────────────────────────
function AdminHomeStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="AdminDashboard"    component={AdminDashboard}    />
      <Stack.Screen name="LiveControl"       component={LiveControl}       />
      <Stack.Screen name="NotifControl"      component={NotifControl}      />
      <Stack.Screen name="PaymentManagement" component={PaymentManagement} />
    </Stack.Navigator>
  );
}

function AdminBatchStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="BatchManagement"  component={BatchManagement}  />
      <Stack.Screen name="ContentMgmt"      component={ContentManagement} />
    </Stack.Navigator>
  );
}

function AdminStudentStack() {
  return (
    <Stack.Navigator screenOptions={noHeader}>
      <Stack.Screen name="StudentManagement" component={StudentManagement} />
    </Stack.Navigator>
  );
}

export function AdminNavigator() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: st.tabBar,
        tabBarActiveTintColor:   C.gold,
        tabBarInactiveTintColor: C.t3,
        tabBarLabelStyle: st.tabLabel,
      }}
    >
      <Tab.Screen
        name="Overview" component={AdminHomeStack}
        options={{ tabBarIcon: ({ color }) => <Ionicons name="grid" size={22} color={color} /> }}
      />
      <Tab.Screen
        name="Batches" component={AdminBatchStack}
        options={{ tabBarIcon: ({ color }) => <Ionicons name="book" size={22} color={color} /> }}
      />
      <Tab.Screen
        name="Students" component={AdminStudentStack}
        options={{ tabBarIcon: ({ color }) => <Ionicons name="people" size={22} color={color} /> }}
      />
      <Tab.Screen
        name="Analytics" component={AdminAnalytics}
        options={{ tabBarIcon: ({ color }) => <Ionicons name="bar-chart" size={22} color={color} /> }}
      />
    </Tab.Navigator>
  );
}

// ─────────────────────────────────────────────────────────────────
//  ROOT
// ─────────────────────────────────────────────────────────────────
export function AppNavigator() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user)              return <AuthNavigator />;
  if (user.role === 'admin') return <AdminNavigator />;
  return <StudentNavigator />;
}

const st = StyleSheet.create({
  tabBar: {
    backgroundColor: C.card,
    borderTopColor: C.border,
    borderTopWidth: 1,
    height: Platform.OS === 'ios' ? 80 : 62,
    paddingBottom: Platform.OS === 'ios' ? 20 : 8,
    paddingTop: 6,
  },
  tabLabel: { fontSize: 10, fontWeight: '600' },
  badge: {
    position: 'absolute', top: -4, right: -8,
    backgroundColor: C.live,
    borderRadius: 8, minWidth: 16, height: 16,
    justifyContent: 'center', alignItems: 'center', paddingHorizontal: 3,
  },
  badgeText: { color: '#fff', fontSize: 9, fontWeight: '800' },
  liveBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: `${C.live}20`,
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1.5, borderColor: C.live,
    marginTop: -18,
  },
  liveBtnActive: { backgroundColor: C.live, borderColor: C.live },
});
