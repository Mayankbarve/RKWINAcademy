// src/context/AuthContext.js
import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  fbEmailLogin, fbRegister, fbLogout, fbOnAuth,
  getUser, createUser, updateUser, setDeviceId, db,
} from '../services/firebase';
import { DEMO_MODE, MOCK_USERS, ADMIN_SECRET } from '../services/mockData';

const AuthContext = createContext(null);

const DEV_DEVICE_KEY = '@rk_device_id';
const DEV_USER_KEY   = '@rk_user';
const DEV_PWD_PREFIX = '@rk_pwd_';

// generate a stable device id stored locally
async function getOrCreateDeviceId() {
  let id = await AsyncStorage.getItem(DEV_DEVICE_KEY);
  if (!id) {
    id = 'dev_' + Math.random().toString(36).slice(2, 11);
    await AsyncStorage.setItem(DEV_DEVICE_KEY, id);
  }
  return id;
}

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);
  const deviceIdRef            = useRef(null);

  useEffect(() => {
    let unsub = () => {};
    (async () => {
      deviceIdRef.current = await getOrCreateDeviceId();

      if (DEMO_MODE) {
        // Restore session from AsyncStorage
        try {
          const stored = await AsyncStorage.getItem(DEV_USER_KEY);
          if (stored) setUser(JSON.parse(stored));
        } catch (_) {}
        setLoading(false);
        return;
      }

      // Firebase auth listener
      unsub = fbOnAuth(async (fbUser) => {
        if (fbUser) {
          const profile = await getUser(fbUser.uid);
          if (profile) {
            // Single-device check
            if (profile.deviceId && profile.deviceId !== deviceIdRef.current) {
              // Force logout previous device — just update deviceId
            }
            await setDeviceId(fbUser.uid, deviceIdRef.current);
            const merged = { ...profile, uid: fbUser.uid };
            setUser(merged);
          }
        } else {
          setUser(null);
        }
        setLoading(false);
      });
    })();
    return () => unsub();
  }, []);

  // ── DEMO sign-in ────────────────────────────────────────────────
  const demoSignIn = async (email, password) => {
    // Admin secret combo — any email, special password
    if (password === ADMIN_SECRET) {
      const adminUser = {
        uid: 'adm_001', name: 'Admin', email,
        role: 'admin', deviceId: deviceIdRef.current,
      };
      await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(adminUser));
      setUser(adminUser);
      return { success: true, role: 'admin' };
    }

    const mockProfile = MOCK_USERS[email.toLowerCase()];
    if (!mockProfile) return { success: false, error: 'No account found with this email' };

    // Check password if one was set
    const storedPwd = await AsyncStorage.getItem(DEV_PWD_PREFIX + email);
    if (storedPwd && storedPwd !== password) {
      return { success: false, error: 'Incorrect password' };
    }

    const sessionUser = { ...mockProfile, deviceId: deviceIdRef.current };
    await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(sessionUser));
    setUser(sessionUser);
    return { success: true, role: mockProfile.role };
  };

  // ── FIREBASE sign-in ─────────────────────────────────────────────
  const firebaseSignIn = async (email, password) => {
    try {
      const cred = await fbEmailLogin(email, password);
      const profile = await getUser(cred.user.uid);
      if (!profile) return { success: false, error: 'Account not found in database' };

      // Check device
      if (profile.deviceId && profile.deviceId !== deviceIdRef.current) {
        // Kick other device
        await setDeviceId(cred.user.uid, deviceIdRef.current);
      }
      return { success: true, role: profile.role };
    } catch (e) {
      const msg = e.code === 'auth/wrong-password'  ? 'Incorrect password'
                : e.code === 'auth/user-not-found'   ? 'No account found'
                : e.code === 'auth/invalid-email'    ? 'Invalid email'
                : e.code === 'auth/too-many-requests' ? 'Too many attempts. Try later'
                : 'Sign-in failed. Check your credentials';
      return { success: false, error: msg };
    }
  };

  const signIn = DEMO_MODE ? demoSignIn : firebaseSignIn;

  // ── Google sign-in (demo simulation) ────────────────────────────
  const signInWithGoogle = async () => {
    // In production replace with expo-auth-session Google OAuth
    const googleUser = {
      uid: 'google_' + Math.random().toString(36).slice(2, 8),
      name: 'Student User',
      email: 'student@gmail.com',
      role: 'student',
      enrolledBatches: ['batch_001'],
      points: 0, streak: 0,
      deviceId: deviceIdRef.current,
      isGoogleUser: true,
    };
    if (DEMO_MODE) {
      await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(googleUser));
      setUser(googleUser);
      return { success: true, isNew: true };
    }
    // Firebase Google auth would go here
    return { success: false, error: 'Configure Firebase for Google auth' };
  };

  // ── Register new account ─────────────────────────────────────────
  const register = async (name, email, password) => {
    if (DEMO_MODE) {
      const newUser = {
        uid: 'new_' + Math.random().toString(36).slice(2, 8),
        name, email, role: 'student',
        enrolledBatches: [],
        points: 0, streak: 0,
        deviceId: deviceIdRef.current,
      };
      await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(newUser));
      await AsyncStorage.setItem(DEV_PWD_PREFIX + email, password);
      setUser(newUser);
      return { success: true };
    }
    try {
      const cred = await fbRegister(email, password);
      await createUser(cred.user.uid, { name, email });
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  };

  // ── Set password (after Google sign-in) ─────────────────────────
  const setPassword = async (password) => {
    if (!user) return;
    await AsyncStorage.setItem(DEV_PWD_PREFIX + user.email, password);
    const updated = { ...user, hasPassword: true };
    await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(updated));
    setUser(updated);
  };

  // ── Sign out ─────────────────────────────────────────────────────
  const signOut = async () => {
    await AsyncStorage.removeItem(DEV_USER_KEY);
    if (!DEMO_MODE) await fbLogout();
    setUser(null);
  };

  // ── Update profile ───────────────────────────────────────────────
  const updateProfile = async (data) => {
    const updated = { ...user, ...data };
    setUser(updated);
    if (DEMO_MODE) {
      await AsyncStorage.setItem(DEV_USER_KEY, JSON.stringify(updated));
    } else {
      await updateUser(user.uid, data);
    }
  };

  return (
    <AuthContext.Provider value={{
      user, loading,
      signIn, signInWithGoogle, register,
      setPassword, signOut, updateProfile,
      deviceId: deviceIdRef.current,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
