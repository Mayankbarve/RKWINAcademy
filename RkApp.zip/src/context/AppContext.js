// src/context/AppContext.js
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import {
  getBatches, getChapters, getLiveClasses,
  subscribeActiveLive, subscribeChat, sendChat,
  getLeaderboard, subscribeNotifs, markNotifRead,
} from '../services/firebase';
import {
  DEMO_MODE,
  MOCK_BATCHES, MOCK_CHAPTERS, MOCK_LIVE_CLASSES,
  MOCK_TIMETABLE, MOCK_ANALYTICS, MOCK_NOTIFICATIONS,
  MOCK_LEADERBOARD, MOCK_ADMIN_STATS,
} from '../services/mockData';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const { user } = useAuth();

  const [batches,       setBatches]       = useState([]);
  const [chapters,      setChapters]      = useState([]);
  const [liveClasses,   setLiveClasses]   = useState([]);
  const [leaderboard,   setLeaderboard]   = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [chatMessages,  setChatMessages]  = useState([]);
  const [activeLiveId,  setActiveLiveId]  = useState(null);
  const [adminStats]                      = useState(MOCK_ADMIN_STATS);
  const [timetable]                       = useState(MOCK_TIMETABLE);
  const [analytics]                       = useState(MOCK_ANALYTICS);
  const [watchHistory,  setWatchHistory]  = useState([]);
  const [activeQuestion, setActiveQuestion] = useState(null);
  const [loading, setLoading]             = useState(true);

  // ── Load data on mount ──────────────────────────────────────────
  useEffect(() => {
    if (DEMO_MODE) {
      setBatches(MOCK_BATCHES);
      setChapters(MOCK_CHAPTERS);
      setLiveClasses(MOCK_LIVE_CLASSES);
      setLeaderboard(MOCK_LEADERBOARD);
      setNotifications(MOCK_NOTIFICATIONS);
      setChatMessages([
        { id: 'm1', name: 'Priya P.',  text: 'Sir please explain Gauss theorem once more 🙏', time: '7:04', isMe: false },
        { id: 'm2', name: 'Rohan V.',  text: 'Understood! Thank you sir 🙌',                  time: '7:06', isMe: false },
        { id: 'm3', name: 'Divya N.',  text: 'Sir will this come in exam?',                   time: '7:08', isMe: false },
      ]);
      setLoading(false);
      return;
    }

    // Firebase mode — real-time listeners
    let unsubLive   = () => {};
    let unsubNotifs = () => {};
    let unsubChat   = () => {};

    (async () => {
      const [b, l, lb] = await Promise.all([
        getBatches(),
        getLiveClasses(null),
        getLeaderboard(),
      ]);
      setBatches(b);
      setLiveClasses(l);
      setLeaderboard(lb);

      unsubLive = subscribeActiveLive(null, (live) => {
        setLiveClasses(prev => {
          const ids = new Set(live.map(x => x.id));
          return [...prev.filter(x => !ids.has(x.id)), ...live];
        });
        if (live.length > 0) setActiveLiveId(live[0].id);
      });

      if (user) {
        unsubNotifs = subscribeNotifs(user.uid, setNotifications);
      }
      setLoading(false);
    })();

    return () => { unsubLive(); unsubNotifs(); unsubChat(); };
  }, [user]);

  // ── Subscribe chat for active live class ────────────────────────
  useEffect(() => {
    if (DEMO_MODE || !activeLiveId) return;
    const unsub = subscribeChat(activeLiveId, (msgs) => {
      setChatMessages(msgs.map(m => ({
        ...m,
        isMe: m.uid === user?.uid,
        time: m.createdAt?.toDate?.()?.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) || '',
      })));
    });
    return unsub;
  }, [activeLiveId, user]);

  // ── Helpers ──────────────────────────────────────────────────────
  const getEnrolledBatches  = useCallback((ids = []) =>
    batches.filter(b => ids.includes(b.id)), [batches]);

  const getAvailableBatches = useCallback((ids = []) =>
    batches.filter(b => !ids.includes(b.id)), [batches]);

  const getBatchChapters    = useCallback((batchId) =>
    chapters.filter(c => c.batchId === batchId), [chapters]);

  const getLiveBatch = useCallback(() =>
    liveClasses.find(c => c.isLive) || null, [liveClasses]);

  const getUnreadCount = useCallback(() =>
    notifications.filter(n => !n.read).length, [notifications]);

  const handleMarkRead = useCallback(async (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    if (!DEMO_MODE) await markNotifRead(id);
  }, []);

  const sendMessage = useCallback(async (text) => {
    const msg = {
      id: 'm' + Date.now(),
      name: user?.name || 'You',
      uid: user?.uid,
      text,
      time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      isMe: true,
    };
    setChatMessages(prev => [...prev, msg]);
    if (!DEMO_MODE && activeLiveId) {
      await sendChat(activeLiveId, user.uid, user.name, text);
    }
  }, [user, activeLiveId]);

  const addWatchHistory = useCallback((video) => {
    setWatchHistory(prev => {
      if (prev.find(v => v.id === video.id)) return prev;
      return [{ ...video, watchedAt: new Date().toISOString() }, ...prev].slice(0, 50);
    });
  }, []);

  const pushQuestion = useCallback((question) => {
    setActiveQuestion(question);
    setTimeout(() => setActiveQuestion(null), 30000);
  }, []);

  const loadBatchChapters = useCallback(async (batchId) => {
    if (DEMO_MODE) return;
    const chs = await getChapters(batchId);
    setChapters(prev => {
      const filtered = prev.filter(c => c.batchId !== batchId);
      return [...filtered, ...chs];
    });
  }, []);

  return (
    <AppContext.Provider value={{
      batches, chapters, liveClasses, leaderboard,
      notifications, chatMessages, adminStats,
      timetable, analytics, watchHistory, activeQuestion,
      loading,
      getEnrolledBatches, getAvailableBatches,
      getBatchChapters, getLiveBatch,
      getUnreadCount, handleMarkRead,
      sendMessage, addWatchHistory, pushQuestion,
      loadBatchChapters,
      setNotifications,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
