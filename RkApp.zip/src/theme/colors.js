// src/theme/colors.js
export const C = {
  bg:        '#08090F',
  bg2:       '#0F1220',
  card:      '#131926',
  card2:     '#192035',
  surface:   '#1E2842',
  border:    '#252F48',
  border2:   '#2E3A58',

  gold:      '#F5A623',
  goldDark:  '#C4841A',
  goldLight: '#FFD080',
  cyan:      '#00D4FF',
  cyanDark:  '#0099BB',

  green:     '#00E676',
  greenDark: '#00B248',
  red:       '#FF4D6D',
  redDark:   '#CC1A3A',
  yellow:    '#FFD600',
  purple:    '#A855F7',

  live:      '#FF4D6D',
  liveGlow:  'rgba(255,77,109,0.25)',

  t1:        '#FFFFFF',
  t2:        '#9BAABF',
  t3:        '#5A6A8A',
  inv:       '#08090F',

  // gradient arrays
  gGold:   ['#F5A623','#C4841A'],
  gCyan:   ['#00D4FF','#0066BB'],
  gCard:   ['#192035','#0F1220'],
  gGreen:  ['#00E676','#00B248'],
  gPurple: ['#A855F7','#7C3AED'],
};
