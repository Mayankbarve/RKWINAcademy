// src/theme/spacing.js
export const S = {
  xs: 4, sm: 8, md: 12, base: 16,
  lg: 20, xl: 24, x2: 32, x3: 40, x4: 56,
};
export const R = {
  sm: 6, md: 10, lg: 14, xl: 20, x2: 28, full: 999,
};
export const F = {
  xs: 10, sm: 12, md: 14, base: 16,
  lg: 18, xl: 20, x2: 24, x3: 28, x4: 34,
};
