// src/services/firebase.js
// ─────────────────────────────────────────────────────────────────
//  REPLACE the config values below with your own Firebase project.
//  Steps:
//  1. Go to https://console.firebase.google.com
//  2. Create project → Web app → copy firebaseConfig
//  3. Enable: Authentication (Email+Google), Firestore, Storage
// ─────────────────────────────────────────────────────────────────
import { initializeApp, getApps } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  onAuthStateChanged,
  updateProfile,
} from 'firebase/auth';
import {
  getFirestore,
  doc, getDoc, setDoc, updateDoc, deleteDoc,
  collection, query, where, orderBy, limit,
  getDocs, addDoc, onSnapshot,
  serverTimestamp, arrayUnion, increment,
} from 'firebase/firestore';
import {
  getStorage,
  ref, uploadBytes, getDownloadURL,
} from 'firebase/storage';

// ── YOUR FIREBASE CONFIG ───────────────────────────────────────────
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID",
};
// ──────────────────────────────────────────────────────────────────

// Prevent re-initialization in hot-reload
const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

export const auth    = getAuth(app);
export const db      = getFirestore(app);
export const storage = getStorage(app);

// ── AUTH ──────────────────────────────────────────────────────────
export const fbEmailLogin = (email, pw) =>
  signInWithEmailAndPassword(auth, email, pw);

export const fbRegister = (email, pw) =>
  createUserWithEmailAndPassword(auth, email, pw);

export const fbLogout = () => fbSignOut(auth);

export const fbOnAuth = (cb) => onAuthStateChanged(auth, cb);

// ── USERS ─────────────────────────────────────────────────────────
export const getUser = async (uid) => {
  const snap = await getDoc(doc(db, 'users', uid));
  return snap.exists() ? { uid, ...snap.data() } : null;
};

export const createUser = async (uid, data) => {
  await setDoc(doc(db, 'users', uid), {
    ...data,
    createdAt: serverTimestamp(),
    points: 0,
    streak: 0,
    enrolledBatches: [],
    role: 'student',
  });
};

export const updateUser = async (uid, data) =>
  updateDoc(doc(db, 'users', uid), data);

export const setDeviceId = async (uid, deviceId) =>
  updateDoc(doc(db, 'users', uid), { deviceId });

// ── BATCHES ───────────────────────────────────────────────────────
export const getBatches = async () => {
  const snap = await getDocs(
    query(collection(db, 'batches'), where('isActive', '==', true))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const getBatch = async (id) => {
  const snap = await getDoc(doc(db, 'batches', id));
  return snap.exists() ? { id, ...snap.data() } : null;
};

export const createBatch = async (data) =>
  addDoc(collection(db, 'batches'), { ...data, createdAt: serverTimestamp() });

export const updateBatch = async (id, data) =>
  updateDoc(doc(db, 'batches', id), data);

export const deleteBatch = async (id) =>
  deleteDoc(doc(db, 'batches', id));

// ── CHAPTERS ──────────────────────────────────────────────────────
export const getChapters = async (batchId) => {
  const snap = await getDocs(
    query(collection(db, 'batches', batchId, 'chapters'), orderBy('order'))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

// ── LIVE CLASSES ──────────────────────────────────────────────────
export const getLiveClasses = async (batchId) => {
  const snap = await getDocs(
    query(collection(db, 'liveClasses'), where('batchId', '==', batchId))
  );
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const subscribeActiveLive = (batchId, cb) =>
  onSnapshot(
    query(collection(db, 'liveClasses'), where('isLive', '==', true)),
    snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() })))
  );

// ── CHAT ──────────────────────────────────────────────────────────
export const sendChat = async (classId, uid, name, text) =>
  addDoc(collection(db, 'liveClasses', classId, 'chat'), {
    uid, name, text, createdAt: serverTimestamp(),
  });

export const subscribeChat = (classId, cb) =>
  onSnapshot(
    query(
      collection(db, 'liveClasses', classId, 'chat'),
      orderBy('createdAt'), limit(100)
    ),
    snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() })))
  );

// ── LEADERBOARD ───────────────────────────────────────────────────
export const getLeaderboard = async () => {
  const snap = await getDocs(
    query(collection(db, 'leaderboard'), orderBy('points', 'desc'), limit(50))
  );
  return snap.docs.map((d, i) => ({ rank: i + 1, ...d.data() }));
};

export const addPoints = async (uid, pts) =>
  updateDoc(doc(db, 'leaderboard', uid), { points: increment(pts) });

// ── NOTIFICATIONS ─────────────────────────────────────────────────
export const subscribeNotifs = (uid, cb) =>
  onSnapshot(
    query(
      collection(db, 'notifications'),
      where('targetUid', 'in', [uid, 'all']),
      orderBy('createdAt', 'desc'),
      limit(30)
    ),
    snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() })))
  );

export const markNotifRead = async (id) =>
  updateDoc(doc(db, 'notifications', id), { read: true });

export const sendNotif = async (data) =>
  addDoc(collection(db, 'notifications'), {
    ...data, createdAt: serverTimestamp(), read: false,
  });

// ── TEST RESULTS ──────────────────────────────────────────────────
export const saveTestResult = async (uid, testId, score, total) => {
  await addDoc(collection(db, 'testResults'), {
    uid, testId, score, total, createdAt: serverTimestamp(),
  });
  await addPoints(uid, score * 10);
};

// ── PROGRESS ──────────────────────────────────────────────────────
export const markWatched = async (uid, batchId, chapterId, videoId) => {
  const ref2 = doc(db, 'users', uid, 'progress', `${batchId}_${chapterId}`);
  await setDoc(ref2, {
    watchedVideos: arrayUnion(videoId),
    updatedAt: serverTimestamp(),
  }, { merge: true });
};

// ── SUBMISSIONS ───────────────────────────────────────────────────
export const submitProject = async (uid, batchId, title, desc, fileUrl, type) =>
  addDoc(collection(db, 'submissions'), {
    uid, batchId, title, desc, fileUrl, type,
    submittedAt: serverTimestamp(), status: 'pending',
  });

// ── STORAGE UPLOAD ────────────────────────────────────────────────
export const uploadFile = async (path, blob) => {
  const r = ref(storage, path);
  await uploadBytes(r, blob);
  return getDownloadURL(r);
};
