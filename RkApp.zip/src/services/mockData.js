// src/services/mockData.js
// Used as fallback when Firebase is not yet configured.
// Once Firebase is set up, data comes from Firestore automatically.

export const DEMO_MODE = true; // Set to false once Firebase is configured

export const MOCK_USERS = {
  'student@rkwin.com': {
    uid: 'stu_001',
    name: 'Arjun Sharma',
    email: 'student@rkwin.com',
    role: 'student',
    enrolledBatches: ['batch_001', 'batch_002'],
    points: 1240,
    rank: 3,
    streak: 15,
    phone: '+91 9876543210',
    joinedAt: '2024-01-15',
    avatar: null,
    deviceId: null,
  },
};

export const ADMIN_SECRET = '//rkadmin2025//';

export const MOCK_BATCHES = [
  {
    id: 'batch_001',
    name: 'JEE Mains 2025 — Dropper Batch',
    subject: 'Physics + Chemistry + Maths',
    teacher: 'RK Sir',
    price: 4999,
    originalPrice: 8999,
    isFree: false,
    isActive: true,
    totalStudents: 342,
    maxStudents: 500,
    expiresAt: '2025-12-31',
    description: 'Complete JEE preparation with live classes, doubt sessions, and full mock tests. Proven results with 95%+ selection rate.',
    chapters: 48,
    videos: 320,
    tests: 56,
    level: 'Advanced',
    tags: ['JEE', 'Physics', 'Chemistry', 'Maths'],
    schedule: 'Mon–Sat | 7:00 AM – 10:00 AM',
    thumbnail: null,
  },
  {
    id: 'batch_002',
    name: 'NEET 2025 — Foundation Batch',
    subject: 'Biology + Physics + Chemistry',
    teacher: 'RK Sir',
    price: 3999,
    originalPrice: 6999,
    isFree: false,
    isActive: true,
    totalStudents: 218,
    maxStudents: 300,
    expiresAt: '2025-11-30',
    description: 'Comprehensive NEET preparation with NCERT-focused teaching, weekly tests and live doubt clearing.',
    chapters: 36,
    videos: 240,
    tests: 44,
    level: 'Intermediate',
    tags: ['NEET', 'Biology', 'Physics', 'Chemistry'],
    schedule: 'Mon–Sat | 4:00 PM – 7:00 PM',
    thumbnail: null,
  },
  {
    id: 'batch_003',
    name: 'Class 12 Board — Free Batch',
    subject: 'All Subjects',
    teacher: 'RK Sir',
    price: 0,
    originalPrice: 0,
    isFree: true,
    isActive: true,
    totalStudents: 1240,
    maxStudents: 9999,
    expiresAt: '2025-04-30',
    description: 'Free batch for Class 12 students targeting board exams. Full NCERT coverage.',
    chapters: 20,
    videos: 140,
    tests: 28,
    level: 'Beginner',
    tags: ['Board', 'Class 12', 'Free'],
    schedule: 'Mon, Wed, Fri | 6:00 PM – 8:00 PM',
    thumbnail: null,
  },
];

export const MOCK_CHAPTERS = [
  {
    id: 'ch_001', batchId: 'batch_001', subject: 'Physics',
    title: 'Chapter 1 — Units & Dimensions', order: 1,
    isUnlocked: true, completionPercent: 100,
    videos: [
      { id: 'v001', title: 'Introduction to Units & Measurement', duration: '32:10', watched: true,  youtubeId: 'jNQXAC9IVRw' },
      { id: 'v002', title: 'Dimensional Analysis Deep Dive',      duration: '45:22', watched: true,  youtubeId: 'jNQXAC9IVRw' },
      { id: 'v003', title: 'Significant Figures & Errors',        duration: '28:44', watched: true,  youtubeId: 'jNQXAC9IVRw' },
    ],
    notes: [
      { id: 'n001', title: 'Units & Dimensions Notes.pdf',  size: '2.4 MB', type: 'pdf' },
      { id: 'n002', title: 'DPP Sheet 1 — Practice.pdf',   size: '1.1 MB', type: 'dpp' },
    ],
    tests: [
      { id: 't001', title: 'Chapter Test 1', questions: 30, duration: 45, maxMarks: 120, attempted: true, score: 96 },
    ],
  },
  {
    id: 'ch_002', batchId: 'batch_001', subject: 'Physics',
    title: 'Chapter 2 — Kinematics', order: 2,
    isUnlocked: true, completionPercent: 65,
    videos: [
      { id: 'v004', title: 'Motion in One Dimension',   duration: '52:18', watched: true,  youtubeId: 'jNQXAC9IVRw' },
      { id: 'v005', title: 'Motion in Two Dimensions',  duration: '48:36', watched: false, youtubeId: 'jNQXAC9IVRw' },
      { id: 'v006', title: 'Projectile Motion',         duration: '55:12', watched: false, youtubeId: 'jNQXAC9IVRw' },
    ],
    notes: [
      { id: 'n003', title: 'Kinematics Complete Notes.pdf', size: '3.8 MB', type: 'pdf' },
    ],
    tests: [
      { id: 't002', title: 'Chapter Test 2', questions: 35, duration: 60, maxMarks: 140, attempted: false, score: null },
    ],
  },
  {
    id: 'ch_003', batchId: 'batch_001', subject: 'Physics',
    title: 'Chapter 3 — Laws of Motion', order: 3,
    isUnlocked: false, completionPercent: 0,
    videos: [], notes: [], tests: [],
  },
  {
    id: 'ch_004', batchId: 'batch_001', subject: 'Chemistry',
    title: 'Chapter 1 — Some Basic Concepts', order: 4,
    isUnlocked: true, completionPercent: 80,
    videos: [
      { id: 'v007', title: 'Mole Concept & Stoichiometry',  duration: '60:00', watched: true,  youtubeId: 'jNQXAC9IVRw' },
      { id: 'v008', title: 'Equivalent Concept',            duration: '42:15', watched: false, youtubeId: 'jNQXAC9IVRw' },
    ],
    notes: [
      { id: 'n004', title: 'Mole Concept Notes.pdf', size: '2.9 MB', type: 'pdf' },
    ],
    tests: [
      { id: 't003', title: 'Mole Concept Test', questions: 25, duration: 40, maxMarks: 100, attempted: true, score: 78 },
    ],
  },
];

export const MOCK_LIVE_CLASSES = [
  {
    id: 'live_001',
    batchId: 'batch_001',
    title: 'Electrostatics — Electric Field & Potential',
    subject: 'Physics',
    teacher: 'RK Sir',
    scheduledAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
    isLive: true,
    youtubeVideoId: 'jNQXAC9IVRw',
    duration: 90,
    attendees: 128,
    chapterName: 'Chapter 12 — Electrostatics',
    description: "Coulomb's law, electric field lines, and Gauss's theorem with solved problems.",
  },
  {
    id: 'live_002',
    batchId: 'batch_001',
    title: 'Organic Chemistry — SN1 & SN2 Mechanisms',
    subject: 'Chemistry',
    teacher: 'RK Sir',
    scheduledAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    isLive: false,
    youtubeVideoId: null,
    duration: 75,
    attendees: 0,
    chapterName: 'Chapter 8 — Organic Chemistry',
    description: 'SN1, SN2, E1, E2 mechanisms with stereochemistry and real exam questions.',
  },
];

export const MOCK_TIMETABLE = [
  {
    day: 'Monday',
    classes: [
      { time: '07:00', subject: 'Physics',   topic: 'Electrostatics',        duration: 90, type: 'live'     },
      { time: '16:00', subject: 'Chemistry', topic: 'Organic Reactions',      duration: 75, type: 'recorded' },
    ],
  },
  {
    day: 'Tuesday',
    classes: [
      { time: '07:00', subject: 'Maths',     topic: 'Integration by Parts',  duration: 90, type: 'live'   },
      { time: '18:00', subject: 'Physics',   topic: 'Doubt Session',          duration: 60, type: 'doubt'  },
    ],
  },
  {
    day: 'Wednesday',
    classes: [
      { time: '07:00', subject: 'Chemistry', topic: 'Inorganic Chemistry',    duration: 90, type: 'live'     },
      { time: '15:00', subject: 'Maths',     topic: 'Coordinate Geometry',    duration: 75, type: 'recorded' },
    ],
  },
  {
    day: 'Thursday',
    classes: [
      { time: '07:00', subject: 'Physics',   topic: 'Magnetism & EMF',        duration: 90, type: 'live' },
      { time: '17:00', subject: 'All',       topic: 'Full Syllabus Mock Test', duration: 180, type: 'test' },
    ],
  },
  {
    day: 'Friday',
    classes: [
      { time: '07:00', subject: 'Maths',     topic: 'Differential Equations', duration: 90, type: 'live' },
      { time: '16:00', subject: 'Chemistry', topic: 'Electrochemistry',        duration: 75, type: 'live' },
    ],
  },
  {
    day: 'Saturday',
    classes: [
      { time: '08:00', subject: 'All',       topic: 'Weekly Revision + Grand Test', duration: 180, type: 'test' },
    ],
  },
  { day: 'Sunday', classes: [] },
];

export const MOCK_LEADERBOARD = [
  { rank: 1, uid: 'u1', name: 'Priya Patel',   points: 4850, batch: 'JEE 2025',  streak: 28 },
  { rank: 2, uid: 'u2', name: 'Rohan Verma',   points: 4720, batch: 'JEE 2025',  streak: 22 },
  { rank: 3, uid: 'stu_001', name: 'Arjun Sharma', points: 1240, batch: 'JEE 2025', streak: 15 },
  { rank: 4, uid: 'u4', name: 'Ananya Singh',  points: 3980, batch: 'JEE 2025',  streak: 19 },
  { rank: 5, uid: 'u5', name: 'Karan Mehta',   points: 3820, batch: 'NEET 2025', streak: 12 },
  { rank: 6, uid: 'u6', name: 'Divya Nair',    points: 3650, batch: 'JEE 2025',  streak: 18 },
  { rank: 7, uid: 'u7', name: 'Sahil Khan',    points: 3490, batch: 'NEET 2025', streak: 9  },
  { rank: 8, uid: 'u8', name: 'Nisha Gupta',   points: 3340, batch: 'JEE 2025',  streak: 14 },
];

export const MOCK_ANALYTICS = {
  attendancePercent: 82,
  testsAttempted: 14,
  totalTests: 18,
  avgScore: 74,
  studyHours: 28,
  studyGoal: 35,
  streak: 15,
  longestStreak: 22,
  weeklyScores: [68, 72, 65, 80, 74, 78, 74],
  subjectWise: [
    { subject: 'Physics',   percent: 78 },
    { subject: 'Chemistry', percent: 72 },
    { subject: 'Maths',     percent: 81 },
  ],
};

export const MOCK_NOTIFICATIONS = [
  { id: 'n1', type: 'live',  title: '🔴 Live Class in 30 mins', body: 'Electrostatics with RK Sir',           time: '5m ago',  read: false },
  { id: 'n2', type: 'test',  title: '📝 New Test Available',    body: 'Chapter 3 — Laws of Motion',           time: '2h ago',  read: false },
  { id: 'n3', type: 'notes', title: '📄 Notes Uploaded',        body: 'Magnetism complete notes & DPP added', time: '1d ago',  read: true  },
  { id: 'n4', type: 'alert', title: '⚠️ Batch Expiry Alert',   body: 'Your JEE batch expires in 30 days',   time: '2d ago',  read: true  },
];

export const MOCK_ADMIN_STATS = {
  totalStudents: 1800,
  activeToday: 423,
  totalBatches: 3,
  pendingDoubts: 12,
  revenueThisMonth: 184500,
  newEnrollments: 47,
  avgAttendance: 78,
  weeklyRevenue: [42000, 38000, 51000, 48000, 62000, 54000, 47000],
  batchStats: [
    { name: 'JEE 2025',  students: 342, color: '#F5A623' },
    { name: 'NEET 2025', students: 218, color: '#00D4FF' },
    { name: 'Board',     students: 1240, color: '#00E676' },
  ],
};

export const TEST_QUESTIONS = [
  {
    id: 'q1',
    text: 'A body moves with uniform acceleration. Velocity at t=0 is 5 m/s and at t=4s is 13 m/s. Find acceleration.',
    options: ['1 m/s²', '2 m/s²', '3 m/s²', '4 m/s²'],
    correct: 1,
  },
  {
    id: 'q2',
    text: "Newton's Second Law states that net force equals:",
    options: ['mass × velocity', 'mass × acceleration', 'mass × displacement', 'momentum / time'],
    correct: 1,
  },
  {
    id: 'q3',
    text: 'The SI unit of electric charge is:',
    options: ['Ampere', 'Volt', 'Coulomb', 'Ohm'],
    correct: 2,
  },
  {
    id: 'q4',
    text: 'Which of the following is a scalar quantity?',
    options: ['Force', 'Velocity', 'Speed', 'Acceleration'],
    correct: 2,
  },
  {
    id: 'q5',
    text: 'The speed of light in vacuum is approximately:',
    options: ['3×10⁶ m/s', '3×10⁸ m/s', '3×10¹⁰ m/s', '3×10⁴ m/s'],
    correct: 1,
  },
  {
    id: 'q6',
    text: 'In which type of collision is kinetic energy conserved?',
    options: ['Perfectly inelastic', 'Inelastic', 'Elastic', 'Oblique'],
    correct: 2,
  },
  {
    id: 'q7',
    text: 'The dimensional formula of gravitational constant G is:',
    options: ['M⁻¹L³T⁻²', 'M¹L²T⁻¹', 'M⁻²L³T⁻²', 'M⁰L²T⁻²'],
    correct: 0,
  },
  {
    id: 'q8',
    text: 'A projectile is thrown at 30° to horizontal with speed 20 m/s. Max height is (g=10):',
    options: ['5 m', '10 m', '15 m', '20 m'],
    correct: 0,
  },
];
