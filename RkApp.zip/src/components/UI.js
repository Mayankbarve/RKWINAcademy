// src/components/UI.js
// All reusable components in one import
import React from 'react';
import {
  View, Text, TouchableOpacity, ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import Svg, { Circle } from 'react-native-svg';
import { C } from '../theme/colors';
import { S, R, F } from '../theme/spacing';

// ── GradientButton ────────────────────────────────────────────────
export function GradBtn({ label, onPress, colors = C.gGold, icon, disabled, style }) {
  return (
    <TouchableOpacity
      onPress={onPress} disabled={disabled}
      style={[{ borderRadius: R.md, overflow: 'hidden', opacity: disabled ? 0.55 : 1 }, style]}
      activeOpacity={0.85}
    >
      <LinearGradient colors={colors} style={gb.grad}>
        {icon && <Ionicons name={icon} size={18} color={C.inv} />}
        <Text style={gb.label}>{label}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
}
const gb = StyleSheet.create({
  grad:  { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 15, paddingHorizontal: 24 },
  label: { color: C.inv, fontWeight: '800', fontSize: F.base },
});

// ── OutlineButton ─────────────────────────────────────────────────
export function OutlineBtn({ label, onPress, color = C.gold, icon, style }) {
  return (
    <TouchableOpacity
      onPress={onPress} activeOpacity={0.8}
      style={[{ borderRadius: R.md, borderWidth: 1.5, borderColor: color,
        backgroundColor: `${color}15`, paddingVertical: 12, paddingHorizontal: 20,
        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6 }, style]}
    >
      {icon && <Ionicons name={icon} size={16} color={color} />}
      <Text style={{ color, fontWeight: '700', fontSize: F.md }}>{label}</Text>
    </TouchableOpacity>
  );
}

// ── Card ──────────────────────────────────────────────────────────
export function Card({ children, style, onPress }) {
  const Wrap = onPress ? TouchableOpacity : View;
  return (
    <Wrap
      style={[cd.card, style]}
      onPress={onPress}
      activeOpacity={0.87}
    >
      {children}
    </Wrap>
  );
}
const cd = StyleSheet.create({
  card: {
    backgroundColor: C.card, borderRadius: R.xl,
    borderWidth: 1, borderColor: C.border, overflow: 'hidden',
  },
});

// ── StatCard ──────────────────────────────────────────────────────
export function StatCard({ icon, iconColor, label, value, sub, onPress }) {
  const Wrap = onPress ? TouchableOpacity : View;
  return (
    <Wrap style={[sc.card, { borderColor: C.border }]} onPress={onPress} activeOpacity={0.85}>
      <LinearGradient colors={[`${iconColor}22`, `${iconColor}06`]} style={sc.inner}>
        <View style={[sc.iconWrap, { backgroundColor: `${iconColor}28` }]}>
          <Ionicons name={icon} size={18} color={iconColor} />
        </View>
        <Text style={sc.val}>{value}</Text>
        <Text style={sc.lbl}>{label}</Text>
        {sub && <Text style={sc.sub}>{sub}</Text>}
      </LinearGradient>
    </Wrap>
  );
}
const sc = StyleSheet.create({
  card:    { width: '47.5%', borderRadius: R.lg, overflow: 'hidden', borderWidth: 1, backgroundColor: C.card },
  inner:   { padding: S.md, gap: 4, borderRadius: R.lg },
  iconWrap:{ width: 38, height: 38, borderRadius: 10, justifyContent: 'center', alignItems: 'center', marginBottom: 2 },
  val:     { color: C.t1, fontSize: F.x2, fontWeight: '900' },
  lbl:     { color: C.t2, fontSize: F.sm, fontWeight: '600' },
  sub:     { color: C.t3, fontSize: F.xs },
});

// ── ProgressRing ──────────────────────────────────────────────────
const RING_SIZE = 70;
const RING_STROKE = 6;
const RING_R = (RING_SIZE - RING_STROKE) / 2;
const CIRC  = 2 * Math.PI * RING_R;

export function ProgressRing({ percent = 0, label = '', color = C.gold }) {
  const offset = CIRC - (percent / 100) * CIRC;
  return (
    <View style={pr.wrap}>
      <View style={{ width: RING_SIZE, height: RING_SIZE, justifyContent: 'center', alignItems: 'center' }}>
        <Svg width={RING_SIZE} height={RING_SIZE} style={{ position: 'absolute' }}>
          <Circle cx={RING_SIZE/2} cy={RING_SIZE/2} r={RING_R}
            stroke={C.surface} strokeWidth={RING_STROKE} fill="none" />
          <Circle cx={RING_SIZE/2} cy={RING_SIZE/2} r={RING_R}
            stroke={color} strokeWidth={RING_STROKE} fill="none"
            strokeDasharray={`${CIRC} ${CIRC}`} strokeDashoffset={offset}
            strokeLinecap="round" rotation="-90"
            originX={RING_SIZE/2} originY={RING_SIZE/2} />
        </Svg>
        <Text style={[pr.pct, { color }]}>{percent}<Text style={pr.sym}>%</Text></Text>
      </View>
      <Text style={pr.lbl} numberOfLines={1}>{label}</Text>
    </View>
  );
}
const pr = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 6 },
  pct:  { fontSize: F.md, fontWeight: '900' },
  sym:  { fontSize: F.xs, fontWeight: '600' },
  lbl:  { color: C.t2, fontSize: 10, fontWeight: '600', maxWidth: RING_SIZE, textAlign: 'center' },
});

// ── Badge ─────────────────────────────────────────────────────────
export function Badge({ label, color = C.gold, sm }) {
  return (
    <View style={[bdg.wrap, { backgroundColor: `${color}20`, borderColor: `${color}35` }, sm && bdg.wrapSm]}>
      <Text style={[bdg.txt, { color }, sm && bdg.txtSm]}>{label}</Text>
    </View>
  );
}
const bdg = StyleSheet.create({
  wrap:   { paddingHorizontal: 10, paddingVertical: 4, borderRadius: R.full, borderWidth: 1, alignSelf: 'flex-start' },
  wrapSm: { paddingHorizontal: 7, paddingVertical: 2 },
  txt:    { fontSize: F.sm, fontWeight: '700' },
  txtSm:  { fontSize: F.xs },
});

// ── EmptyState ────────────────────────────────────────────────────
export function EmptyState({ icon = 'folder-open-outline', title, subtitle, action, onAction }) {
  return (
    <View style={es.wrap}>
      <View style={es.iconBox}>
        <Ionicons name={icon} size={48} color={C.t3} />
      </View>
      <Text style={es.title}>{title}</Text>
      {subtitle && <Text style={es.sub}>{subtitle}</Text>}
      {action && <GradBtn label={action} onPress={onAction} style={{ marginTop: S.md }} />}
    </View>
  );
}
const es = StyleSheet.create({
  wrap:    { alignItems: 'center', paddingTop: 60, paddingHorizontal: S.x2, gap: 10 },
  iconBox: { width: 88, height: 88, borderRadius: 24, backgroundColor: C.card, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: C.border, marginBottom: 6 },
  title:   { color: C.t1, fontSize: F.xl, fontWeight: '800', textAlign: 'center' },
  sub:     { color: C.t2, fontSize: F.md, textAlign: 'center', lineHeight: 20 },
});

// ── Loader ────────────────────────────────────────────────────────
export function Loader({ text }) {
  return (
    <View style={{ flex: 1, backgroundColor: C.bg, justifyContent: 'center', alignItems: 'center', gap: 14 }}>
      <ActivityIndicator size="large" color={C.gold} />
      {text && <Text style={{ color: C.t2, fontSize: F.md }}>{text}</Text>}
    </View>
  );
}

// ── ScreenHeader ──────────────────────────────────────────────────
export function ScreenHeader({ title, subtitle, onBack, rightIcon, onRight, rightLabel }) {
  return (
    <LinearGradient colors={['#0F1220', '#08090F']} style={sh.wrap}>
      <View style={sh.row}>
        {onBack && (
          <TouchableOpacity style={sh.back} onPress={onBack}>
            <Ionicons name="arrow-back" size={22} color={C.t1} />
          </TouchableOpacity>
        )}
        <View style={{ flex: 1 }}>
          <Text style={sh.title} numberOfLines={1}>{title}</Text>
          {subtitle && <Text style={sh.sub} numberOfLines={1}>{subtitle}</Text>}
        </View>
        {onRight && (
          <TouchableOpacity style={sh.rightBtn} onPress={onRight}>
            {rightIcon && <Ionicons name={rightIcon} size={18} color={C.gold} />}
            {rightLabel && <Text style={sh.rightLbl}>{rightLabel}</Text>}
          </TouchableOpacity>
        )}
      </View>
    </LinearGradient>
  );
}
const sh = StyleSheet.create({
  wrap:     { paddingTop: 52, paddingHorizontal: S.base, paddingBottom: S.lg },
  row:      { flexDirection: 'row', alignItems: 'center', gap: 12 },
  back:     { width: 40, height: 40, borderRadius: R.md, backgroundColor: `${C.surface}90`, justifyContent: 'center', alignItems: 'center' },
  title:    { color: C.t1, fontSize: F.xl, fontWeight: '900' },
  sub:      { color: C.t2, fontSize: F.sm, marginTop: 2 },
  rightBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: `${C.gold}20`, paddingHorizontal: 12, paddingVertical: 7, borderRadius: R.md, borderWidth: 1, borderColor: `${C.gold}35` },
  rightLbl: { color: C.gold, fontWeight: '700', fontSize: F.sm },
});

// ── TimetableWidget ───────────────────────────────────────────────
const TYPE_CFG = {
  live:     { color: C.live,    icon: 'radio',       label: 'Live'     },
  recorded: { color: C.cyan,    icon: 'play-circle', label: 'Recorded' },
  test:     { color: C.gold,    icon: 'clipboard',   label: 'Test'     },
  doubt:    { color: C.green,   icon: 'chatbubbles', label: 'Doubt'    },
};
const SUB_COLORS = {
  Physics: C.cyan, Chemistry: C.green, Maths: C.gold,
  Biology: '#22c55e', All: C.purple, Test: C.red,
};

export function TimetableWidget({ classes = [] }) {
  if (!classes.length)
    return (
      <View style={tw.empty}>
        <Ionicons name="checkmark-circle" size={18} color={C.green} />
        <Text style={tw.emptyTxt}>No more classes today!</Text>
      </View>
    );

  return (
    <View style={tw.container}>
      {classes.map((cls, i) => {
        const cfg = TYPE_CFG[cls.type] || TYPE_CFG.recorded;
        const col = SUB_COLORS[cls.subject] || C.gold;
        return (
          <View key={i} style={[tw.row, { borderLeftColor: col }, i < classes.length - 1 && tw.rowBorder]}>
            <View style={tw.timeCol}>
              <Text style={tw.time}>{cls.time}</Text>
              <Text style={tw.dur}>{cls.duration}m</Text>
            </View>
            <View style={tw.divider} />
            <View style={{ flex: 1, gap: 4 }}>
              <View style={tw.topRow}>
                <Text style={[tw.subj, { color: col }]}>{cls.subject}</Text>
                <View style={[tw.pill, { backgroundColor: `${cfg.color}20` }]}>
                  <Ionicons name={cfg.icon} size={10} color={cfg.color} />
                  <Text style={[tw.pillTxt, { color: cfg.color }]}>{cfg.label}</Text>
                </View>
              </View>
              <Text style={tw.topic} numberOfLines={1}>{cls.topic}</Text>
            </View>
          </View>
        );
      })}
    </View>
  );
}
const tw = StyleSheet.create({
  container:  { backgroundColor: C.card, borderRadius: R.xl, borderWidth: 1, borderColor: C.border, overflow: 'hidden' },
  row:        { flexDirection: 'row', alignItems: 'center', paddingVertical: S.md, paddingHorizontal: S.md, borderLeftWidth: 3, gap: 10 },
  rowBorder:  { borderBottomWidth: 1, borderBottomColor: C.border },
  timeCol:    { width: 46, alignItems: 'center', gap: 2 },
  time:       { color: C.t1, fontSize: 12, fontWeight: '800' },
  dur:        { color: C.t3, fontSize: 10 },
  divider:    { width: 1, height: 36, backgroundColor: C.border },
  topRow:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  subj:       { fontSize: 11, fontWeight: '700' },
  pill:       { flexDirection: 'row', alignItems: 'center', gap: 3, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 10 },
  pillTxt:    { fontSize: 10, fontWeight: '700' },
  topic:      { color: C.t1, fontSize: 13, fontWeight: '600' },
  empty:      { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: C.card, borderRadius: R.lg, padding: S.md, borderWidth: 1, borderColor: C.border },
  emptyTxt:   { color: C.t2, fontSize: 13, fontWeight: '600' },
});
