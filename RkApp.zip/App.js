// App.js — RK WIN Academy
// ─────────────────────────────────────────────────────────────────
//  Snack-compatible entry point.
//  All imports use relative paths. No native-only modules used.
// ─────────────────────────────────────────────────────────────────
import 'react-native-gesture-handler';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AuthProvider } from './src/context/AuthContext';
import { AppProvider  } from './src/context/AppContext';
import { AppNavigator  } from './src/navigation/index';

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <AuthProvider>
          <AppProvider>
            <NavigationContainer>
              <StatusBar barStyle="light-content" backgroundColor="#08090F" />
              <AppNavigator />
            </NavigationContainer>
          </AppProvider>
        </AuthProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
