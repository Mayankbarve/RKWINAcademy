# 🎓 RK WIN Academy — Snack.expo.dev Setup Guide

---

## ⚡ Quick Start in Snack (5 minutes)

### Step 1 — Open Snack
Go to **https://snack.expo.dev** → Click **"New Snack"**

### Step 2 — Clear default files
Delete everything in the left panel.

### Step 3 — Create folder structure
Click the **+** icon to create files. Build this exact structure:

```
App.js
src/
  theme/
    colors.js
    spacing.js
  context/
    AuthContext.js
    AppContext.js
  navigation/
    index.js
  components/
    UI.js
  services/
    firebase.js
    mockData.js
  screens/
    auth/
      SplashScreen.js
      LoginScreen.js
      RegisterScreen.js
    student/
      StudentDashboard.js
      BatchesScreen.js
      BatchDetailScreen.js
      ChapterDetailScreen.js
      VideoPlayerScreen.js
      LiveClassScreen.js
      TestScreen.js
      LeaderboardScreen.js
      ProfileScreen.js
      TimetableScreen.js
      NotificationsScreen.js
      WatchHistoryScreen.js
      ProjectSubmitScreen.js
    admin/
      AdminDashboard.js
      BatchManagement.js
      StudentManagement.js
      AdminAnalytics.js
      LiveControl.js
      ContentManagement.js
      NotifControl.js
      PaymentManagement.js
```

### Step 4 — Paste each file
Copy the content of each file from this zip into Snack.

### Step 5 — Add dependencies
In Snack, click the **packages icon (⬡)** in the left sidebar and add:

```
@react-navigation/native
@react-navigation/native-stack
@react-navigation/bottom-tabs
expo-linear-gradient
@react-native-async-storage/async-storage
react-native-webview
react-native-svg
react-native-safe-area-context
react-native-screens
react-native-gesture-handler
@expo/vector-icons
firebase
```

### Step 6 — Test
Click **"My Device"** tab in Snack → Open **Expo Go** → Scan QR code.

---

## 🔐 Demo Login

| Role    | Email                  | Password        |
|---------|------------------------|-----------------|
| Student | student@rkwin.com      | any password    |
| Admin   | any email              | `//rkadmin2025//` |

---

## 🔥 Firebase Setup (Real Backend)

### 1. Create Firebase Project
- Go to https://console.firebase.google.com
- Create project: **rk-win-academy**
- Enable: **Authentication** (Email+Password), **Firestore**, **Storage**

### 2. Update firebase.js
Open `src/services/firebase.js` and replace:
```js
const firebaseConfig = {
  apiKey:            "YOUR_API_KEY",         // ← paste your values
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  projectId:         "YOUR_PROJECT_ID",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID",
};
```

### 3. Set DEMO_MODE = false
Open `src/services/mockData.js`:
```js
export const DEMO_MODE = false;  // ← change this
```

### 4. Firestore Security Rules
In Firebase Console → Firestore → Rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth.uid == uid;
    }
    match /batches/{batchId} {
      allow read: if request.auth != null;
      allow write: if get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /liveClasses/{classId} {
      allow read: if request.auth != null;
      allow write: if get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /liveClasses/{classId}/chat/{msgId} {
      allow read, write: if request.auth != null;
    }
    match /notifications/{nId} {
      allow read: if request.auth != null;
      allow write: if get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin';
    }
    match /testResults/{rId} {
      allow read, write: if request.auth.uid == resource.data.uid;
    }
    match /leaderboard/{uid} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == uid;
    }
  }
}
```

### 5. Create Admin User in Firestore
1. Firebase → Authentication → Add user (email + password)
2. Copy the UID
3. Firestore → users collection → Add document (ID = UID):
```
name:  "RK Sir"
email: "admin@rkwinacademy.com"
role:  "admin"
enrolledBatches: []
points: 0
```

---

## 📱 Adding YouTube Videos

1. Upload class to YouTube as **UNLISTED**
2. Copy only the **Video ID** (11 characters after `v=`)
   - URL: `https://www.youtube.com/watch?v=jNQXAC9IVRw`
   - ID:  `jNQXAC9IVRw`
3. In Admin → Live Control → paste the Video ID
4. Students CANNOT see the video ID or URL

---

## 🏗️ Build APK from Snack

### Export from Snack
1. In Snack → Click **"Export"** (top right)
2. Download zip → extract on your phone in Termux

### Build with EAS
```bash
cd ~/RKWINAcademy
npm install
npm install -g eas-cli
eas login
eas build:configure
eas build -p android --profile preview
```

---

## 🔑 Change Admin Secret
Open `src/services/mockData.js`:
```js
export const ADMIN_SECRET = '//rkadmin2025//';  // ← change before publishing
```

---

## 🎨 Change Brand Color
Open `src/theme/colors.js`:
```js
gold:      '#F5A623',  // ← main brand color
goldDark:  '#C4841A',
```

---

## 📁 File Reference

| File | Purpose |
|------|---------|
| `App.js` | Entry point |
| `src/theme/colors.js` | All colors |
| `src/theme/spacing.js` | Fonts, spacing, radius |
| `src/context/AuthContext.js` | Login, logout, device lock |
| `src/context/AppContext.js` | All app data state |
| `src/navigation/index.js` | All navigators |
| `src/components/UI.js` | All reusable components |
| `src/services/firebase.js` | Firebase functions |
| `src/services/mockData.js` | Demo data + DEMO_MODE flag |

---

*RK WIN Academy — Production EdTech App*
